//////////////////////////////////////////////////////
//
//  3.8.1 WERTYU
//  PC/UVa IDs: 110301/10082, Popularity: A, Success rate: high Level: 1
//  programming_challenges
//  Created by Moussa on 8-DEC-2014 07:18 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>

using namespace std;

string ref_string = "QWERTYUIOP[]ASDFGHJKL;'ZXCVBNM,./`1234567890-=";

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.1.input");
    
    //data structure
    string s;
   
    //read input
    while (getline(cin, s) && (s != "\r") && (s != "\n") && (s != ""))
    {
            //init
        for (int i = 0; i<s.length(); i++)
            for (int j = 0; j<ref_string.length(); j++)
                if (s[i] == ref_string[j])
                    s[i] =  ref_string[j-1];
 
       //print output
       cout<<s<<endl;
    }
    
   return 0;
}