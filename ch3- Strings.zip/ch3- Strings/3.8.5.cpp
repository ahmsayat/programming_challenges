//////////////////////////////////////////////////////
//
//  3.8.5 Automated Judge Script
//  PC/UVa IDs: 110305/10188, Popularity: B, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 8-DEC-2014 09:46 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include<set>
#include<map>
#include<vector>

using namespace std;

int testcase = 1;
vector<string> correct, team;

bool is_accepted(string correct_solution, string team_submitted_solution)
{
    if (correct_solution.length() != team_submitted_solution.length())
        return false;
    
    for (int i=0; i < correct_solution.length(); i++)
        if (correct_solution[i] != team_submitted_solution[i]) //character comparision
            return false;
    
    return true;
}

bool is_all_accepted()
{
    for (int i=0; i < correct.size(); i++)
        if(! is_accepted(correct[i], team[i])) //single solution comparision
            return false;
    return true;
}


bool is_presentation_error(string correct_solution, string team_submitted_solution)
{
    if(is_accepted(correct_solution, team_submitted_solution))
        return false;
    
    string s="",t="";
    for (int i=0; i < correct_solution.length(); i++)
        if(isnumber(correct_solution[i]))
            s = s + correct_solution[i];
    
    for (int i=0; i < team_submitted_solution.length(); i++)
        if(isnumber(team_submitted_solution[i]))
            t = t + team_submitted_solution[i];
    
    //cout<<s<<" : "<<t<<endl;
    return s==t;
}

bool is_any_presentation_error()
{
    for (int i=0; i < correct.size(); i++)
        if(is_presentation_error(correct[i], team[i])) //single solution comparision
            return true;
    return false;
}

void check()
{
    cout<<"Run #"<<testcase++<<": ";
    
    if(is_all_accepted())
        cout<<"Accepted"<<endl;
    else if(is_any_presentation_error())
        cout<<"Presentation Error"<<endl;
    else
        cout<<"Wrong Answer"<<endl;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.5.input");
    
    //data structure
    string line;

    int n;
    while (getline(cin, line) && line != "0\r")
    {
        
        correct.clear(); team.clear();
        
        stringstream ss(line); ss>>n;
        
        while(n-- &&  getline(cin, line))
            correct.push_back(line);
        
        int m; getline(cin, line); stringstream sss(line); sss>>m;
        while(m-- &&  getline(cin, line))
            team.push_back(line);
        
        check();
    }
   return 0;
}
