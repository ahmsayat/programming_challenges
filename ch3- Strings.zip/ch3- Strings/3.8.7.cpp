//////////////////////////////////////////////////////
//
//  3.8.7 Doublets
//  PC/UVa IDs: 110307/10150, Popularity: C, Success rate: average Level: 3
//  programming_challenges
//  Created by Moussa on 8-DEC-2014 10:50 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include<set>
#include<map>
#include<vector>

using namespace std;

vector<string> dictionary;

//bool graph [25143][25143];
bool ** graph;

unsigned long N;

bool * visited;

bool is_Doublets(string a, string b)
{
    if (a.length() != b.length())
        return false;
    
    int dif = 0;
    for (int i = 0; i < a.length(); i++)
        if (a[i] != b[i])
            dif++;
    
    return (dif == 1);
}

map< pair<int, int>, pair<int, vector<int> > > dp;
vector<int> shortest_path(int source, int destination)
{
    //path[0]++; cout << &path << " " << source << " " << &path[0] << " " << path.size() << endl;
    visited[source] = true; //to avoid loops
    
    vector<int> temp; //creat local copy
    
    if (source == destination)
    {
        //temp.push_back(destination);
        return temp;
    }
    
    int min = INT_MAX;
    for (int i = 0; i < N; i++)
        if (graph[source][i] == true && visited[i] == false) //there is a link follow it and return minumum amongst all
        {
            temp = shortest_path(i , destination);
            if(temp.size() < min)
            {
                min = (int) temp.size();
                temp.push_back(i);
            }
        }

    return temp;
}

int find(string a)
{
    for (int i = 0; i < N; i++)
        if (dictionary[i] == a)
            return i;
    return -1;
}

void print()
{
    //print & debug my graph
    for (int i = 0; i < N; i++)
    {   for (int j = 0; j < N; j++)
        cout<< graph[i][j] << " ";
        cout<<endl;
    }
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.7.input");

    //data structure
    string line;
    while(getline(cin, line) && line != "\r")
        dictionary.push_back(line.substr(0,line.length()-1));
   
    N = dictionary.size();
    
    //alloc visited
    visited = new bool[N];
    
    //init visited
        for (int i = 0; i < N; i++)
            visited[i] = false;
    
    //alloc
    graph = new bool* [N]; //must //new array to N pointers [bool* ]
    for (int i = 0; i < N; i++)
        graph[i] = new bool[N];
    
    //init
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            graph[i][j] = false;

    //fill edges in the graph if doublets
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            graph[i][j] = is_Doublets(dictionary[i],dictionary[j]);

    //print();
    
    //graph traversal
    string a, b;
    while (cin>>a>>b)
    {
        //cout<<find(a)<< " "<<find(b)<<endl;
        vector<int> path = shortest_path(find(a), find(b));
        
        path.push_back(find(a));
        
        int shortest_path_length = (int) path.size();
        
        if( shortest_path_length == 1 )
            cout << "No solution." << endl;
        else
            //print final output or results
            for (int i = (int) path.size()-1; i >= 0 ; i--)
                cout<<dictionary[path[i]]<<endl;
        
        cout<<endl;
    }

    //cout<<dictionary.size();
    return 0;
}

/***My Graph

        booster	rooster	roaster	coasted roasted coastal postal
 booster   0        1       0       0       0       0      0
 rooster   1        0       1       0       0       0      0
 roaster   0	    1       0       0       1       0      0
 coasted   0        0       0       0       1       0      0
 roasted   0        0       1       1       0       0      0
 coastal   0        0       0       0       0       0      0
 postal    0        0       0       0       0       0      0

*/
