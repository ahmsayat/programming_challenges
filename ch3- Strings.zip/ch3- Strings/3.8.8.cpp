//////////////////////////////////////////////////////
//
//  3.8.8 Fmt
//  PC/UVa IDs: 110308/848, Popularity: C, Success rate: low Level: 2
//  programming_challenges
//  Created by Moussa on 12-DEC-2014 12:02 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include<set>
#include<map>
#include<vector>

using namespace std;

int N; vector<string> lines;

void print()
{
    //print & debug my graph
    for (int i = 0; i < N; i++)
        cout<< lines[i] << endl;
}

vector<string> format()
{
    vector<string> good_lines;
    
    string s = "";
    for (int i = 0; i < N; i++)
    {
        if (lines[i] == "")
        {
            good_lines.push_back(s.substr(1, s.length()));
            s = "";
        }
        else
            s = s + " " + lines[i];
    }
    
    good_lines.push_back(s);
    
    return good_lines;
}

void fmt_one_line(string s)
{
    if (s.length() <= 72)
        cout << s << endl;
    else
    {
        int start = 0, end = 0;
        for (int i = 0; i < s.length(); i++)
            if (s[i] == ' ')
            {
                if( (i - start) <= 72)
                    end = i;
                else
                {
                    cout<< s.substr(start, end-start) << endl;
                    start = end + 1;
                }
            }
        
        cout<< s.substr(start, s.length()-start) << endl;
    }
    
    cout<<endl;
}

void fmt()
{
      for (int i = 0; i < N; i++)
          fmt_one_line(lines[i]);
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.8.input");

    //data structure
    string line;
    while(getline(cin, line))
        lines.push_back(line.substr(0,line.length()-1));
    N = (int) lines.size(); //before format
    lines = format();
    N = (int) lines.size(); //after format
    fmt();
    return 0;
}