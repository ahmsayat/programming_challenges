//////////////////////////////////////////////////////
//
//  8.3 Common Permutation
//  PC/UVa IDs: 110303/10252, Popularity: A, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 8-DEC-2014 08:42 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include<set>

using namespace std;

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.3.input");
    
    //data structure
    string a, b;
    
    //read input
    while (cin>>a>>b)
    {
        set<char> st;
        
        for (int i = 0; i< a.length(); i++)
            for (int j = 0; j< b.length(); j++)
                if (a[i] == b[j])
                    st.insert(a[i]);
        
        for (set<char>::iterator it = st.begin(); it != st.end(); it++)
            cout<<*it;
        
        cout<<endl;
    }
    
   return 0;
}

/* SET Data Structure
- It is useful to use and know the SET data structure since it order items automatically and keep uniques only by dropping duplicates. 
*/