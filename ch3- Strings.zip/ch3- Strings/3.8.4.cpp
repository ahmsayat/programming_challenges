//////////////////////////////////////////////////////
//
//  3.8.4 Crypt Kicker II
//  PC/UVa IDs: 110304/850, Popularity: A, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 8-DEC-2014 09:06 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include<set>
#include<map>
#include<vector>

using namespace std;

string ref_string = "the quick brown fox jumps over the lazy dog\r";

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.4.input");
    
    //data structure
    string line;
    int T;
    cin>>T;
    
    vector<string> lines;
    
    while (T--) //read input
        while (getline(cin,line))
            if (line != "\r")
                lines.push_back(line);
    
   map<char, char> mp;
   //int ref;

   for (int i=0; i<lines.size(); i++)
       if (lines[i].length() == ref_string.length())
           for (int k=0; k<ref_string.length(); k++)
               mp[lines[i][k]] = ref_string[k];
    
           //for (int k=0; k<ref_string.length(); k++)
           //    if (ref_string[k] == lines[i][k] == ' ')
                   
    for (int i=0; i<lines.size(); i++)
    {   for (int k=0; k<lines[i].length(); k++)
            if (lines[i][k] == ' ')
                cout<< " ";
            else
                cout<<mp[lines[i][k]];
        cout<<endl;
    }
    
   return 0;
}

/* SET Data Structure
- It is useful to use and know the SET data structure since it order items automatically and keep uniques only by dropping duplicates. 
*/