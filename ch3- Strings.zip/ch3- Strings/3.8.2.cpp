//////////////////////////////////////////////////////
//
//  3.8.2 Where’s Waldorf?
//  PC/UVa IDs: 110302/10010, Popularity: B, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 8-DEC-2014 07:29 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>

using namespace std;

#define N 51

char grid [N][N];

bool check(int direction_x, int direction_y, int i, int j, string s)
{
    for (int k = 0; k<s.length(); k++)
    {
        if ( grid[i][j] != s[k])
            return false;
        
        i += direction_x;
        j += direction_y;
    }
    
    return true;
}

bool is_valid(string s, int i, int j)
{
    if (check(1, 0, i, j, s)) //horizontal left to right
        return true;
    else if(check(1, -1, i, j, s)) //diagonal bottom left to upper right
        return true;
    else if(check(1, 1, i, j, s)) //diagonal top left to bottom right
        return true;
    else if(check(-1, 0, i, j, s)) //horizontal right to left
        return true;
    else if(check(-1, -1, i, j, s)) //diagonal bottom right to upper left
        return true;
    else if(check(-1, 1, i, j, s)) //diagonal top right to bottom left
        return true;
    else if(check(0, -1, i, j, s)) //vertical bottom to upper
        return true;
    else if(check(0, 1, i, j, s)) //vertical upper to bottom
        return true;
    
    return false;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.2.input");
    
    //data structure
    int T;
    cin >> T; //scanf("%d\n",&T);
   
    //read input
    while (T--)
    {
        int m,n;
        cin>>m>>n; //scanf("%d%d\n",&m, &n);
        char c;
        for (int i = 1; i<=m; i++)
            for (int j = 1; j<=n; j++)
            {
                cin>>c;
                grid[i][j] = tolower(c);
            }
        
        int t;
        cin >> t;
        
        while (t--)
        {
            string s;
            cin>>s;
            
            //lower case the string
            for (int k = 0; k<s.length(); k++)
                s[k] = tolower(s[k]);
            
            for (int i = 1; i<=m; i++)
                for (int j = 1; j<=n; j++)
                    if (s[0] == grid[i][j]) //s[0] for first character only
                        if (is_valid(s, i, j))
                            {
                                cout << i << " " << j << endl;
                                goto here;
                            }
            
            here:;
        }
       
        /*print output
        for (int i = 1; i<=m; i++)
        {    for (int j = 1; j<=n; j++)
                cout<< grid[i][j];
            cout<<endl;
        }*/
        
        cout<<endl;
    }
    
   return 0;
}