//////////////////////////////////////////////////////
//
//  3.8.6 File Fragmentation
//  PC/UVa IDs: 110306/10132, Popularity: C, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 8-DEC-2014 10:50 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include<set>
#include<map>
#include<vector>

using namespace std;

vector<string> fragments;
int orginal_length;
map<string, map<string, bool>> candidates;
map<string, int> visited;

void check_average()
{
    int average = 0;
    for (int i=0; i < fragments.size(); i++)
        average+=fragments[i].length();
    average/=fragments.size();
    orginal_length = average * 2; //times two because of each dropped file is divided into exactly two fragments
}

void construct_candidates()
{
    for (int i=0; i < fragments.size(); i++)
        for (int j=0; j < fragments.size(); j++)
            if ( (i != j) && (fragments[i].length() + fragments[j].length() == orginal_length)) //unique candidates
                candidates[fragments[i]][fragments[j]] = false;
}

bool is_valid_pair(string p1, string p2)
{
    return true;
    return false;
}

void try_all_pairs()
{
    for (map<string, map<string, bool>>::iterator it = candidates.begin(); it != candidates.end(); it++)
        for (map<string, bool>::iterator it2 = it->second.begin(); it2 != it->second.end(); it2++)
            if(is_valid_pair(it->first, it2->first))
            {
                visited[it->first + it2->first]++;
                //visited[it2->first + it->first]++;
                //cout<< it->first << it2->first <<endl;
                //cout<< it2->first << it->first <<endl;
            }
}

int main()
{
   ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch3- Strings/3.8.6.input");
   
   //data structure
   string line; getline(cin, line); int T; stringstream ss(line); ss>>T;

   while (T--)
   {
       fragments.clear();
       while(cin>>line && line != "\n")
            fragments.push_back(line);
        
       check_average(); //cout<<orginal_length<<endl;
        
       construct_candidates(); try_all_pairs();
       
       //the correct combination will be repeated half the fragments
       for (map<string, int>::iterator it = visited.begin(); it != visited.end(); it++)
           if (it->second == fragments.size()/2)
               cout << it->first << endl;
   }

   return 0;
}