//////////////////////////////////////////////////////
//
//  5.9.2 Reverse and Add
//  PC/UVa IDs: 110502/10018, Popularity: A, Success rate: low Level: 1
//  programming_challenges
//  Created by Moussa on 27-DEC-2014 9:15 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

vector<char> number;

void convert(int num)
{
    
    //cout << num << endl;
    
    number.clear();
    while (num > 0) {
        char c = '0' + char(num % 10);
        number.push_back(c);
        num/=10;
    }
    
    //cout<<number.size()<<endl;
}


bool is_palindrome(int num)
{
    convert(num);
    for (int i=0; i<number.size(); i++)
       if(number[i] != number[number.size() - 1 - i])
           return false;
    return true;
}


int add_to_self(int num)
{
    int res = 0, carry = 0;
    for (int i=0; i<number.size(); i++)
    {
        int a = number[i] - '0';
        int b = number[number.size() - 1 - i] - '0';
        
        int v = (a+b) + carry;
        
        carry = v / 10; //this must be before the line below since v will be distorted
        
        if(v > 9) v%=10;
        
        res = res + v;
        res = res * 10;
    }
    
    if(carry > 0) //take care
        res = res + carry;
    else
        res = res / 10;

    return res;
}

void print()
{
    for (int i=0; i<number.size(); i++)
        cout<<number[i] << " ";
    cout<<endl;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.2.input");
    
    int N; cin >> N;
    
    while (N--)
    {
        int num; cin >> num; //convert(num);
        int counter = 0;
        
        while (is_palindrome(num) == false && ++counter)
            num = add_to_self(num);
        
        cout << counter << " " << num << endl;
    }
    
    return 0;
}
