//////////////////////////////////////////////////////
//
//  5.9.7 The Stern-Brocot Number System
//  PC/UVa IDs: 110507/10077, Popularity: C, Success rate: high Level: 1
//  programming_challenges
//  Created by Moussa on 02-JAN-2015 7:03 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.7.input");

struct NODE
{
    int m;
    int n;
    NODE * left;
    NODE * right;
    NODE(int m, int n) : m(m), n(n), left(NULL), right(NULL){}
};

NODE * arr[3];

int mleft = 0, nleft = 1, mright = 1, nright = 0;
int rootm = mleft + mright, rootn = nleft + nright;

/*
*/

string sol = "";

void solve(int m, int n)
{
    if ((m * rootn) == (rootm * n))
    {
        cout << endl;
        return;
    }
    else if((m * rootn) < (rootm * n))
    {
        mright = rootm; nright = rootn;
        cout << "L";
    }
    else
    {
        //cout<< rootm << " / " << rootn << endl;
        mleft = rootm; nleft = rootn;
        cout << "R";
    }
    
    rootm = mleft + mright; rootn = nleft + nright;
    solve(m, n);
}

void R(int m, int n)
{
    if (m * arr[1]->n == arr[1]->m * n)
    {
        //cout << "I" << endl;
        cout << endl;
        return;
    }
    else if (m * arr[1]->n < arr[1]->m * n)
    {
        arr[2]->m = arr[1]->m;
        arr[2]->n = arr[1]->n;
        //cout<< arr[1]->m << " / " << arr[1]->n << endl;
        cout << "L";
    }
    else
    {
        arr[0]->m = arr[1]->m;
        arr[0]->n = arr[1]->n;
        //cout<< arr[1]->m << " / " << arr[1]->n << endl;
        cout << "R";
    }
    
    arr[1]->m = arr[0]->m + arr[2]->m;
    arr[1]->n = arr[0]->n + arr[2]->n;
    R(m, n);
}

int main()
{
    int m = 0, n = 0;
    
    while (::cin >> m >> n)
    {
        sol = "";
        arr[0] = new NODE(0,1);
        arr[1] = new NODE(1,1);
        arr[2] = new NODE(1,0);
        mleft = 0, nleft = 1, mright = 1, nright = 0;
        rootm = mleft + mright, rootn = nleft + nright;
        //solve(m, n);
        R(m,n);
    }

    return 0;
}

/* These rational number comparisons are wrong
 if (m == rootm && n == rootn)
 {
 cout << sol << endl;
 return;
 }
 else if ((m/n) > (rootm/rootn))
 {
 mleft = rootm; nleft = rootn;
 rootm = rootm + mright; rootn = rootn + nright;
 sol+="R";
 }
 else if((m/n) < (rootm/rootn))
 {
 mright = rootm; nright = rootn;
 rootm = rootm + mleft; rootn = rootn + nleft;
 sol+="L";
 }

*/
