//////////////////////////////////////////////////////
//
//  My attempt to create a better compression algorithm
//  programming_challenges
//  Created by Moussa on 01-JAN-2015 2:59 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//  If I can combin/represent 2 bytes as 1 byte, I'd get Nobel
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

unsigned int Megabyte = 1048576;

void serialize()
{
    ofstream out("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.5.ouput");
    /*******WOW CODE********/
    unsigned int Gigabyte = 1073741824 * 3;
    char * bytes = new char[Gigabyte+1]; //must to cosider end of file/string character so add +1 byte to avoid a crash
    for (unsigned int i=0; i<Gigabyte; i++)
        bytes[i] = 'c';
    /****** Results: 3 GB File took 33 seconds to process 3 GB memory and to write this to disk at rate 200 MB/sec *************/
    out << bytes;
}

void print_binary(unsigned char byte)
{
    if (byte == 0) cout << "0";
    else if(byte == 1) cout << "1";
    else { print_binary(byte >> 1); cout << (((byte & 1) == true)? "1" : "0"); }
}

int calculate_value(vector<int> bits)
{
    int res = 0;
    for(int i=0; i<bits.size(); i++)
        res = res + bits[i] * pow(2, i);
    return res;
}

vector<int> convert_into_bits_vector(unsigned char v)
{
    vector<int> bits;
        do bits.push_back(v & 1); while (v >>= 1);
    return bits;
}

unsigned char compress(unsigned char a, unsigned char b)
{
    unsigned char res = 0;
    vector<int> a_bits = convert_into_bits_vector(a);
    cout << (int) a << " ";
    cout << calculate_value(a_bits)<<" ";
    for(int i=0; i<a_bits.size(); i++)
        res = res + a_bits[i] * pow(2, i);
    cout<<(int) res<<endl;
    
    vector<int> b_bits = convert_into_bits_vector(b);
    return res;
}

void decompress(unsigned char c)
{
    unsigned char a = '\0'; unsigned char b = '\0';
    cout << c << endl;
    
    vector<int> bits = convert_into_bits_vector(c);
    cout << calculate_value(bits) << endl;
    
    print_binary(a); cout << " "; print_binary(b); cout << endl;
}

void print_a()
{
    for (int i=0; i<pow(2, 8); i++)
            cout << i/2 << endl;
}

int main()
{
    print_a();
    return 0;
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.5.input");
    ofstream out("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.5.ouput");
    unsigned char c=111;
    long long N = 0;
    
    print_binary(111); cout<<endl;
    
    decompress(c);
    
    decompress(compress(3, 7)); //Inverse function cancels its function so this should print 3 and 7 or 11 111
    
    return 0;
    
    time_t * t = new time_t();
    
    *t = 2.0;
    
    tm* m = gmtime(t);
    
    cout << m->tm_hour << " " << m->tm_mday << " " << m->tm_min << " " << endl;
    
    cout << ctime(t) << endl;
    
    cout << asctime(m) << endl;
    
    cout << clock() << endl;
    
    cin >> N;
    
    map<pair<char, int>, int> freq;
    
    //Megabyte++;
    
    while (--Megabyte)
        freq[pair<char, int>(c++, Megabyte%2)]++;
    
    while (Megabyte++ < 1024*1024) freq[pair<char, int>(c++, Megabyte%2)]++;

    cout << "size: " << freq.size() << endl;
    for (map<pair<char, int>, int>::iterator it = freq.begin(); it != freq.end(); it++)
        cout << it->first.first << " " << it->first.second << " " << it->second << endl;
        
    return 0;
}

/****
 char bytes[1024 * 1024 * 7]; Be careful with static allocation as it is limited to 7 MB only. Program Stack is limited.
 char bytes[1024 * 1024 * 8]; Requesting 8 or more memory will give you bad access error. 
 char * bytes = new char[Gigabyte]; Dynamic allocation is the best as it uses the heap and you can request as much as the memory installed on the PC.
 char * bytes = new char[3*Gigabyte +1]; will give u => libc++abi.dylib: terminating with uncaught exception of type std::bad_alloc: std::bad_alloc
*****************************************************************************************************************************************************
0] 0|1 => 00, 01, 10, 11
1] 0|1 =>
2] 0|1 =>
3] 0|1 =>
4] 0|1 =>
5] 0|1 =>
6] 0|1 =>
7] 0|1 =>
    T F
00  0 1
01  1 0
10
11
 
0 = 0 + 0
1 = 1 + 0
2 = 1 + 1
3 = 1 + 2

even   odd even
0 0 =
0 1 =
1 0 =
1 1 =
 
odd    odd even
0 0 =
0 1 =
1 0 =
1 1 =
 
AND truth table
 0 0    0
 0 1    0
 1 0    0
 1 1    1

OR truth table
 0 0    0
 0 1    1
 1 0    1
 1 1    1
 
XOR truth table
 0 0    0
 0 1    1
 1 0    1
 1 1    0
 
AND truth table
 0 0    0
 0 1    0
 1 0    0
 1 1    1
 
if we used mode it is solved but mode is an overhead

*/

