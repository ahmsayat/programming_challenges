//////////////////////////////////////////////////////
//
//  Print all rational numbers
//  Rational Numbers — These are the numbers which can be expressed as the ratio of two integers, i.e. c is rational if c = a/b for integers a and b.
//  programming_challenges
//  Created by Moussa on 25-DEC-2014 3:54 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

map<double, int> freq;

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/5.9.0.input");
    
    unsigned char c = ~0 + 2; //overflow so the most significant bits above the 8th bit will be droped and ignored
    cout << (double) (c) << endl; //prints 1
    
    cout<< ~0 <<endl; //prints -1
    
    //data structure
    for (unsigned char a=1; a<(unsigned char)(~0); a++)
        for (unsigned char b=+1; b<(unsigned char)(~0); b++)
            if (freq.find((double)((double) a / b - floor(a / b))) != freq.end())
                freq[(double)((double) a / b - floor( a / b))]++;
            else
                freq[(double)((double) a / b - floor( a / b))] = 1;
    
    //how can we benefits from these rational numbers? 
    cout << "unique sequences: " << freq.size() << endl;
    for (map<double, int>::iterator it = freq.begin(); it != freq.end(); it++)
        cout << setprecision(100) << double (it->first) << endl;
    
    return 0;
}

/***
 char means byte which is 8 bits
 this code will never terminate as "Comparison of constant 999 with expression of type 'char' is always true"
 
 for (char a=1; a<999; a++)
    for (char b=1; b<999; b++)
        cout <<(double) a / b << endl;
 
 results:
 -0.2
 -0.25
 -0.333333
 -0.5
 -1
 inf
 1
 0.5
**/
