//////////////////////////////////////////////////////
//
//  5.9.4 Ones
//  PC/UVa IDs: 110504/10127, Popularity: A, Success rate: high Level: 2
//  programming_challenges
//  Created by Moussa on 31-DEC-2014 3:31 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

vector<char> number;

void convert(long long num)
{
    number.clear();
    while (num > 0) {
        char c = '0' + char(num % 10);
        number.push_back(c);
        num/=10;
    }
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.4.input");
    
    int N; 
    
    while (cin >> N)
    {
        long long x = 1;
        
        while(x % N != 0)
            x = x * 10 + 1;
        
        convert(x);
        cout << number.size() << endl;
    }
    
    return 0;
}
