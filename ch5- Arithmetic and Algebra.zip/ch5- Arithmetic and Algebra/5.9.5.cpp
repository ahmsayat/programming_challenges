//////////////////////////////////////////////////////
//
//  5.9.5 A Multiplication Game
//  PC/UVa IDs: 110505/847, Popularity: A, Success rate: high Level: 3
//  programming_challenges
//  Created by Moussa on 31-DEC-2014 3:49 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

vector<char> number;

void convert(long long num)
{
    number.clear();
    while (num > 0) {
        char c = '0' + char(num % 10);
        number.push_back(c);
        num/=10;
    }
}

/*
 Dynamic Programming
 We do a depth first search for choices that can win. We use memoization to remember the values of p for which it was possible to win.
********DP must have 3 things [base case][memoization step][memoization check]********/
map<int,bool> CanWin;//the dp trick to know what to memoize in what data structure
bool whoWins(int n, int p, bool Current)
{
    //[base case]
    if (p >= n)
        return !Current; //this means previous player already won and got p >= n
    else
        for (int i=2; i<=9; i++)
        {
            //[memoization step]
            if (CanWin.find(p*i) == CanWin.end()) //not found in memoization data structure
                CanWin[p*i] /*memoization step*/ =  /*recursion*/ whoWins(n, p*i, !Current) == Current;
            
            //[memoization check]
            if (CanWin[p*i]) //concern about wins only
                return Current; 
        }
    return !Current;
}

bool DP(int n, int p, bool stan)
{
    if (p >= n)
        return !stan;
    else
        for (int i=2; i<9; i++)
            return DP(n, i*p, !stan);
}

//my unverified function works fine as DP
bool recursion(int n, int p, bool stan)
{
    if (p >= n)
        return stan;
    else
        for (int i=2; i<9; i++)
            return DP(n, i*p, !stan);
}

/*
 explanation:
 Clearly, Stan can win trivially with n between 2 and 9. If the number is between 10 and 18, then even if Stan picks 2, Ollie will win. For numbers between 19 and 162, Stan can pick a number low enough that Ollie can't win, bt high enough that he can win when Ollie only picks 2. From this, a pattern arises.
 
 If n <= 9, Stan wins
 Else If n <= 9*2 Ollie wins
 Else If n <= 9*2*9 Stan wins
 Else If n <= 9*2*9*2, Ollie wins
 ...etc...
 */
void simplest_solution(int n)
{
        long p = 1;
        bool stan = true; bool ollie = false;
        while ( p < n ) {
            if ( stan )
                p *= 9;
            else
                p *= 2;
            stan = !stan;
        }
        if (!stan) printf ("Stan wins.\n"); else printf ("Ollie wins.\n");
}

/*
 Pattern
 Observe that the maximum number the first player can get on his first roll is 9. The max on his second roll is 9*2*9, because the second player can roll a 2. And similarly, on his third roll it is 9*2*9*2*9. The second player can get a max of 2*9 on his first, 2*9*2*9 on his second roll and on and on.Hence, it is clear that number range define which player wins. The range go like this
 0-9 stan wins
 9+1-9*2 ollie wins
 9*2+1 – 9*2*9 stan wins
 9*2*9+1 – 9*2*9*2 ollie wins
 So we devise a way to check where the numbers fall and we’re done. I chose logs. We can divide the ranges into pairs, where each pair is bordered on both sides by a a power of 18. So we find which power of 18 it is using logs and then we find if it lies within that power of 18 multiplied by 9.
*/
void simplest_solution_patterns(int n)
{
    long long int lo;
    long double lg = logl(n)/logl(18); //this will gives log(n) to base 18
    lo = floorl(lg);
    if (lg - lo < 0.00000000001) {cout << "Ollie wins.\n";return;}
    if ( n/powl(18.0,lo) > 9.0 ) cout << "Ollie wins.\n";
    else cout << "Stan wins.\n";
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.5.input");

    int N = 0;
    while (cin >> N)
    {
        whoWins(N, 1, true)? cout <<  "Stan wins." << endl : cout <<  "Ollie wins." << endl;
        //DP(N, 1, true)? cout <<  "Stan wins." << endl : cout <<  "Ollie wins." << endl;
        CanWin.clear();
    }

    return 0;
}
