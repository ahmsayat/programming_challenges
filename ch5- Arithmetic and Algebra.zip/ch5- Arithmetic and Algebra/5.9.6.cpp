//////////////////////////////////////////////////////
//
//  5.9.6 Polynomial Coefficients
//  PC/UVa IDs: 110506/10105, Popularity: B, Success rate: high Level: 1
//  programming_challenges
//  Created by Moussa on 02-JAN-2015 2:43 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.6.input");

//compute n!
int factorial(int n)
{
    int res = 1;
    for (int i =1; i<=n; i++)
        res = res * i;
    return res;
}

/*
 Solution 2
 This solution involves the multinational coefficient function, which is defined as follows. For a multinomial such as (x1 + x2 + x3 …)^n, the coefficient of the element of the product with the exponent n1 for x1, n2 for x2 and so on is equal n!/(n1! * n2! *n3! …).
*/
void solve(int N, int K)
{
    int res = 1;
    for (int i=0; i<K; i++)
    {
        int t;
        ::cin >> t;
        res = res * factorial(t);
    }
    
    cout << factorial(N)/res << endl;
}

int main()
{
    int N = 0, K = 0;
    
    while (::cin >> N >> K)
    {
        solve(N,K);
    }

    return 0;
}
/*
 While the answer to this problem is quite simple, the derivation is not. For a complete derivation, see:
 
 http://www.comp.nus.edu.sg/~stevenha/programming/volC1.html#10105%20-%20Polynomial%20coefficients
 
 Here's a quick overview:
 
 Let n(k) be the power of the kth term in the monomial we're asked to examine.
 
 Given the polynomial (x1 + x2 + ... + xl)^n, we can break it up using the binomial theorem:
 
 ((x1 + ... + xk-1) + xk)^n
 
 [sum from i = 1 to k] (n C i) * (x1 + ... + xk-1)^n-i * xk^i
 
 The only term we care about is where i = n(xk), so we can through away the rest. We keep breaking this down recursively until we end up with a product of Chooses, which we can then simplify into a simple final form:
 
 n! / (n(1)! * n(2)! * ... * n(k)!)
*/
