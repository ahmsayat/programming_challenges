//////////////////////////////////////////////////////
//
//  5.9.8 Pairsumonious Numbers
//  PC/UVa IDs: 110508/10202, Popularity: B, Success rate: high Level: 4
//  programming_challenges
//  Created by Moussa on 02-JAN-2015 10:35 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.8.input");

/*
 Explanation:
 This is a backtracking solution. Firstly, observe that in our array of sums, if we sort the array, the first two elements are guaranteed to be A+B, A+C, where A,B,C are the three smallest integers. Since we have A+B and A+C, we need B+C in order to solve for A, B and C, hence we need to iterate through all elements to find B+C. Additionally, since this is backtracking, we need to make sure that after we do each assignment of values to results, we need to test if they are compatible with the rest of the values we have. Here’s an illustration of the order in which we looked for elements.
 A+B, A+C, B+C, A+D, B+D, C+D, A+E, B+E, C+E, D+E …
 Basically, after the third element, we try to find one new element and then test if the values that we can generate and that should exist in the array are there. If at any point we can’t find a result, then we just digress to the previous step and change the value for that.
 
 Worth mentioning that there’s a solution that doesn’t use BT, but rather exploits the fact that the array is sorted by constantly removing elements from the array in a way that allows us to predict what the next smallest element will be. However, both approaches are equally fast.
*/

bool solve(int N, int sums[], int ans[]){
    int M = N*(N-1)/2;
    
    multiset<int> S;
    
    //A+B, A+C are first smallest two
    sort(sums,sums+M);
    
    //find B+C
    for(int i=2; i<M; i++)
    {
        if((sums[0] + sums[1] - sums[i]) % 2 == 0) //A+B + A+C - (B+C) = 2A . IF it is even then this may be 2A
        {
            ans[0] = (sums[0] + sums[1] - sums[i]) / 2; //found A
            
            S = multiset<int>(sums,sums+M);
            
            bool valid = true;
            
            //Test A and find all others paired with A
            for(int j = 1; j<N && valid; j++)
            {
                ans[j] = (*S.begin()) - ans[0];
                
                for(int k = 0; k<j && valid; k++)
                    if(S.find(ans[k] + ans[j]) != S.end()) //found so erase it
                       S.erase(S.find(ans[k] + ans[j]));
                    else
                        valid = false; //sum of pairs is not found so it is invalid
            }
            
            if(valid)
                return true;
        }
    }
    
    return false;
}

int main()
{
    int N,sums[45],ans[10]; // if 2<N<=10 then sums <= 45 or (10*9/2)
    
    while(::cin >> N)
    {
        int M = N*(N-1)/2; //sums
        
        //read input / sums
        for(int i=0; i<M; i++) ::cin >> sums[i];
        
        //solve
        if(! solve(N,sums,ans))
            printf("Impossible\n");
        else
        {   //print original numbers in ans
            for(int i = 0; i<N-1; i++)
                printf("%d ",ans[i]);
            printf("%d\n",ans[N-1]);
        }
    }

    return 0;
}
