//////////////////////////////////////////////////////
//
//  5.9.3 The Archeologist’s Dilemma
//  PC/UVa IDs: 110503/701, Popularity: A, Success rate: low Level: 1
//  programming_challenges
//  Created by Moussa on 31-DEC-2014 2:45 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

vector<char> number;

void convert(int num)
{
    
    number.clear();
    while (num > 0) {
        char c = '0' + char(num % 10);
        number.push_back(c);
        num/=10;
    }
}

void print()
{
    for (int i=0; i<number.size(); i++)
        cout<<number[i] << " ";
    cout<<endl;
}

bool is_correct(int x, int y)
{
    stringstream aa; aa << x; stringstream bb; bb << y;
    string a, b; aa >> a; bb >> b;
    return a == b.substr(0,a.size());
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.3.input");
    
    int N; 
    
    while (cin >> N)
    {
        convert(N);
        
        int p = ceil(log2(N * pow(10, number.size() * 2))); //starting power of 2
        
        while(is_correct(N, pow(2.0, p)) == false)
            p++;
        
        cout << p << endl;
    }
    
    return 0;
}
