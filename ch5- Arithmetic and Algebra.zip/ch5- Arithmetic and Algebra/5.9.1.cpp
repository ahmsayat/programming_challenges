//////////////////////////////////////////////////////
//
//  5.9.1 Primary Arithmetic
//  PC/UVa IDs: 110501/10035, Popularity: A, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 27-DEC-2014 8:58 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch5- Arithmetic and Algebra/5.9.1.input");
    int A, B;
    while (cin >> A >> B && A !=0) {
        int cnt = 0;
        
        while (A > 0 && B > 0) {
            int carry = 0;
            int v = carry + (A % 10) + (B % 10);
            if (v > 9)
            {
                cnt++;
                carry = 1;
            }
            
            A/=10; B/=10;
        }
        
        switch (cnt)
        {
            case 0:
                cout << "No carry operation." << endl;
                break;
            case 1:
                cout << cnt << " carry operation." << endl;
                break;
            default:
                cout << cnt << " carry operations." << endl;
                break;
        }
    }
    return 0;
}
