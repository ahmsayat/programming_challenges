//////////////////////////////////////////////////////
//
//  6.6.2 How Many Pieces of Land?
//  PC/UVa IDs: 110602/10213, Popularity: B, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 16-JAN-2015 6:57 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include "MoussaInteger.cpp"

using namespace std;

#define MAXN 10000//2147483648 //1<<32  = 2^31 = 2,147,483,648

long long Pascal[MAXN][MAXN];

//MAXN for this function is 10000 after that program will not terminate within seconds
void calc_all_binomial_coeffecients()
{
    for (int i=0; i<MAXN; i++) Pascal[i][0] = 1;
    for (int j=0; j<MAXN; j++) Pascal[j][j] = 1;
    
    for (int i=1; i<MAXN; i++)
        for (int j=1; j<i; j++)
            Pascal[i][j] = Pascal[i-1][j-1] + Pascal[i-1][j];
}

long long Choose(int n, int k)
{
    return Pascal[n][k];
}

void print_pascal()
{
    for (int i=0; i<=MAXN; i++)
    {
        for (int j=0; j<=i; j++)
            cout << Pascal[i][j] << " ";
        cout << endl;
    }
}

//max n can this function compute is 170,000 when choosing 2 and 1400 when choosing 4
//recursive
double C(long n , long k)
{
    if (k == 0)
        return 1;
    else if (k == 1)
        return n;
    else if(k == n)
        return 1;
    else
        return C(n-1,k-1) + C(n-1,k);
}

//dp
map<pair<long, long>, double> bc;
double C2(long n , long k)
{
    if (bc.find(pair<int, int>(n,k)) != bc.end())
        return bc[pair<int, int>(n,k)];
    if (k == 0)
        return 1;
    else if (k == 1)
        return n;
    else if(k == n)
        return 1;
    else
        return  bc[pair<int, int>(n,k)] = C(n-1,k-1) + C(n-1,k);
}

struct BigInteger
{
    char Digits[110];
    int LastDigit;
    void addBI(BigInteger & a, BigInteger & b, BigInteger & c)
    {
        for (int i=0; i<110; i++)
            c.Digits[i] = 0;
        int carry=0;
        
        c.LastDigit = max(a.LastDigit, b.LastDigit);
        
        for (int i=0; i<=c.LastDigit; i++)
        {
            c.Digits[i] = (a.Digits[i] + b.Digits[i] + carry)%10;
            carry = (a.Digits[i] + b.Digits[i] + carry)/10;
        }
        
        if (carry)
            c.Digits[++c.LastDigit] = carry;
        return;
    }
    
    int compare_BigIntegers(BigInteger & a, BigInteger & b)
    {
        if (a.LastDigit != b.LastDigit)
            return a.LastDigit > b.LastDigit;
            
        for (int i = a.LastDigit; i >= 0; i--)
            if (a.Digits[i] != b.Digits[i])
                return a.Digits[i] > b.Digits[i];
            
        return -1;
    }
};

//n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1.
//Which is equal to nC4 + nC2 + 1
void solve(long n)
{
    double res = n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1;
    cout << res << endl;
}

/*
//n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1.
//Which is equal to nC4 + nC2 + 1
#include "mybignum.cpp"
void solve4(long s)
{
    bignum * one = new bignum();
    bignum * two = new bignum();
    bignum * three = new bignum();
    bignum * twenty_four = new bignum();
    bignum * n = new bignum();
    bignum * n_1 = new bignum();
    bignum * n_2 = new bignum();
    bignum * n_3 = new bignum();
    bignum * res = new bignum();
    bignum * res1 = new bignum();
    bignum * res2 = new bignum();
    bignum * res3 = new bignum();
    bignum * res4 = new bignum();
    bignum * res5 = new bignum();
    bignum * res6 = new bignum();
    
    one->int_to_bignum(1, one);
    two->int_to_bignum(2, two);
    three->int_to_bignum(3, three);
    twenty_four->int_to_bignum(24, twenty_four);
    n->int_to_bignum(s, n);
    
    n_1->subtract_bignum(n, one, n_1);
    n_2->subtract_bignum(n, two, n_2);
    n_3->subtract_bignum(n, three, n_3);
    
    res1->multiply_bignum(n, n_1, res1);
    res2->multiply_bignum(n_2, n_3, res2);
    res3->multiply_bignum(res1, res2, res3);
    
    res4->divide_bignum(res1, two, res4);
    res5->divide_bignum(res3, twenty_four, res5);
    res5->add_bignum(res4, res5, res6);
    
    //signbit is not set correctly after add //
    
    //res6->signbit = 1;
    
    res->add_bignum(res6, one, res);

    //double res = n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1;
    //cout << res->signbit << endl;
    
    res->print_bignum(res);
}
*/

//n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1.
//Which is equal to nC4 + nC2 + 1

#include "bignum.txt"

/*** Closed Form: res = n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1; ***/
void solve4(long s)
{
    bignum * one = new bignum();
    bignum * two = new bignum();
    bignum * three = new bignum();
    bignum * twenty_four = new bignum();
    bignum * n = new bignum();
    bignum * n_1 = new bignum();
    bignum * n_2 = new bignum();
    bignum * n_3 = new bignum();
    bignum * res = new bignum();
    bignum * res1 = new bignum();
    bignum * res2 = new bignum();
    bignum * res3 = new bignum();
    bignum * res4 = new bignum();
    bignum * res5 = new bignum();
    bignum * res6 = new bignum();
    
    //res = (bignum *) malloc(sizeof(bignum));

    int_to_bignum(1, one);
    int_to_bignum(2, two);
    int_to_bignum(3, three);
    int_to_bignum(24, twenty_four);
    int_to_bignum(s, n);
    
    subtract_bignum(n, one, n_1);
    subtract_bignum(n, two, n_2);
    subtract_bignum(n, three, n_3);

    //n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1.
    //print_bignum(n);

    multiply_bignum(n, n_1, res1);
    
    multiply_bignum(n_2, n_3, res2);
    
    multiply_bignum(res1, res2, res3);
    
    divide_bignum(res1, two, res4);
    
    divide_bignum(res3, twenty_four, res5);
   
    add_bignum(res4, res5, res6);
    
    add_bignum(res6, one, res);
    
    //double res = n*(n-1)/2 + n*(n-1)*(n-2)*(n-3)/24 + 1;
    //cout << res << endl;
    
    print_bignum(res);
}

typedef unsigned long   long ulonglong;
string add (string const & x, string const & y)
{
    int sumlen = max(x.size (), y.size ()) + 1;
    
    string sum (sumlen, '0'), xtmp (sumlen, '0'), ytmp (sumlen, '0');
    
    int xstart = sumlen - x.size (), ystart = sumlen - y.size ();
    
    copy (x.begin (), x.end (), xtmp.begin () + xstart);
    copy (y.begin (), y.end (), ytmp.begin () + ystart);
    
    for (int i = sumlen-1, s, carry = 0; i >= 0; --i, carry = s / 10)
        sum [i] = (s = xtmp [i] + ytmp [i] - '0'- '0' + carry)% 10 + '0';
    
    for (; sum [0] == '0'; sum.erase (0, 1))
        {}
    
    return sum;
}

string muladd (ulonglong x, ulonglong y, ulonglong z)
{
    int const shift = 31;
    
    ulonglong x1 = x >> shift, x2 = x & ((1LL << shift) - 1);
    ulonglong y1 = y >> shift, y2 = y & ((1LL << shift) - 1);
    ulonglong z1 = z >> shift, z2 = z & ((1LL << shift) - 1);
    
    ulonglong high = x1 * y1, mid = x1 * y2 + x2 * y1 + z1, low = x2 * y2 + z2;
    
    string tmp;
    for (; high != 0; high /= 10)
        tmp.append (1, high% 10 + '0');
    
    string highs (tmp.rbegin (), tmp.rend ());
    for (tmp.clear(); mid != 0; mid /= 10)
        tmp.append (1, mid %10 + '0');
    
    string mids (tmp.rbegin (), tmp.rend ());
    for (tmp.clear(); low != 0; low /= 10)
        tmp.append (1, low%10 + '0');
    
    string lows (tmp.rbegin (), tmp.rend ());
    for (int i = 0; i < shift * 2; ++i)
        highs = add (highs, highs);
    
    for (int i = 0; i <shift; ++i)
        mids = add (mids, mids);
    
    string product = add (highs, mids);
    
    product = add (product, lows);
    
    return product;
}


void solve3(ulonglong n)
{
    /* F (n) = (n, 4) + (n, 2) + 1 */
    if (n < 4)
    {
        ulonglong fn = 1;
        for (int i = 1; i < n; ++i)
            fn *= 2;
        cout << fn << endl;
    }
    else if (n < (1 << 16))
    {
        ulonglong fn = n * (n-1) / 2 * (n-2) / 3 * (n-3) / 4;
        fn += (n%2 == 0)? n/2*(n-1) : (n-1)/2*n;
        fn += 1;
        cout << fn << endl;
    }
    else
    {
        ulonglong x = n * (n-1) / 2, y = (n-2) * (n-3) / 2;
        if (x% 2 == 0)
            x /= 2;
        else
            y /= 2;
        if (x% 3 == 0)
            x /= 3;
        else
            y /= 3;
        ulonglong z = (n%2 == 0? n / 2 * (n-1): (n-1) / 2 * n);
        z += 1;
        string fn = muladd(x, y, z);
        cout << fn << endl;
    }
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.2.input");
    int t; cin>>t;
    
    double n;
    while (t--)
    {
        cin >> n;
        //cout<< "n = " <<n<<endl;
        //cout << pow(2.0, n-1) << endl; //gotsha wrong formula
        //if(n>4)
        solve4(n);
        //solve3(n);
    }
    
    MoussaInteger * m = new MoussaInteger(0);
    
    //m->display();
    //*/ has same precedence level but first seen first served
    //cout << 6*2/10 << endl << 6/10*2 << endl << 6/2*10 << endl;
    //solve3(pow(2.0, 31)); //max boundry
    //solve(pow(2.0, 31));
    //calc_all_binomial_coeffecients();
    //print_pascal();
    //cout << C(33, 20) << endl;
    return 0;
}

/***
 To do:
 Finish MoussaInteger class that manipulate huge numbers
*/
