#include <iostream>
#include <string>
#include <sstream>

using namespace std;

class MoussaInteger
{
    string val;
public:
    //ctors
    MoussaInteger(){};
    MoussaInteger(long long n)
    {
        if (n > 0)
            this->val = ToMoussaPositiveInteger(n)->val;
        else if (n < 0)
            this->val = ToMoussaNegativeInteger(n)->val;
        else
            this->val = "0";
    };
    
    //Conversion Functions
    MoussaInteger * ToMoussaPositiveInteger(unsigned long long n)
    {
        MoussaInteger * temp = new MoussaInteger();
        while (n > 0)
        {
            int digit = n % 10;
            stringstream ss;
            ss << digit;
            string s; ss >> s;
            temp->val = s + temp->val;
            n = n/10;
        }
        temp->val = '+' + temp->val;
        return temp;
    };
    
    void ToMoussaPositiveInteger(unsigned long long n, MoussaInteger * result)
    {
        MoussaInteger * temp = new MoussaInteger();
        while (n > 0)
        {
            int digit = n % 10;
            stringstream ss;
            ss << digit;
            string s; ss >> s;
            temp->val = s + temp->val;
            n = n/10;
        }
        temp->val = '+' + temp->val;
        result = temp;
    };
    
    string ToMoussaPositiveInteger_String(unsigned long long n)
    {
        string result;
        while (n > 0)
        {
            int digit = n % 10;
            stringstream ss;
            ss << digit;
            string s; ss >> s;
            result = s + result;
            n = n/10;
        }
        result = '+' + result;
        return result;
    };
    
    MoussaInteger * ToMoussaNegativeInteger(long long n)
    {
        n*=-1;
        MoussaInteger * temp = new MoussaInteger();
        while (n > 0)
        {
            int digit = n % 10;
            stringstream ss;
            ss << digit;
            string s; ss >> s;
            temp->val = s + temp->val;
            n = n/10;
        }
        temp->val = '-' + temp->val;
        return temp;
    };
    
    void ToMoussaNegativeInteger(long long n, MoussaInteger * result)
    {
        n*=-1;
        MoussaInteger * temp = new MoussaInteger();
        while (n > 0)
        {
            int digit = n % 10;
            stringstream ss;
            ss << digit;
            string s; ss >> s;
            temp->val = s + temp->val;
            n = n/10;
        }
        temp->val = '-' + temp->val;
        result = temp;
    };
    
    string ToMoussaNegativeInteger_String(long long n)
    {
        n*=-1;
        string result;
        while (n > 0)
        {
            int digit = n % 10;
            stringstream ss;
            ss << digit;
            string s; ss >> s;
            result = s + result;
            n = n/10;
        }
        result = '-' + result;
        return result;
    };
    
    void display()
    {
        cout << this->val << endl;
    };
    
    
};