//////////////////////////////////////////////////////
//
//  6.6.7 Self-describing Sequence
//  PC/UVa IDs: 110607/10049, Popularity: C, Success rate: high Level: 2
//  programming_challenges
//  Created by Moussa on 29-JAN-2015 8:05 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include "InfInt.h"
#include <cstdio>
#include <algorithm>

using namespace std;

long long last[700000] = {0, 1, 3};
int N;
void pre_compute_1()
{
    for (N = 3; last[N - 1] <= 2e9; N++)
        last[N] = last[N - 1] + (lower_bound(last, last + N, N) - last);
};

void solve_1(int n)
{
     cout << lower_bound(last, last + N, n) - last << endl;
};

#define MAXN 1000000
int save [MAXN];
int ind;
void pre_compute_2()
{
    save [1] = 1;
    save [2] = 2;
    save [3] = 4;
    save [4] = 6;
    save [5] = 9;
    save [6] = 12;
    save [7] = 16;
    
    ind = 7;
    for (int indicator = 4; (save[ind - 1] <= 2000001000); indicator++)
     for (int cnt = save [indicator + 1] - save [indicator]; (cnt && save [ind - 1] <= 2000001000); cnt--)
         save [ind] = save [ind - 1] + indicator, ind++;
};

void solve_2(int n)
{
    for (int i = 1; i < ind; i++ )
        if (n < save[i])
            {
                cout << i - 1 << endl;
                break;
            }
};

/*
 * Let g(n) denote the n'th number that satifies f(k) > f(k-1). We can know that
 * g(0) = 1, g(1) = 2, g(2) = 4, ... From the definition of g(n), we can know
 * that all the values of f(k) where k belongs to the range of [g(n-1), g(n)) is n.
 * Since there are exactly f(k) occurrences of k in the sequence, there must be
 * f(1) + f(2) + ... + f(f(k)-1) elements before f(k) if f(k) > f(k-1). Thus, we can
 * know that g(n) = f(1) + f(2) + ... + f(f(k)-1) + 1. In fact f(k)-1 == n, so we
 * have g(n) = f(1) + f(2) + ... + f(n) + 1. Also, we can draw a simple recurrence of
 *   g(n) = g(n-1) + f(n).
 * We have already known that the values of f(k) in the range of [g(n-1), g(n)) is n.
 * So we can compute g(n) in this way:
 * 1. Let g(1) = 2, g(2) = 4, i = 1
 * 2. for n in [g(i), g(i+1)), we know f(n) = i+1, so we can compute g(n) with
 *      g(n) = g(n-1) + (i+1)
 * 3. i = i+1, repeat 2 util g(n) is big enough.
 */

int numbers[700000];
int size = 0;
void pre_compute_3()
{
    int const max_number = 2000000000;
    numbers[0] = 1;
    numbers[1] = 2;
    numbers[2] = 4;
    int i = 1;
    for (; numbers[numbers[i]-1] < max_number; ++i)
        for (int j = numbers[i]; j < numbers[i+1]; ++j)
            numbers[j] = numbers[j-1] + i + 1;
    size = numbers[i] - 1;
};

void solve_3(int n)
{
    cout << upper_bound(numbers, numbers + size, n) - numbers << endl;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.7.input");
    pre_compute_1(); pre_compute_2(); pre_compute_3();
    for(int n; cin >> n && n != 0; solve_1(n), solve_2(n), solve_3(n));
    return 0;
}

/* 
 Notes:
 #10049 - Self-describing Sequence
 
 Solved By:	wesley
 Theory Difficulty:	easy
 Coding Difficulty:	easy
 Algorithms Used:	ad hoc
 math
 Solution Description: 	With bounds like 2,000,000,000, you won't be able to have a solution that runs O(n) for each input. But, you can't store the entire sequence naively with O(n) space either.
 
 Luckily, the sequence is non-decreasing, so it suffices to store the different ranges instead. The sequence starts with:
 
 1 2 2 3 3 4 4 4 5 5 5 6 6 6 6 ...
 
 So you can store the tuples:
 
 <1,1> (1)
 <2,3> (2)
 <4,5> (3)
 <6,8> (4)
 <9,11> (5)
 <12,15> (6)
 ...
 
 Pregenerate all of these tuples. There are around 600,000 of them, so it suffices to search through them linearly for each input.
*/

/*****Approach 3:
 Let g(n) denote the n'th number that satifies f(k) > f(k-1). We can know that
 g(0) = 1, g(1) = 2, g(2) = 4, ...
 From the definition of g(n), we can know that all the values of f(k) where k belongs to the range of [g(n-1), g(n)) is n. Since there are exactly f(k) occurrences of k in the sequence, there must be  f(1) + f(2) + ... + f(f(k)-1) elements before f(k) if f(k) > f(k-1). Thus, we can know that
 g(n) = f(1) + f(2) + ... + f(f(k)-1) + 1.
 In fact f(k)-1 == n, so we have
 g(n) = f(1) + f(2) + ... + f(n) + 1.
 Also, we can draw a simple recurrence of
 g(n) = g(n-1) + f(n).
 We have already known that the values of f(k) in the range of [g(n-1), g(n)) is n. So we can compute g(n) in this way:
 1. Let g(1) = 2, g(2) = 4, i = 1
 2. for n in [g(i), g(i+1)), we know f(n) = i+1, so we can compute g(n) with
 g(n) = g(n-1) + (i+1)
 3. i = i+1, repeat 2 util g(n) is big enough.
*/