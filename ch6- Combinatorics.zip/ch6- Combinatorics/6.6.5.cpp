//////////////////////////////////////////////////////
//
//  6.6.5 Complete Tree Labeling
//  PC/UVa IDs: 110605/10247, Popularity: C, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 26-JAN-2015 5:34 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include "InfInt.h"

using namespace std;

#define MAXK 21
#define MAXD 21

//Branching by Depth
InfInt dp[MAXK + 1][MAXD + 1]; //allocate 1 more place to accomodate for the ZERO in C++ ZERO Based Arrays.

void print()
{
    cout << "DP |";
    for (int j=1; j<= MAXD; j++)
        cout<<setw(7) << j << " ";
    cout << endl;
    
    for (int j=0; j < 8*MAXD+3; j++)
        cout<<"-";
    cout << endl;
    
    for (int i=1; i<=MAXK/2; i++)
    {
        cout<<setw(2) << i <<" |";
        for (int j=1; j<= MAXD/7; j++)
            cout << setw(7) << dp[i][j] << " ";
        cout << endl;
    }
};

void init()
{
    for (int i=0; i<=MAXD; i++)
        for (int j=0; j<= MAXK; j++)
            dp[i][j] = 0;
};

InfInt number_of_nodes[MAXK + 1][MAXD + 1];
void count_number_of_nodes()
{
    for (int i=2; i<=MAXK; i++)
        for (int j=1; j<=MAXD; j++)
        {
            InfInt a = 1;
            InfInt b = j;
            for (int k=1; k<=j+1; k++)
                a*=i;
            
            a-=1;
            InfInt c;
            c = a/(i-1);
            //cout << "i,j = " << i << " " << j << " => " << c << endl << endl;
            number_of_nodes[i][j] = c;
            //InfInt(long(pow(i, j + 1) - 1) / (i - 1))
        }
};

const InfInt max_nodes = number_of_nodes[21][21];

//InfInt factorial[10000000];
map<InfInt, InfInt> factorial;

void count_factorials()
{
    //factorials
    factorial[0] = 1; factorial[1] = 1;
    for (int i=2; i<= max_nodes.toInt(); i++)
        factorial[i] = factorial[i-1] * i;
};

InfInt fact(InfInt n)
{
    InfInt result = 1;
    for (InfInt i=2; i<=n; ++i)
    {
        result *= i;
    }
    return result;
};

int count_number_of_nodes_1(int k, int d)
{
    //total number of nodes for a k-ary tree of depth d = Σ(i = 0 to d) pow(k, i) = (pow(k, d + 1) - 1) / (k - 1).
    int total = 0;
    for (int i = 0; i<=d; i++)
    {
        total+= pow(k, i);
    }
    //cout << "Total Nodes: " << total << endl;
    return total;
};

int count_number_of_nodes_2(int k, int d)
{
    //total number of nodes for a k-ary tree of depth d = Σ(i = 0 to d) pow(k, i)
    //= (pow(k, d + 1) - 1) / (k - 1).
    return (pow(k, d + 1) - 1) / (k - 1);
};

int count_number_of_nodes_3(int k , int d)
{
    unsigned powers[22][22];
    for (int k = 1; k <= 21; ++k)
    {
        powers[k][0] = 1;
        for (int d = 1; d * k <= 21; ++d)
            powers[k][d] = powers[k][d-1] * k;
    }
    
    unsigned nodes[22][22];
    unsigned max_fac = 0;
    for (int k = 1; k <= 21; ++k)
    {
        nodes[k][0] = 1;
        for (int d = 1; d * k <= 21; ++d)
        {
            nodes[k][d] = nodes[k][d-1] + powers[k][d];
            if (nodes[k][d] > max_fac)
                max_fac = nodes[k][d];
        }
    }
    
    return nodes[k][d];
};

InfInt Pascal[MAXK][MAXD];

//MAXN for this function is 10000 after that program will not terminate within seconds
void calc_all_binomial_coeffecients()
{
    for (int i=0; i<MAXK; i++) Pascal[i][0] = 1;
    for (int j=0; j<MAXK; j++) Pascal[j][j] = 1;
    
    for (int i=1; i<MAXK; i++)
        for (int j=1; j<i; j++)
            Pascal[i][j] = Pascal[i-1][j-1] + Pascal[i-1][j];
}

void DP_1()
{
    for (int i=0; i<=MAXK; i++)
        dp[i][0] = 1; //When Depth is 0 which mean there is only 1 node which is the root!
    
    for (int j=0; j<= MAXD; j++)
        dp[0][j] = -1; //When Branching Factor is 0 which means there is no tree at all!
    
    //dp[][1]
    dp[1][1] = 1;
    for (int i=2; i<=MAXK; i++)
        dp[i][1] = dp[i-1][1] * i; //Depth=1 means all nodes are on the same level 1 so equate to factorial
    
    //dp[1][]
    dp[1][1] = 1;
    for (int i=2; i<=MAXD; i++)
        dp[1][i] = 1; //Branching=1 means every node has only one child that equate to 1 way to sequencially labeling them
    
    for (int i=0; i<=MAXD; i++)
        for (int j=0; j<= MAXK; j++)
            ;//dp[i][j] = -1;

};

//using recurrence
// f(k, d) = (n(k, d) - 1)! / (n(k, d-1)!)^k * f(k, d-1)
void DP_2()
{
    for (int k = 1; k <= 21; ++k)
    {
        dp[k][0] = 1;
        for (int d = 1; d * k <= 21; ++d)
        {
            //to power k
            dp[k][d] = dp[k][d-1];
            for (int i = 1; i != k; ++i)
                dp[k][d] *= dp[k][d-1];
            
            dp[k][d] *= fact(number_of_nodes[k][d]-1);
            
            //cout << dp[k][d] << endl;
            /// (n(k, d-1)!)^k
            for (int i = 0; i < k; ++i)
                dp[k][d]/= fact(number_of_nodes[k][d-1]);
        }
    }
};

//Approach 2
map<long, InfInt> cache;
InfInt completeTreeLabeling( int k /* branching factor */, int d /* depth */)
{
    if (k == 1 || d == 0)
        return 1;
    
    long kd = (long) k << 32 | d;
    if (cache.find(kd) != cache.end())
        return cache[kd];
    
    InfInt num_labeling = fact(k);
    if (d > 1)
    {
        // number of descendants of the root node for a k-ary tree of depth (d - 1)
        InfInt num_descendants = number_of_nodes[k][d - 1] - 1;
        
        // number of labeling for a k-ary tree of depth (d - 1)
        InfInt num_descendant_labeling = completeTreeLabeling(k, d - 1);
        
        //i from number of nodes for a k-ary tree of depth d .. to descendants number
        for (int i = number_of_nodes[k][d].toInt() - 2; i >= num_descendants.toInt(); i -= num_descendants.toInt() + 1)
            num_labeling *= Pascal[i][num_descendants.toInt()] * num_descendant_labeling;
    }
    
    return cache[kd] = num_labeling; //memoize and return
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.5.input");
    
    int k = 0; /*branching factor*/
    int d = 0; /*the depth of the complete k-ary tree*/;
    
    init();
    count_number_of_nodes();
    calc_all_binomial_coeffecients();
    
    //clock_t st1 = clock();
    
    DP_2();
    
    //cout << double (clock() - st1 / CLOCKS_PER_SEC) << "seocnds" << endl;
    
    //print();
    //cout << "Max Nodes#: " << number_of_nodes[21][21].toString() << " " << (pow(21, 21 + 1) - 1) / (21 - 1) << endl;
    
    for (; cin>>k>>d; )
    {
        //factorial[number_of_nodes[k][d].toInt()] = fact(number_of_nodes[k][d]);
        
        //cout << "Nodes#: " << number_of_nodes[k][d] << " sol: " << dp[k][d] << endl;
        cout << dp[k][d] << endl;
        
        //clock_t st = clock();
        
        //cout << completeTreeLabeling(k,d) << endl;
        
        //cout << double (clock() - st / CLOCKS_PER_SEC) << "seocnds" << endl;
    }
    
    return 0;
}

/***
    1] total number of nodes for a k-ary tree of depth d = Σ(i = 0 to d) pow(k, i) = (pow(k, d + 1) - 1) / (k - 1).
    2] number of nodes at the i-th level of depth = pow(k, i), each of which has pow(k, i + 1) nodes.
 
 //Approach 1:
            Let f(k, d) denote the number of labelings of the k-ary tree of depth d. Moreover, let n(k, d) denote the number of nodes of the tree. The tree contains k subtrees, each contains n(k, d-1) nodes. There are totally  (n(k, d) - 1)! / (n(k, d-1)!)^k ways to partition the n(k, d) - 1 labels into k different subsets, each have the same size of n(k, d-1), therefore  we can draw this recurrence:
            
            f(k, d) = (n(k, d) - 1)! / (n(k, d-1)!)^k * f(k, d-1)
            
            with base cases of
            f(k, 0) = 1
 
 //Approach 2:
 
 
 */