//////////////////////////////////////////////////////
//
//  6.6.4 Expressions
//  PC/UVa IDs: 110604/10157, Popularity: C, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 17-JAN-2015 12:42 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include "bignum.txt"

using namespace std;

// need to include <string>
class mybigint {
    friend ostream &operator<<(ostream& os, const mybigint& b) {
        os << b.value ;
        return os;
    }
    friend istream &operator>>(istream& is, mybigint& b) {
        is >> b.value ;
        while( b.value[ 0 ] == '0' && b.value.length() > 1 ) b.value.erase( 0, 1 ) ;
        return is;
    }
    
public:
    string value;
    
    mybigint() {
        value.assign( "0" ) ;
    }
    
    const mybigint &operator=( unsigned int x ) {
        value.assign( 1, '0' + x % 10 ) ;
        x /= 10 ;
        while( x != 0 )
        {
            value.insert( 0, 1, x % 10 + '0' ) ;
            x /= 10 ;
        }
        return *this ;
    }
    
    const mybigint &operator=( const mybigint &x ) {
        value = x.value ;
        return *this ;
    }
    
    mybigint operator+(const mybigint &x) {
        mybigint	sum ;
        int		buffer = 0 ;
        int		carryIn = 0 ;
        int		i = 0 ; // loop counter
        int		j = 0 ; // loop counter
        
        if( value.length() < x.value.length() )
        {
            sum.value = string( x.value.length() - value.length(), '0' ) + value ;
        }
        else
        {
            sum.value = value ;
        }
        
        // add x.value into returnValue
        for( 	i = x.value.length() - 1, j = sum.value.length() - 1 ;
            i >= 0 ;
            i--, j-- )
        {
            buffer = ( sum.value[ j ] - '0' ) + ( x.value[ i ] - '0' ) + carryIn ;
            if( buffer >= 10 )
            {
                sum.value[ j ] = buffer - 10 + '0' ;
                carryIn = 1 ;
            }
            else
            {
                sum.value[ j ] = buffer + '0' ;
                carryIn = 0 ;
            }
        }
        
        if( carryIn > 0 )
        {
            while( j >= 0 )
            {
                if( sum.value[ j ] == '9' )
                {
                    sum.value[ j ] = '0' ;
                }
                else
                {
                    sum.value[ j ] += 1 ;
                    break ;
                }
                j-- ;
            }
            if( j < 0 )
            {
                sum.value.insert( 0, 1, '1' ) ;
            }
        }
        return sum ;
    }
    
    mybigint& operator+=( const mybigint &x ){
        *this = *this + x ;
        return *this ;
    }
    
    mybigint operator+(unsigned int x) {
        mybigint mybigintX ;
        mybigintX = x ;
        mybigintX = *this + mybigintX ;
        return mybigintX ;
    }
    
    mybigint operator*(const mybigint& x) {
        mybigint	multiValue[ 10 ] ;
        mybigint	multiply ;
        int		i = 0 ;
        
        multiValue[ 0 ] = 0 ;
        for( i = 1 ; i < 10 ; i++ )
        {
            multiValue[ i ] = multiValue[ i - 1 ] + *this ;
        }
        
        multiply = 0 ;
        for( i = 0 ; i < x.value.length() ; i++ ) {
            // mult multiply with 10
            if( multiply.value[ 0 ] != '0' )
            {
                multiply.value.insert( multiply.value.length(), 1, '0' ) ;
            }
            multiply = multiply + multiValue[ x.value[ i ] - '0' ] ;
        }
        return multiply;
    }
    
    mybigint &operator*=(const mybigint& x) {
        *this = *this * x ;
        return *this ;
    }
    
    mybigint operator*(unsigned int x) {
        mybigint mybigintX ;
        mybigintX = x ;
        return *this * mybigintX ;
    }
};

// need to include <sstream>, <iomanip>, <cstdlib>, <algorithm>
class bigint {
    friend ostream& operator<<(ostream& os, const bigint& b) {
        using std::ostringstream ;
        ostringstream buffer ;
        buffer << b.v[b.size-1] ;
        for(int i=b.size-2; i>=0; i--)
            buffer << setw(Ndigit) << setfill('0') << b.v[ i ] ;
        os << buffer.str() ;
        return os;
    }
    friend istream& operator>>(istream& is, bigint& b) {
        string	input ;
        int		i = 0 ;
        is >> input ;
        input.insert( input.length(), 1, '\0') ;
        while( input[ 0 ] == '0' && input[ 1 ] != '\0' )	input.erase( 0, 1 ) ;
        memset(b.v, 0, sizeof(b.v));
        for( i=input.length() - Ndigit - 1, b.size = 0 ; i>=0; i-=Ndigit, (b.size) += 1 )
        {
            b.v[ b.size ] = atoi( input.c_str() + i ) ;
            input[ i ] = '\0' ;
        }
        if( i + Ndigit != 0 )
        {
            b.v[ b.size ] = atoi( input.c_str() ) ;
            (b.size) += 1 ;
        }
        return is;
    }
    
public:
    unsigned int v[10];
    int size;
    static const unsigned int N, Ndigit;
    
    bigint(int x)
    {
        memset(v, 0, sizeof(v));
        v[0] = x % N , size = 1 , x /= N ;
        while( x != 0 ) v[ size ] = x % N, size++, x /= N ;
    }
    
    bigint()
    {
        memset(v, 0, sizeof(v));
        size = 1;
    }
    
    bigint& operator=( const bigint& x )
    {
        memset(v, 0, sizeof(v));
        copy( x.v, x.v + x.size, v ) ;
        size = x.size ;
        return *this ;
    }
    
    bigint& operator=( unsigned int x )
    {
        memset(v, 0, sizeof(v));
        v[0] = x % N , size = 1 , x /= N ;
        while( x != 0 ) v[ size ] = x % N, size++, x /= N ;
        return *this ;
    }
    
    bigint operator+(const bigint& x)
    {
        bigint sum = 0 ;
        long long int carry = 0 ;
        int i = 0 ;
        for( i = 0; i < x.size || i < size ; i++)
        {
            carry += v[ i ] + x.v[i] ;
            if( carry >= N )
            {
                sum.v[ i ] = carry - N , carry = 1 ;
            }
            else
            {
                sum.v[ i ] = carry, carry = 0 ;
            }
        }
        if( carry > 0 )
        {
            sum.v[ i ] = carry, i += 1 ;
        }
        sum.size = i;
        return sum ;
    }
    
    bigint& operator+=(const bigint& x)
    {
        *this = *this + x ;
        return *this;
    }
    
    bigint operator*(unsigned int x) const
    {
        bigint multiply = 0 ;
        if( x == 0 ) return multiply ;
        int i = 0 ;
        long long int carry = 0;
        for(i=0; i<size; i++) {
            carry += (long long int)v[i] * x;
            multiply.v[i] = carry%N;
            carry /= N;
        }
        while(carry>0) multiply.v[i] = carry%N, carry /= N, i++ ;
        multiply.size = i ;
        return multiply;
    }
    
    bigint& operator*=(unsigned int x)
    {
        *this = *this * x ;
        return *this;
    }
    
    bigint operator*(const bigint& x) const
    {
        bigint multiply = 0 ;
        int i = 0 ;
        if( x.size <= size )
        {
            for(i=x.size - 1; i>=0 ; i--)
            {
                multiply *= N ;
                multiply += *this * x.v[ i ] ;
            }
        }
        else
        {
            for(i=size - 1; i>=0 ; i--)
            {
                multiply *= N ;
                multiply += x * v[ i ] ;
            }
        }
        
        return multiply ;
    }
    
    bigint& operator*=(const bigint& x)
    {
        *this = *this * x ;
        return *this;
    }
};

#define MAXN 20
int n = 0;
int dp[MAXN+1][MAXN+1]; //n by depth

//return the depth of a balanced parenthesis expression p
unsigned long depth(string p)
{
    stack<char> st;
    unsigned long max_size = 0;
    for (int i=0; i<p.size(); i++)
    {
        if (p[i] == '(')
            st.push('(');
        else if(p[i] == ')')
            st.pop();
        
        if(st.size() > max_size)
            max_size = st.size();
    }
    
    return max_size;
};

//return true if a parenthesis expression p is balanced
bool is_balanced(string p)
{
    stack<char> st;
    for (int i=0; i<p.size(); i++)
    {
        if (p[i] == '(')
            st.push('(');
        else if(p[i] == ')' && st.size() > 0)
                st.pop();
            else
                return false;
    }
    
    return (st.size() == 0)? true : false;
};

//generate all balanced parenthesis of length len
void generate_parenthesis(string s, int len)
{
    if (len == 0)
    {
        if(is_balanced(s))
        {
            unsigned long d = depth(s);
            //cout << d << " : " << s << endl;
            dp[n][d]++;
        }
    }
    else
    {
        s[len-1] = '(';
        generate_parenthesis( s, len - 1);
        s[len-1] = ')';
        generate_parenthesis( s, len - 1);
    }
};


void print_dp()
{
    cout << "Dep:";
    for (int j=1; j<= MAXN/2; j++)
        cout<<setw(5) << j << " ";
    cout << endl << "---------------------------------------------------------------" << endl;
    
    for (int i=2; i<=MAXN; i+=2)
    {
      cout<<setw(2) << i <<" |";
      for (int j=1; j<= MAXN/2; j++)
         if(dp[i][j] != 0)
            cout << setw(5) << dp[i][j] << " ";
      cout << endl;
    }
};


//F(n, d) = E {i: 2 -> n-2, i += 2: f(i, d-1) * f(n-i, d)}
int countp(int n, int d)
{
    int sum = 1;
    for (int i = 2; i< n-2; i+=2)
         sum*= (dp[i][d-1] * dp[n-i-1][d]);
    
    dp[n][d] = sum;
    return sum;
};

/*
long long expression[N+1][N+1];

long long expressionLEtoD[N+1][N+1];
*/

#define MaxN 300
#define MaxD 150

const unsigned int bigint::N = 1000000000;
const unsigned int bigint::Ndigit=9;

// expression[ n ][ d ] expressions of length n and depth d.
// method of calculate expression[ n ][ d ] is
// expression[ n ][ d ] = ??
bigint	expression[ MaxN + 1 ][ MaxD + 1 ] ;

// expressionLEtoD[ n ][ d ] expressions of length n and depth less than or equal to d.
// method of calculate expressionLEtoD[ n ][ d ] is
// expressionLEtoD[ n ][ d ] = expressionLEtoD[ n ][ d - 1 ] + expression[ n ][ d ]
bigint	expressionLEtoD[ MaxN + 1 ][ MaxD + 1 ] ;

//approach 2
void prepare_expression()
{
    // when n = 0
    for( int d = 0 ; d <= MaxD ; d++ )
    {
        expression[ 0 ][ d ] = 1 ;
        expressionLEtoD[ 0 ][ d ] = 1 ;
    }
    
    //only even numbers because we care only for balanced
    for( int n = 2 ; n <= MaxN ; n += 2 )
    {
        expression[ n ][ 1 ] = 1 ;
        expressionLEtoD[ n ][ 1 ] = 1 ;
        for( int d = 2 ; d <= MaxD ; d++ )
        {
            // calculate expression[ n ][ d ]
            for( int i = 2 ; i <= n - d * 2 ; i += 2 )
                expression[n][d] += expression[n - i][d] * expressionLEtoD[i - 2][d - 2];
        
            for( int i = d * 2 ; i <= n ; i += 2 )
                expression[n][d] += expression[i - 2][d - 1] * expressionLEtoD[n - i][d];
            
            // calculate expressionLEtoD[ n ][ d ]
            expressionLEtoD[ n ][ d ] = expressionLEtoD[ n ][ d - 1 ] + expression[ n ][ d ] ;
        }
    }
};

void print_expression()
{
    cout << "Dep:";
    for (int j=1; j<= MAXN/2; j++)
        cout<<setw(5) << j << " ";
    cout << endl << "---------------------------------------------------------------" << endl;
    
    for (int i=2; i<=MAXN; i+=2)
    {
        cout<<setw(2) << i <<" |";
        for (int j=1; j<= MAXN/2; j++)
                cout << setw(5) << expression[i][j] << " ";
        cout << endl;
    }
};

//solve using approach 1 using recurrence F (n, d) = E {i: 2 -> n-2, i += 2: f(i, d-1) * f(n-i, d)}
void init(int n, int D)
{
    long long result[n+1][D+1];
    for (int m = 0; m < n+1; m++)
        for (int j = 0; j < D+1; j++)
            result[m][j] = 0;
    
    for (int i = 0; i < D+1; i++)
        result[0][i] = 1;
    
    for (int m = 1; m < n+1; m++)
        for (int d = 1; d < D+1; d++)
        {
            for (int k = 0; k <= m - 1; k++)
                result[m][d] += result[k][d - 1] * result[m - k - 1][d];
        }
    
    cout << result[n / 2][D] - result[n / 2][D - 1] << endl;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.4.input");
    
    for (int i=0; i<MAXN; i++)
         for (int j=0; j<MAXN; j++)
             dp[i][j] = 0;

    //cout << depth("()(())()") << endl;
    
    for (int i=0; i<=MAXN; i+=2)
    {
        n = i;
        string s = "";
        s.resize(i);
        generate_parenthesis(s, i);
    }
    
    //print();
    //cout << countp(16, 5) << endl;
    
    //clock_t temp = clock();
    prepare_expression(); //print_expression();
    //cout << double(clock() - temp) / CLOCKS_PER_SEC << " Seconds" << endl;
    
    //init(300,120);
    //solve
    cout << expression[ 290 ][ 50 ] << endl;
    for (int n,d; cin>>n>>d; cout << expression[ n ][ d ] << endl);
    //init(n,d);
    
    return 0;
}

/***
 Approach 1 Notes :
 * Let n denotes the length of the expression, d denotes the depth at most,
 * And the count is f (n, d). Obviously, f (n, d) = 0 when n is odd. For other
 * Conditions, let us consider where we can find the corresponding
 * Parenthesis of the leftmost one. It can be only found at the even places.
 * For place 2, this yields f (2, d-1) * f (n-2, d) ways of correctly built
 * Expressions. And for place 4, the number will be f (4, d-1) * f (n-4, d).
 * So we can draw this recurrence from the above observation
 * F (n, d) = E {i: 2 -> n-2, i += 2: f(i, d-1) * f(n-i, d)}
 * And and base cases are
 * F (0, d) = 1 where d> = 0
 */