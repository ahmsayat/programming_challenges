//
//  bigint.cpp
//  programming_challenges
//
//  Created by Moussa on 1/26/15.
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//

#include "bigint.h"

// need to include <sstream>, <iomanip>, <cstdlib>, <algorithm>
class bigint {
    friend ostream& operator<<(ostream& os, const bigint& b) {
        using std::ostringstream ;
        ostringstream buffer ;
        buffer << b.v[b.size-1] ;
        for(int i=b.size-2; i>=0; i--)
            buffer << setw(Ndigit) << setfill('0') << b.v[ i ] ;
        os << buffer.str() ;
        return os;
    }
    
    friend istream& operator>>(istream& is, bigint& b) {
        string	input ;
        int		i = 0 ;
        is >> input ;
        input.insert( input.length(), 1, '\0') ;
        while( input[ 0 ] == '0' && input[ 1 ] != '\0' )	input.erase( 0, 1 ) ;
        memset(b.v, 0, sizeof(b.v));
        for( i=input.length() - Ndigit - 1, b.size = 0 ; i>=0; i-=Ndigit, (b.size) += 1 )
        {
            b.v[ b.size ] = atoi( input.c_str() + i ) ;
            input[ i ] = '\0' ;
        }
        if( i + Ndigit != 0 )
        {
            b.v[ b.size ] = atoi( input.c_str() ) ;
            (b.size) += 1 ;
        }
        return is;
    }
    
public:
    unsigned int v[10];
    int size;
    static const unsigned int N, Ndigit;
    
    bigint(int x)
    {
        memset(v, 0, sizeof(v));
        v[0] = x % N , size = 1 , x /= N ;
        while( x != 0 ) v[ size ] = x % N, size++, x /= N ;
    }
    
    bigint()
    {
        memset(v, 0, sizeof(v));
        size = 1;
    }
    
    bigint& operator=( const bigint& x )
    {
        memset(v, 0, sizeof(v));
        copy( x.v, x.v + x.size, v ) ;
        size = x.size ;
        return *this ;
    }
    
    bigint& operator=( unsigned int x )
    {
        memset(v, 0, sizeof(v));
        v[0] = x % N , size = 1 , x /= N ;
        while( x != 0 ) v[ size ] = x % N, size++, x /= N ;
        return *this ;
    }
    
    bigint operator+(const bigint& x)
    {
        bigint sum = 0 ;
        long long int carry = 0 ;
        int i = 0 ;
        for( i = 0; i < x.size || i < size ; i++)
        {
            carry += v[ i ] + x.v[i] ;
            if( carry >= N )
            {
                sum.v[ i ] = carry - N , carry = 1 ;
            }
            else
            {
                sum.v[ i ] = carry, carry = 0 ;
            }
        }
        if( carry > 0 )
        {
            sum.v[ i ] = carry, i += 1 ;
        }
        sum.size = i;
        return sum ;
    }
    
    bigint& operator+=(const bigint& x)
    {
        *this = *this + x ;
        return *this;
    }
    
    bigint operator*(unsigned int x) const
    {
        bigint multiply = 0 ;
        if( x == 0 ) return multiply ;
        int i = 0 ;
        long long int carry = 0;
        for(i=0; i<size; i++) {
            carry += (long long int)v[i] * x;
            multiply.v[i] = carry%N;
            carry /= N;
        }
        while(carry>0) multiply.v[i] = carry%N, carry /= N, i++ ;
        multiply.size = i ;
        return multiply;
    }
    
    bigint& operator*=(unsigned int x)
    {
        *this = *this * x ;
        return *this;
    }
    
    bigint operator*(const bigint& x) const
    {
        bigint multiply = 0 ;
        int i = 0 ;
        if( x.size <= size )
        {
            for(i=x.size - 1; i>=0 ; i--)
            {
                multiply *= N ;
                multiply += *this * x.v[ i ] ;
            }
        }
        else
        {
            for(i=size - 1; i>=0 ; i--)
            {
                multiply *= N ;
                multiply += x * v[ i ] ;
            }
        }
        
        return multiply ;
    }
    
    bigint& operator*=(const bigint& x)
    {
        *this = *this * x ;
        return *this;
    }
};