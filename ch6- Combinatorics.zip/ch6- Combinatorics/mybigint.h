//
//  mybigint.h
//  programming_challenges
//
//  Created by Moussa on 1/26/15.
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//

#ifndef __programming_challenges__mybigint__
#define __programming_challenges__mybigint__

#include <stdio.h>
#include <fstream>

using namespace std;

#endif /* defined(__programming_challenges__mybigint__) */
