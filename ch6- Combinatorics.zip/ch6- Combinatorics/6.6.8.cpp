//////////////////////////////////////////////////////
//
//  6.6.8 Steps
//  PC/UVa IDs: 110608/846, Popularity: A, Success rate: high Level: 2
//  programming_challenges
//  Created by Moussa on 29-JAN-2015 9:00 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include "InfInt.h"
#include <cstdio>
#include <algorithm>

using namespace std;

void solve_1(int a, int b)
{
        int c = (int) round(sqrt(b - a));
        cout << 2 * c - (c && c * c >= b - a) << endl;
};

void solve_2(int x, int y)
{
    if (x == y)
    {
        cout << 0 << endl;
        return;
    }
    
    int n = (int)sqrt(y - x);
    
    if (n * n == y - x)
        n = 2 * n - 1;
    else
        if (n * (n + 1) < y - x)
        {
            n = 2 * n + 1;
        }
        else
            n = 2 * n;
    
    printf("%d\n", n); //cout << n << endl;
};

void solve_3(int x, int y)
{
    int sum=y-x;
    int lol=sqrt(sum),result=0;
    if(sum==0){
        result=0;
    }else if(lol*lol==sum){
        result=lol*2-1;
    }else if(lol*lol+lol<sum){
        result=lol*2+1;
    }else{
        result=lol*2;
    }
    printf("%d\n",result);
};

void solve_4(int x, int y)
{
    int difference = y - x;
    int min_steps = 0;

    if(difference != 0)
    {
        int sumOfSteps = 0;
        int z = 2; //divided by 2, it represents the size if the next step
        
        while(difference > sumOfSteps)
        {
            sumOfSteps += (z / 2); //next step
            min_steps++;
            z++;
        }
    }
    
    cout<<min_steps<<endl;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.8.input");
    
    int T; cin>>T;
    for(int a, b; T-- && cin >> a >> b; solve_1(a,b)/*, solve_2(a,b), solve_3(a,b), solve_4(a,b)*/);
    return 0;
}

/* 
 Notes 1:
 
 Solved By:	wesley
 Theory Difficulty:	easy
 Coding Difficulty:	easy
 Algorithms Used:	ad hoc
 math
 Solution Description: 	If we plot out the first few series of steps, we can see a pattern:
 
 1 *
 11 *
 111
 121 *
 1211
 1221 *
 12121
 12221
 12321 *
 
 The starred sequences are the ones that cannot be expanded without adding anoter character. Look at them separately:
 
 1 (sum = 1)
 11 (sum = 2)
 121 (sum = 4)
 1221 (sum = 6)
 12321 (sum = 9)
 
 Let a[i] be the furthest distance you can go with i steps. Assuming i is 0-indexed:
 
 a[0] = 0
 a[i] = a[i-1] + (i+1)/2
 
 For each input, take the difference between the two points, binary search a[] for this difference, and return the index of the smallest element that is greater than or equal to the difference.

*/

/*
 Notes 2: http://www.algorithmist.com/index.php/UVa_846
 
 Summary:
 An ad hoc math quiz.
 
 Explanation:
 First, the start and end numbers do not really matter. So we can assume the start number is always 0. 
 Given the number of steps, it is not hard to find out the maximum number we can reach using the steps. 
 The results for the first few steps are shown below.
 
 steps   max_reachable_number    increase
 0       0  (0)
 1       1  (1)                  +1
 2       2  (11)                 +1
 3       4  (121)                +2
 4       6  (1221)               +2
 5       9  (12321)              +3
 6       12 (123321)             +3
 7       16 (1234321)            +4
 8       20 (12344321)           +4
 
 Thus the function from the number of steps to the maximum reachable number is f(2n)=n(n+1) for even steps, and f(2n+1)=(n+1)^{2} for odd steps. 
 The numbers from f(k-1)+1 to f(k) can be reached by using k steps, but not by using less than k steps (proof ignored). 
 The solution to this problem is really about writing the inverse function of f.
 An O(1) algorithm can be obtained.
 
 Gotchas:
 Probably need to take special care of the trivial case in which the start and end numbers are the same.
 
 Input[edit]
 4
 45 45
 45 48
 45 49
 45 50
 
 Output[edit]
 0
 3
 3
 4
 */

