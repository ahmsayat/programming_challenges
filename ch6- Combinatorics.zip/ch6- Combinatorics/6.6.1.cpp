//////////////////////////////////////////////////////
//
//  6.6.1 How Many Fibs?
//  PC/UVa IDs: 110601/10183, Popularity: B, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 16-JAN-2015 5:56 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

//This is the largest N for a fibonacci after that Fib(n) will be INF
//Fib[1475] = 1.30699e+308 which represest the largest number a double can hold.
#define MAXN 1476

double Fib[MAXN];

void calc_all_possible_fibonacci()
{
    Fib[1] = 1;
    Fib[2] = 2;
    
    for (int i=3; i<=MAXN; i++)
        Fib[i] = Fib[i-1] + Fib[i-2];
    
    //for (int i=1; i<=MAXN; i++) cout << Fib[i] << endl;
}

void print_fibonacci()
{
    double a = 1, b = 2, c, t;
    cout << a << endl << b << endl;

    for (int i=1; i<=1474; i++)
    {
        c = a + b;
        
        cout << c << endl;
        t = a;
        a = b;
        b = t + b;
    }
}

int count_fib_in_range(double a, double b)
{
    int cnt = 0;
    for (int i=1; i<=MAXN; i++)
        if (Fib[i] >= a && Fib[i] <= b)
            cnt++;
    return cnt;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.1.input");
    
    calc_all_possible_fibonacci();
    
    double A, B;
    while (cin >> A >> B && A != 0)
    {
        int cnt = count_fib_in_range(A, B);
        cout << cnt << endl;
    }
    
    return 0;
}
