//////////////////////////////////////////////////////
//
//  6.6.6 The Priest Mathematician
//  PC/UVa IDs: 110606/10254, Popularity: C, Success rate: high Level: 2
//  programming_challenges
//  Created by Moussa on 27-JAN-2015 6:29 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include "InfInt.h"

using namespace std;

#define MAXN 10000

//The four towers of hanoi
//stack<int> tower[4];
vector<stack<int>> tower;
int cnt;
void print()
{
    for(int i=0; i<4; i++)
    {
        stack<int> temp;
        
        cout<<i<<"= ";
        
        while (!tower[i].empty())
        {
            int d = tower[i].top();
            cout<<setw(1)<<d<<"[";
            temp.push(d);
            tower[i].pop();
        }
        
        while (!temp.empty())
        {
            tower[i].push(temp.top()); temp.pop();
        }
        
        cout<<endl;
    }
    
    cout<<endl;
}

void move_top(int from, int to)
{
    //validation checks
    if (tower[from].empty())
        return;
    if ((tower[to].empty() == false) && (tower[from].top() > tower[to].top()))
        return;
    
    //move the disk
    tower[to].push(tower[from].top());
    tower[from].pop();
    //print();
    cnt++;
};

void hanoi(int n, int from, int tmp, int dst)
{
    if (n>0)
    {
        hanoi(n-1, from, dst, tmp);
        move_top(from, dst);
        hanoi(n-1, tmp, from, dst);
    }
};

void init(int N)
{
    for (int i=0; i<tower.size(); i++)
        tower[i] = stack<int>();
    
    for (int i=N; i>0; i--)
    {
        tower[0].push(i);
        //tower[1].push(i);
        //tower[2].push(i);
    }
};


/*
 * From the description of this problem we can easily draw the recurrence of
 *   f(n) = 2*f(n-k) + 2^k - 1
 * and the base cases of
 *   f(0) = 0 and f(1) = 1
 * However, how can we determine which k would give the minimum value of f(n)?
 * Suppose k is giving the minimum value, then it must satisfy
 *   2*f(n-k) + 2^k - 1 <= 2*f(n-(k+1)) + 2^(k+1) - 1,
 * which can be deduced to
 *   f(n-k) - f(n-k-1) <= 2^(k-1).
 * Thus, let d(n) = f(n) - f(n-1), and we can use d(n) to determine the value
 * of k through the inequality of
 *   d(n-k) <= 2^(k-1)
 * and the fact that d(n) is a non-decreasing sequence.
 */

int const size = 10001;
InfInt numbers[size];
InfInt pow2[1500];
InfInt diff[size];

void gen_numbers()
{
    //compute all powers of two
    pow2[0] = 1;
    for (int n = 1; n < 1500; ++n)
        pow2[n] = pow2[n-1] * 2;
    
    //use recurrence f(n) = 2*f(n-k) + 2^k - 1 with the base cases of f(0) = 0 and f(1) = 1
    numbers[0] = 0, numbers[1] = 1;
    
    diff[0] = 0, diff[1] = 1;
    
    int k = 1;
    for (int n = 2; n < size; ++n)
    {
        if (diff[n-k] > pow2[k-1])
            ++k;
        
        /*
        numbers[n] = numbers[n-k] * 2);
        numbers[n] += pow2[k];
        numbers[n] -= 1;
        */
        
        numbers[n] = (numbers[n-k] * 2) + pow2[k] - 1;
        
        diff[n] = numbers[n] - numbers[n-1];
    }
};

// steps
#define MAXDISKS 10001
InfInt steps[MAXDISKS];

// ?2  m  ?m + 1? ?
void hanoi()
{
    InfInt exponent = 1;
    steps[0] = 0;
    for (int index = 1, sequence = 1; index < MAXDISKS; (sequence++, exponent *= 2))
        for (int start = 1; (start <= sequence && index < MAXDISKS); (start++, index++))
            steps[index] = steps[index - 1] + exponent;
};

void print_steps()
{
    for (int i=0; i<MAXDISKS; i++)
        cout << steps[i] << endl;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.6.input");
    
    gen_numbers();
    hanoi();
    //print_steps();
    
    for (int N; cin >> N; cout << numbers[N] <<endl) ;//cout << steps[N] << endl;
    return 0;
    
    int N;
    tower.resize(4);
    while (cin >> N)
    {
        cnt = 0;
        cout << N << endl;
        tower.clear();
        init(N);
        
        //print();
        hanoi(N, 0, 1, 2);
        //print();
        cout << cnt << " transfers " << endl;
    }
    
    return 0;
}

/***Notes:
 From the description of this problem we can easily draw the recurrence of
 f(n) = 2*f(n-k) + 2^k - 1
 and the base cases of
 f(0) = 0 and f(1) = 1
 However, how can we determine which k would give the minimum value of f(n)?
 Suppose k is giving the minimum value, then it must satisfy
 2*f(n-k) + 2^k - 1 <= 2*f(n-(k+1)) + 2^(k+1) - 1,
 which can be deduced to
 f(n-k) - f(n-k-1) <= 2^(k-1).
 Thus, let d(n) = f(n) - f(n-1), and we can use d(n) to determine the value
 of k through the inequality of
 d(n-k) <= 2^(k-1)
 and the fact that d(n) is a non-decreasing sequence.

 */

/*
 2*f(n-k) + 2^k  <= 2*f(n-(k+1)) + 2^(k+1)
 
 2*f(n-k)  -  2*f(n-k-1)  <= 2^(k+1) - 2^k      over 2
 f(n-k)  -  f(n-k-1)  <= 2^(k) - 2^(k-1)   common factor
 f(n-k)  -  f(n-k-1)  <= 2^(k-1) ( 2 - 1)  times 1
 f(n-k)  -  f(n-k-1)  <= 2^(k-1)
 
 let d(n) = f(n)  -  f(n-1)
 so d(n-k) = f(n-k)  -  f(n-k-1)
 
 d(n-k) <= 2^(k-1)
*/
