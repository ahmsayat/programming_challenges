//
//  mybigint.cpp
//  programming_challenges
//
//  Created by Moussa on 1/26/15.
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//

#include "mybigint.h"

// need to include <string>
class mybigint
{
    friend ostream &operator<<(ostream& os, const mybigint& b) {
        os << b.value ;
        return os;
    }
    friend istream &operator>>(istream& is, mybigint& b) {
        is >> b.value ;
        while( b.value[ 0 ] == '0' && b.value.length() > 1 ) b.value.erase( 0, 1 ) ;
        return is;
    }
    
public:
    string value;
    
    mybigint()
    {
        value.assign( "0" ) ;
    }
    
    
    const mybigint &operator=(int x)
    {
        if (x>=0)
        {
            value.assign( 1, '0' + x % 10 ) ;
            x /= 10 ;
            while( x != 0 )
            {
                value.insert( 0, 1, x % 10 + '0' ) ;
                x /= 10 ;
            }
            return *this ;
        }
        else
        {
            x *= -1;
            value.assign( 1, '0' + x % 10 ) ;
            x /= 10 ;
            while( x != 0 )
            {
                value.insert( 0, 1, x % 10 + '0' ) ;
                x /= 10 ;
            }
            value = '-' + value;
            return *this ;
        }
    }
    
    const mybigint &operator=( const mybigint &x ) {
        value = x.value ;
        return *this ;
    }
    
    mybigint operator+(const mybigint &x) {
        mybigint	sum ;
        int		buffer = 0 ;
        int		carryIn = 0 ;
        int		i = 0 ; // loop counter
        int		j = 0 ; // loop counter
        
        if( value.length() < x.value.length() )
        {
            sum.value = string( x.value.length() - value.length(), '0' ) + value ;
        }
        else
        {
            sum.value = value ;
        }
        
        // add x.value into returnValue
        for( 	i = x.value.length() - 1, j = sum.value.length() - 1 ;
            i >= 0 ;
            i--, j-- )
        {
            buffer = ( sum.value[ j ] - '0' ) + ( x.value[ i ] - '0' ) + carryIn ;
            if( buffer >= 10 )
            {
                sum.value[ j ] = buffer - 10 + '0' ;
                carryIn = 1 ;
            }
            else
            {
                sum.value[ j ] = buffer + '0' ;
                carryIn = 0 ;
            }
        }
        
        if( carryIn > 0 )
        {
            while( j >= 0 )
            {
                if( sum.value[ j ] == '9' )
                {
                    sum.value[ j ] = '0' ;
                }
                else
                {
                    sum.value[ j ] += 1 ;
                    break ;
                }
                j-- ;
            }
            if( j < 0 )
            {
                sum.value.insert( 0, 1, '1' ) ;
            }
        }
        return sum ;
    }
    
    mybigint& operator+=( const mybigint &x ){
        *this = *this + x ;
        return *this ;
    }
    
    mybigint operator+(unsigned int x) {
        mybigint mybigintX ;
        mybigintX = x ;
        mybigintX = *this + mybigintX ;
        return mybigintX ;
    }
    
    mybigint operator*(const mybigint& x) {
        mybigint	multiValue[ 10 ] ;
        mybigint	multiply ;
        int		i = 0 ;
        
        multiValue[ 0 ] = 0 ;
        for( i = 1 ; i < 10 ; i++ )
        {
            multiValue[ i ] = multiValue[ i - 1 ] + *this ;
        }
        
        multiply = 0 ;
        for( i = 0 ; i < x.value.length() ; i++ ) {
            // mult multiply with 10
            if( multiply.value[ 0 ] != '0' )
            {
                multiply.value.insert( multiply.value.length(), 1, '0' ) ;
            }
            multiply = multiply + multiValue[x.value[i] - '0' ] ;
        }
        return multiply;
    }
    
    mybigint &operator*=(const mybigint& x) {
        *this = *this * x ;
        return *this ;
    }
    
    bool operator==(const mybigint& x)
    {
        return *this == x;
    }
    
    bool operator!=(const mybigint& x)
    {
        return !(*this == x);
    }
    
    bool operator==(const int x)
    {
        return *this == x;
    }
    
    bool operator!=(const int x)
    {
        return !(*this == x);
    }
    
    mybigint operator*(unsigned int x) {
        mybigint mybigintX ;
        mybigintX = x ;
        return *this * mybigintX ;
    }
    
    mybigint operator/(unsigned int x)
    {
        mybigint res;
        res = 1;
        
        mybigint mybigintX ;
        mybigintX = x ;
        
        while (mybigintX * res != *this)
            res = res+1;
        
        return res;
    }
    
    mybigint operator/(const mybigint& x)
    {
        mybigint res;
        res = 1;
        
        mybigint mybigintX ;
        mybigintX = x ;
        
        while (mybigintX * res != *this)
            res = res+1;
        
        return res;
    }
};