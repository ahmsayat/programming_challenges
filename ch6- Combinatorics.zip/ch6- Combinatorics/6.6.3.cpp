//////////////////////////////////////////////////////
//
//  6.6.3 Counting
//  PC/UVa IDs: 110603/10198, Popularity: B, Success rate: high Level: 2
//  programming_challenges
//  Created by Moussa on 17-JAN-2015 9:28 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <stdio.h>
#include <stdlib.h>

#include "bignum.txt"

using namespace std;

bignum * dp[1001];

string myset = "1234";

//years
void count(int l, string num)
{
    if (l>10) //20 is the upper bound and the program will not terminat. 4^20
        return;
    cout << num << endl;
    num.resize(l+1);
    for (int i=0; i<4; i++)
    {
        num[l] = myset[i];
        count(l+1, num);
    };
}


int sum_digits(string s)
{
    int res = 0;
    for (int i=0; i<s.length(); i++)
        if (s[i] == '1' || s[i] == '4')
            res+=1;
        else if(s[i] == '2')
             res+=2;
        else if(s[i] == '3')
             res+=3;
}

//f(n,k) = f(n−k,k)+f(n,k−1). The basis cases are f(1,1) = 1 and f(n,k) = 0 whenever k > n.
int integer_partitions(int n, int k)
{
    if (n == 1 && k == 1)
        return 1;
    if (k > n)
        return 0;
    if (n <= 0)
        return 0;
    if (k <= 0)
        return 0;
    
    return integer_partitions(n-k , k) + integer_partitions(n, k-1);
}

//solve using dp on bignums using recurrence
//dp [n] = dp [n – 1] + dp [n – 2] + dp [n – 3] + dp [n – 1]
void solve(int n)
{
    bignum two, res, res2;
    
    dp[1] = (bignum *) malloc(sizeof(bignum));
    dp[2] = (bignum *) malloc(sizeof(bignum));
    dp[3] = (bignum *) malloc(sizeof(bignum));
    
    int_to_bignum(2,dp[1]);
    int_to_bignum(5,dp[2]);
    int_to_bignum(13,dp[3]);
    int_to_bignum(2,&two);
    
    int smallv = 3;
    
    if (n <= smallv)
    {
        print_bignum(dp[n]);
    }
    else
    {
        for (int i= smallv+1; i<= n ; i++)
        {
            add_bignum(dp[i-3], dp[i-2], &res);
            
            multiply_bignum(dp[i-1], &two, &res2);
            
            dp[i] = (bignum *) malloc(sizeof(bignum));
            add_bignum(&res,&res2,dp[i]);
        }
        
        smallv = n;//useless now to avoid reconstruction of the dp table
        
        print_bignum(dp[n]);
    }
};

void solve_small(int n)
{
        long long M[1001];
    
        M[1]=2; M[2]=5; M[3]=13;
        
        for(int i=4;i<1001;i++)
            M[i]= 2*M[i-1] + M[i-2] + M[i-3]; //the recurrence relation

        cout<<M[n]<<endl;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch6- Combinatorics/6.6.3.input");
    //count(0, "");
    int A;
    //solve_small(4);
    while (cin >> A)
    {
        solve(A);
        //solve_small(A-1);
        //cout << integer_partitions(4,A) << endl;
    }
    
    return 0;
}

/***
 Analysis :
         Classic dp
                 dp [n] =
                         how many ways we can made (n – 1) +
                         how many ways we can made (n – 2) +
                         how many ways we can made (n – 3) +
                         how many ways we can made (n – 1)
                 dp [n] = dp [n – 1] + dp [n – 2] + dp [n – 3] + dp [n – 1]
 
         Use Big Integer
         Runtime : 0.676s
*/