//////////////////////////////////////////////////////
//
//  2.8.4 Crypt Kicker
//  PC/UVa IDs: 110204/843, Popularity: B, Success rate: low Level: 2
//  programming_challenges
//  Created by Moussa on 16-NOV-2014 11:57 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <map>
#include <vector>

using namespace std;

#define N 1000
string line;

map<int, map<string, map<string, float> > > best;

map<char, char> mp;
map<string, string> mp2;
bool found[N];
vector<string> words_in_the_line;
map<int, vector<string>> dict;
map<int, vector<string>> encrypted_word;

//By Moussa
template<class T, class V>
typename map<T, V>::iterator find_key_with_value(V value, map<T, V> &m)
{
    for (typename map<T, V>::iterator it = m.begin(); it != m.end(); it++)
        if (it->second == value)
            return it;
    
    return m.end();
}

template<class T, class V>
typename map<T, V>::iterator find_key_in_map(V key, map<T, V> &m)
{
    for (typename map<T, V>::iterator it = m.begin(); it != m.end(); it++)
        if (it->first == key)
            return it;
    
    return m.end();
}

void recursive(map<int, vector<string> >::iterator it, map<int, vector<string> >::iterator begin)
{
    vector<string> v = it->second;
    for (int i = 0; i < v.size(); i++) {
        cout<<v[i]<<endl;
    }
    
    if (it == begin)
        return;
    else
        recursive(--it, begin); //last
}


void recursive2(map<int, vector<string> >::iterator it, map<int, vector<string> >::iterator end)
{
    if (it == end)
        return;
    
    recursive2(++it, end); //first
    
    vector<string> v = (--it)->second;
    for (int i = 0; i < v.size(); i++) {
        cout<<v[i]<<endl;
    }
}

bool is_a_solution()
{
    for (int i=0; i<words_in_the_line.size(); i++)
        if (find_key_in_map(words_in_the_line[i], mp2) == mp2.end())
            return false;
    
    return true;
}

bool is_valid(string w, string w1)
{
    for (map<string, string>::iterator it = mp2.begin(); it != mp2.end(); it++)
    {
         string u = it->first;
         string u1 = it->second;
         for (int i = 0; i<w.length(); i++)
              for (int j = 0; j<w.length(); j++)
                  if (w[i] == u[j])
                      if (w1[i] != u1[j])
                          return false;
    }
    
    if(is_a_solution())
        cout<<"a solution is found"<<endl;
    
    return true;
}

void recursive4(map<int, vector<string> >::iterator it, map<int, vector<string> >::iterator end)
{
    if (it == end)
        return;
    
    recursive2(++it, end); //first
    
    --it;
    int length = it->first;
    vector<string> words = it->second;
    for (int i = 0; i < words.size(); i++)
    {
        string w = words[i];
        vector<string> dic_words =  dict[length];
        for (int j = 0; j < dic_words.size(); j++)
            if(is_valid(w, dic_words[j])) //string d = dic_words[j];
                mp2[w] = dic_words[j];
        
            /*
            for (int k=0; k<length; k++)
              mp[w[k]] = dic_words[j][k];
            mp2.erase("s");
            //test w -> d map
            */
    }
}

//brute force with smart proning
void decrypt2()
{
    //for (int i = 0; i < words_in_the_line.size(); i++)
        
    /*int length = it->first;
    vector<string> words = it->second;
    for (int i = 0; i < words.size(); i++)
    {
        string w = words[i];
        vector<string> dic_words =  dict[length];
        for (int j = 0; j < dic_words.size(); j++)
            if(is_valid(w, dic_words[j])) //string d = dic_words[j];
                mp2[w] = dic_words[j];
        
        /*
         for (int k=0; k<length; k++)
         mp[w[k]] = dic_words[j][k];
         mp2.erase("s");
         //test w -> d map
         */
}

void decrypt()
{
    //recursive(--dict.end(), dict.begin());
    //recursive2(dict.begin(), dict.end());
    //algorithm to decrypt a sentence
    /*
    for (map<int, vector<string> >::iterator it = --posible_match.end(); it++ != posible_match.begin(); it--)
    {
        vector<string> v = it->second;
        
        for (int i = 0; i < v.size(); i++) {
            cout<<v[i]<<endl;
        }
    }*/
    
    //cout<<s<<endl;
    //recursive(--encrypted_word.end(), encrypted_word.begin());
    recursive4(encrypted_word.begin(), encrypted_word.end());
    cout<<endl;
}

bool compare(string p1, string p2)
{
    return p1.length() < p2.length();
}

//not used yet
bool is_good_mapping(char c, char d)
{   //yes found
    if(mp[c] == d)
        return true;
    
    
    else
        if(mp[c] == 0) //not found at all
            return false;
        else
            return false; //found but wrong mapping
}

bool is_good(string s, string p)
{
    if (s.length() != p.length())
        return false;
    
    for (int i=0; i<s.length(); i++)
        if (mp[s[i]] ==  p[i])
            return true;
    
    return false;
}

//major work is here to decrypt other undecrypted words
void try_to_decrypt()
{
    for (map<int, map<string, map<string, float> > >::iterator it1 = best.begin(); it1 != best.end(); it1++) //biggest outer map
        for (map<string, map<string, float> >::iterator it2 = it1->second.begin(); it2 != it1->second.end(); it2++) //second map
            if (it2->second.size() > 1)
                for (map<string, float>::iterator it3 = it2->second.begin(); it3 != it2->second.end(); it3++) //third map
                    if(is_good(it2->first, it3->first)) //local search to search each word with its best possibilities
                        {
                            it3->second = 1.0;
                            //cout<<it2->first<<":"<<it3->first<<endl;
                            //fill more certain characters in mp map
                            for (int i=0; i< it2->first.length(); i++)
                                if (mp[it2->first[i]] == 0)
                                    mp[it2->first[i]] = it3->first[i];
                        }
}

int hash_str_to_num(string s)
{
    map<char, int> m;
    int score = 1;
    int index = 1;
    m[s[0]] = 1;

    for (int i = 1; i<s.size(); i++)
    if(m[s[i]] == 0)
    {
        index++;
        m[s[i]] = index;
        score = score*10 + m[s[i]];
        //m[s[i--]] = ++index; //optimum line
    }
    else
        score = score*10 + m[s[i]];
    
    //cout<<s<<" = "<<score<<endl;
    return score;
}

//if a word has only one word mapped to it, add their charaters to mp and start with them though this could be none.
void map_certain()
{
    for (map<int, map<string, map<string, float> > >::iterator it1 = best.begin(); it1 != best.end(); it1++) //biggest outer map
        for (map<string, map<string, float> >::iterator it2 = it1->second.begin(); it2 != it1->second.end(); it2++) //second map
             for (map<string, float>::iterator it3 = it2->second.begin(); it3 != it2->second.end(); it3++) //third map
                 if (it2->second.size() == 1)
                 {
                     it3->second = 1.0;
                     for (int i=0; i<it2->first.length(); i++)
                         mp[it2->first[i]] = it3->first[i];
                 }
}

void print(string line)
{
    string s; stringstream ss; ss << line;
    while (ss>>s)
    {
        map<string, float>::iterator it = find_key_with_value(float(1), best[(int) s.length()][s]);
        if (it != best[(int) s.length()][s].end())
            cout<< it->first;
        else
            for (int i=0; i<s.length(); i++)
                cout<< "*";
        
        cout<<" ";
    }
}

void fillds(ifstream &cin)
{
    string s;
    //map<int, map<string, map<string, float>>> best;
    
    //read encrypted sentence
    while (getline(cin, line))
        if(line != "\r")
        {
            //encrypted_word.clear();
            best.clear();
            stringstream ss; ss << line;
            while (ss>>s) //fill maps data structure
            {
                //words_in_the_line.push_back(s);
                for (int i=0; i<dict[(int)s.length()].size(); i++)
                  if(hash_str_to_num(s) == hash_str_to_num(dict[(int)s.length()][i])) //put only good possibilities
                     best[(int) s.length()][s][dict[(int)s.length()][i]] = 0;
                //encrypted_word[(int)s.length()].push_back(s);
            }
            
            //sort(words_in_the_line[0], words_in_the_line[words_in_the_line.size()-1], compare);
            //sort(words_in_the_line[0], words_in_the_line[words_in_the_line.size()-1]);
            //decrypt();
            map_certain();
            //cout<<line<<endl;
            try_to_decrypt();
            print(line);
            cout<<endl;
        }
}

int main()
{
    //data structure
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.4.input");
    int n; cin>>n;
    string s; getline(cin, s); //to get the /r or newline break mark
    
    //fill in the dictionary of words
    while(n-- && cin>>s)
       dict[(int)s.length()].push_back(s);
    
    //cin>>s; cout<<s<<endl;
    
    fillds(cin);
    
    /*
    return 0;
    //read encrypted sentence
    while (getline(cin, line))
     if(line != "\r")
        {
            encrypted_word.clear();
            stringstream ss; ss << line;
            while (ss>>s)
            {
                words_in_the_line.push_back(s);
                
                encrypted_word[(int)s.length()].push_back(s);
            }
    
            //sort(words_in_the_line[0], words_in_the_line[words_in_the_line.size()-1], compare);
            //sort(words_in_the_line[0], words_in_the_line[words_in_the_line.size()-1]);
            //decrypt();
        }
    */
   return 0;
}