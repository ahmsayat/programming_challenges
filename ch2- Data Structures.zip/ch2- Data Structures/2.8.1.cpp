//////////////////////////////////////////////////////
//
//  2.8.1 Jolly Jumpers
//  programming_challenges
//  PC/UVa IDs: 110201/10038, Popularity: A, Success rate: average Level: 1
//  Created by Moussa on 14-NOV-2014 07:38 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>

using namespace std;

#define N 3000

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.1.input");
    //data structure
    bool arr[N];
    string s;
    bool is_jolly = true;
    
    
   //read input
   while (getline(cin, s) && (s != "\r") && (s != "\n") && (s != ""))
   {
            //init
        for (int i = 0; i<N; i++)
                arr[i] = false;
       
            stringstream ss; ss<<s; //cout << s <<endl;
            int n;
            ss>>n;
            int previous;
       
       for (int i = 0; i<n; i++)
        {
                int temp;
                ss>> temp;
                
                if(i!=0) //missing bound check on abs(temp - previous) to be less than 3000
                {
                    arr[abs(temp - previous)] = true;
                }
                
                previous = temp;
        }
       
       //test if not jolly
       for (int i = 1; i<n; i++)
           if(arr[i] == false)
               is_jolly = false;
       
       //print output
       is_jolly? cout<<"Jolly"<<endl : cout<< "Not jolly"<<endl;
   }
    
   return 0;
}