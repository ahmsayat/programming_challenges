//////////////////////////////////////////////////////
//
//  2.8.6 Erdo ̈s Numbers
//  PC/UVa IDs: 110206/10044, Popularity: B, Success rate: low Level: 2
//  Created by Moussa on 22-NOV-2014 7:02 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <map>
#include <vector>
#include <queue>

using namespace std;

int P;
vector<string> paper_database;

int N;
vector<string> list_of_names;

map<string, int> erdos_number;
map<string, map<string, int>> co_authors; //paper->authors->number

vector<string> visited_names;

queue<string> explore;

void get_authors(string authors, string paper)
{
    cout<<authors<<endl;
    string a=""; bool second = false;
    for(int i = 0; i < authors.length(); i++)
        if(authors[i] == ',')
            if (second)
            {
                co_authors[paper][a] = -1; //cout<<a<<endl;
                erdos_number[a] = -1;
                a = "";
                second = false;
                i++;
            }
            else
            {
                second = true;
                a+=authors[i];
            }
        else
            a+=authors[i];
    
    co_authors[paper][a] = -1; //cout<<a<<endl;
    erdos_number[a] = -1;
}

string get_paper(string paper)
{
    //authors
    string s="";
    for(int j = 0; j < paper.length(); j++)
        if (paper[j]==':')
            break;
        else
            s+=paper[j];
    
    //paper name
    string p="";
    for(int i = 0; i < paper.length(); i++)
        if (paper[i]==':')
            for(int j = i+2; j < paper.length(); j++) //skip : and space
                p+=paper[j];
    
    get_authors(s,p);
    return p;
}

void process()
{
    for(int i = 0; i < paper_database.size(); i++)
    {
        string paper = paper_database[i];
        paper_database[i] = get_paper(paper);
    }
}

void print()
{
    for (int i=0; i<list_of_names.size(); i++)
        cout<< list_of_names[i] << " " << erdos_number[list_of_names[i]] <<endl;
}

string remove_newline(string s)
{
    stringstream ss;
    ss<<s;
    string res = "";
    ss>>res;
    while (ss>>s)
        res = res + " " + s;
    return res;
}


void fill(map<string, int> c, int score)
{
    for(map<string, int>::iterator it = c.begin(); it != c.end(); it++)
        if(it->first != "Erdos, P.")
        {
            //explore.push(it->first); //memory leak
            it->second = score;
            erdos_number[it->first] = score;
        }
}


void breadth_first_search()
{
    while (! explore.empty())
    {
        string name = explore.front();
        for(map<string, map<string, int>>::iterator it = co_authors.begin(); it != co_authors.end(); it++)
            for(map<string, int>::iterator it2 = it->second.begin(); it2 != it->second.end(); it2++)
                if(it2->first == name)
                    fill(it->second, 1);
        
        explore.pop();
    }
}

void compute_erdos_number()
{
    for(map<string, map<string, int>>::iterator it = co_authors.begin(); it != co_authors.end(); it++)
        for(map<string, int>::iterator it2 = it->second.begin(); it2 != it->second.end(); it2++)
            if (it2->first == "Erdos, P.")
                fill(it->second, 1);
    
    //co_authors.find
}

int main()
{
    //data structure
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.6.input");
    int T; cin>>T;
    string line;
    int t = 1;
    while (T--)
    {
        //read input into data structures
        cin>>P>>N; getline(cin, line);//to skip the \r
        while (P-- && getline(cin, line))
            paper_database.push_back(remove_newline(line));
        
        while (N-- && getline(cin, line))
            list_of_names.push_back(remove_newline(line));
        
        //process data
        process();
        compute_erdos_number();
        breadth_first_search();
        cout<<"Scenario "<<t++<<endl;
        print();
    }
   return 0;
}