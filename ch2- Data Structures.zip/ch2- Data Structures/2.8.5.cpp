//////////////////////////////////////////////////////
//
//  2.8.5 Stack ’em Up
//  PC/UVa IDs: 110205/10205, Popularity: B, Success rate: average Level: 1//  programming_challenges
//  Created by Moussa on 22-NOV-2014 3:47 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <map>
#include <vector>

using namespace std;

string suits[] = {"Clubs", "Diamonds", "Hearts", "Spades"};
string values[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};

#define N 52

/*
/13
%13
*/

int card[N];

vector<map<int, int>> shuffles;

struct acard
{
    string suit;
    string value;
};

//before shuffle and after shuffle decks
acard before_deck[N]; //which card will set on location 0
acard after_deck[N];

string getSuit(int card)
{
    return suits[card/13];
}

string getValue(int card)
{
    return values[card%13];
}

void print()
{
 //for (int j=0; j<N; j++)
    for (int i=0; i<N; i++)
        //if(j==card[i])
            cout << getValue(card[i]) << " of " << getSuit(card[i]) << endl;
}


void print_acard()
{
    for (int i=0; i<N; i++)
        cout << before_deck[i].value << " of " << before_deck[i].suit << endl;
}

void fillds()
{
    for (int i=0; i<N; i++)
        card[i] = i;
}

void fillds_acard()
{
    for (int i=0; i<N; i++)
    {
        before_deck[i].suit = getSuit(i);
        before_deck[i].value = getValue(i);
    }
}

//try to avoid overwriting data and losing values when swaping
void process(int k)
{
    for (int i=0; i<N; i++)
        card[i] = shuffles[k][card[i]];
}

void process_acard(int k)
{
    for (int i=0; i<N; i++)
    {
        //acard t = deck[shuffles[k][i]];
        //deck[shuffles[k][i]] = deck[i];
        //deck[i] = t;
        after_deck[i] = before_deck[shuffles[k][i]];
    }
    
    //this is a must to have two versions of deck hands to preserve the shuffle before and the after states without overrighting and losing data
    for (int i=0; i<N; i++)
        before_deck[i] = after_deck[i];
}

//assume deck[i] contains any random card at poition i
int main()
{
    //data structure
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.5.input");
    int T; cin>>T;

    while (T--)
    {
        //fillds();
        fillds_acard();
        
        int shuffle_numbers;
        cin>>shuffle_numbers;
        
        while (shuffle_numbers--)
        {
            map<int, int> shuf;
            for (int pos=0; pos<N; pos++)
            {
                int cn;
                cin>>cn;
                shuf[pos] = cn-1;
            }
            
            shuffles.push_back(shuf);
        }
        
        //print();
        
        string s;int k;stringstream ss; //cin>>k; cout<<k<<endl;
        
        //while (getline(cin, s) && s != "\r")
        while (cin>>k)
        {
            //cout<<k<<endl;
            //ss<<s; ss>>k;
            //process(k-1);
            process_acard(k-1);
            //print();
        }
        
        print_acard();
    }
    
   return 0;
}