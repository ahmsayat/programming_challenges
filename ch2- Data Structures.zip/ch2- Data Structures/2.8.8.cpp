//////////////////////////////////////////////////////
//
//  2.8.8 Yahtzee
//  PC/UVa IDs: 110208/10149, Popularity: C, Success rate: average Level: 3
//  Created by Moussa on 23-NOV-2014 7:29 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <map>
#include <vector>
#include <queue>

using namespace std;

#define f for (int i=0; i<5; i++)
int dice[13][5];
int values[13];
bool category_used[13];

int matrix13x13[13][13];

//print is ugly coded because I need to print the map values in descending order where the map sort keys ascendingly.
void print(vector<int> output)
{
    for (int i=0; i<15; i++)
        printf("%d ",output[i]);
    
    //if (i!= 14) printf(" ");
    
    printf("\n");}

int getValue(int index)
{
    int v = 0;
    for (int j=0; j<5; j++)
        v = (v + dice[index][j]) * 10;
    return v/10;
}

void value()
{
    for (int i=0; i<13; i++)
        values[i] = getValue(i);
}

//round index, category
int category(int index, int cat)
{
    int score = 0;
    switch (cat)
    {
        case 1:
            f if(dice[index][i] == 1) score+=1;
            break;
        case 2:
            f if(dice[index][i] == 2) score+=2;
            break;
        case 3:
            f if(dice[index][i] == 3) score+=3;
            break;
        case 4:
            f if(dice[index][i] == 4) score+=4;
            break;
        case 5:
            f if(dice[index][i] == 5) score+=5;
            break;
        case 6:
            f if(dice[index][i] == 6) score+=6;
            break;
        case 7:
            f score+=dice[index][i]; //chance - sum of all dice
            break;
        case 8:
            if ( dice[index][0] == dice[index][2] || dice[index][1] == dice[index][3] || dice[index][2] == dice[index][4] )
                f score+=dice[index][i]; //three of a kind - sum of all dice, provided at least three have same value
            break;
        case 9:
            if( (dice[index][0] == dice[index][1] && dice[index][1] == dice[index][2] && dice[index][2] == dice[index][3])
             || (dice[index][1] == dice[index][2] && dice[index][2] == dice[index][3] && dice[index][3] == dice[index][4]) )
             f score+=dice[index][i]; //four of a kind - sum of all dice, provided at least four have same value
            break;
        case 10:
            if(dice[index][0] == dice[index][1] && dice[index][1] == dice[index][2] && dice[index][2] == dice[index][3] && dice[index][3] == dice[index][4])
                score = 50; //five of a kind - 50 points, provided all five dice have same value
            break;
        case 11:
            //if(getValue(index) == 1234 || getValue(index) == 2345 || getValue(index) == 3456)
                if( (dice[index][0] == dice[index][1]-1 && dice[index][1] == dice[index][2]-1 && dice[index][2] == dice[index][3]-1)
                 || (dice[index][1] == dice[index][2]-1 && dice[index][2] == dice[index][3]-1 && dice[index][3] == dice[index][4]-1) )
                    score = 25; //short straight - 25 points, provided four of the dice form a sequence (that is, 1,2,3,4 or 2,3,4,5 or 3,4,5,6)
            break;
        case 12:
            if(getValue(index) == 12345 || getValue(index) == 23456)
               score = 35; //long straight - 35 points, provided all dice form a sequence (1,2,3,4,5 or 2,3,4,5,6)
            break;
        case 13:
            if( (dice[index][0] == dice[index][1] && dice[index][2] == dice[index][4])
             || (dice[index][0] == dice[index][2] && dice[index][3] == dice[index][4]) )
                score = 40; //full house - 40 points, provided three of the dice are equal and the other two dice are also equal. (for example, 2,2,5,5,5)
            break;
        default:
            break; //Each of the last six categories may be scored as 0 if the criteria are not met.
    }
    return score;
}

int process(int c)
{
    if (c == 12)
        return category(1, c);
    
    category_used[c] = true;
    for (int i=0; i<13; i++)
      return max(category(i, c) , process(c+1));
    category_used[c] = false;
}

void fill_matrix()
{
    for (int round=0; round<13; round++)
        for (int c=1; c<=13; c++)
            matrix13x13[round][c] = category(round,c);
}

map<pair<int,int>, vector<int>> memo; //best score for categories used over rounds and assignments

//dynamic programming
vector<int> dp(int rounds_left, int category)
{
    //check memoization case
    if (memo.find(pair<int, int>(rounds_left,category)) != memo.end())
        return memo[pair<int, int>(rounds_left,category)];
    
    vector<int>  HighestScore, TestScore; HighestScore.resize(15); TestScore.resize(15); HighestScore[14]=-1;
    //base case
    if (category == 0)
    {
        HighestScore[0] = matrix13x13[(int)(log((double)rounds_left)/log(2.0))][0]; //only 1 round left with category 0
        HighestScore[14] = HighestScore[0]; //total is same
        return HighestScore;  //HighestScore[14] = HighestScore[0] = matrix13x13[rounds_left][0];
    }
    
    for (int i=0; i<13; i++)
        if(rounds_left & (int) pow(2.0,i)) //if the bit i in rounds_free is 1
        {
            TestScore = dp(rounds_left ^ (int) pow(2.0,i) , category-1); //dp recursive step by turning off the bit i
            TestScore[14] += matrix13x13[i][category];
            TestScore[category] = matrix13x13[i][category];
            
            //check if bonus eligible
            if (category == 5)
            {
                TestScore[13] = (TestScore[14] >= 63) ? 35 : 0;
                TestScore[14] += TestScore[13];
            }
            
            //print(HighestScore);
            
            //store max
            if (TestScore[14] > HighestScore[14] ) HighestScore = TestScore;
            //else if (TestScore[14] == HighestScore[14] && category==12) print(HighestScore);
        }
    
    memo[pair<int, int>(rounds_left,category)] = HighestScore;
    return HighestScore;
}

int main()
{
    //data structure
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.8.input");
    int T = 2;
    while (T--)
    {
        for (int i=0; i<13; i++)
        {
            for (int j=0; j<5; j++)
                cin>>dice[i][j];
            sort(dice[i], dice[i]+5);
        }
    
        //value();
        //cout<<process(1);
        fill_matrix();
        //cout<<endl;
        
        vector<int> output = dp(pow(2.0, 13)-1, 12);
        print(output);
        memo.clear();
    }

    return 0;
}

/* Notes
This has been the most challenging problem I’ve done so far. 
This is a classic optimization problem and the approach I chose here was Dynamic Programming (Memoization).
 
find which mapping of categories to rounds will create the highest score.
using dynamic programming

I chose the sub problem to be the what is the highest score attainable given that categories 0….k have been assigned and particular rounds have been used. So we can say

 MaxScore(13,all rounds free) = 
    Max(  Score of category 13 assigned to round 1 + MaxScore(12, round 1 not free), 
          Score of category 13 assigned to round 2 + MaxScore(12, round 2 not free) …). 

The base case here is of course in category 1 when only one round is free. We will use memoization to remember our answer to each MaxScore problem.

digital logic gates:
^ xor
& and
| or

pair<int,int> key; 
key.first = 3;

cout<<int(1 ^ 0)<<endl;
*/