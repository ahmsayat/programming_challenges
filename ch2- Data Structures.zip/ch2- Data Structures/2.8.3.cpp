//////////////////////////////////////////////////////
//
//  2.8.3 Hartals
//  PC/UVa IDs: 110203/10050, Popularity: B, Success rate: high Level: 2
//  programming_challenges
//  Created by Moussa on 15-NOV-2014 12:45 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <map>

using namespace std;

#define N 3650

bool day[N];

int main()
{
    //data structure
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.3.input");
    int T;
    cin>>T;
    
    for (int t=1; t<=T; t++)
    {
        int n;
        cin>>n;
        int P;
        cin>>P;
        //int h[P];
        int lost_days = 0;
        
        for (int i=1; i<=n; i++) day[i] = false;
        
        //simulate
        for (int i=0; i<P; i++)
        {
            int temp;
            cin>>temp; //h[i] = temp;
            for (int j = 1; j<=n; j++)
                if(j%7 == 6 || j%7 == 0) //friday or saturday so don't count them
                    continue;
                else if(j % temp == 0 && day[j] == false)
                {
                    day[j] = true; //to avoid double counting when repeating on (4 & 8) for example.
                    lost_days++;
                }
        }
        
        //print output
        cout<<lost_days<<endl;
   }

   return 0;
}