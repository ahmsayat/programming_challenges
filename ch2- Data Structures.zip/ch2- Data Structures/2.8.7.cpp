//////////////////////////////////////////////////////
//
//  2.8.7 Contest Scoreboard
//  PC/UVa IDs: 110207/10258, Popularity: B, Success rate: average Level: 1
//  Created by Moussa on 23-NOV-2014 6:32 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <map>
#include <vector>
#include <queue>

using namespace std;

struct score
{
    int problems;
    int time;
};

map<int, score> contestants;

map<int, map<int, int>> score_board; //problems=>time=>contestant

//print is ugly coded because I need to print the map values in descending order where the map sort keys ascendingly.
void print()
{
    for (map<int, map<int, int>>::iterator it = --score_board.end(); ; it--)
        if (it == score_board.begin()) {
            for (map<int, int>::iterator it2 = --it->second.end(); ; it2--)
                if(it2 == it->second.begin())
                {
                    cout << it2->second << " " << it->first << " " << it2->first << endl;
                    break;
                }
                else
                    cout << it2->second << " " << it->first << " " << it2->first << endl;
            break;
        }
        else
            for (map<int, int>::iterator it2 = --it->second.end(); ; it2--)
                if(it2 == it->second.begin())
                {
                    cout << it2->second << " " << it->first << " " << it2->first << endl;
                    break;
                }
                else
                    cout << it2->second << " " << it->first << " " << it2->first << endl;
}

int main()
{
    //data structure
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.7.input");
    int T; cin>>T;
    string line;
    getline(cin, line); getline(cin, line);//to skip the \r
    int c, p, t; char L;
    
    while (T--)
    {
        //read input into data structures
        while(getline(cin, line) && line != "\r")
        {
            stringstream ss; ss<<line;
            ss >> c >> p >> t >> L;
            //cout<<c<<p<<t<<L<<endl;
            
            if(L=='C')
            {
                contestants[c].time+=t;
                contestants[c].problems+=1;
            }
            else if(L == 'I')
            {
                contestants[c].time+=20;
            }
        }
        
        for (map<int, score>::iterator it = contestants.begin(); it != contestants.end(); it++)
            score_board[it->second.problems][it->second.time] = it->first;
        
        print();
    }
    
   return 0;
}

