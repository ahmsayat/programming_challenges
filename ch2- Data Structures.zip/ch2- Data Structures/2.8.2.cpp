//////////////////////////////////////////////////////
//
//  2.8.2 Poker Hands
//  PC/UVa IDs: 110202/10315, Popularity: C, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 14-NOV-2014 08:15 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

int Is_Straight_Flush(int i);
int Is_Four_of_a_Kind(int i);
int Is_Full_House(int i);
int Is_Flush(int i);
int Is_Straight(int i);
int Is_Three_of_a_Kind(int i);
int Is_Two_Pairs(int i);
int Is_Pair(int i);
int Is_High_Card(int i);

#define N 3000

map<char, int> mp;

//values: 2, 3, 4, 5, 6, 7, 8, 9, T, J, Q, K, A
//suits: C, D, H, S

enum rank //ranking rules of Poker
{
    High_Card = 0, //Hands not fit any higher category ranked by value of highest card then by next highest, and so on.
    Pair = 1, //Two of the five cards in the hand have the same value. Tie ranked by value of pair then other cards.
    Two_Pairs = 2, //The hand contains two different pairs. rank by value of highest pair, 2nd pair then remaining card
    Three_of_a_Kind = 3, //Three of the cards in the hand have the same value. Tie is solved by the value on the 3 cards
    Straight = 4, //Hand contains 5 cards with consecutive values. Tie hands are ranked by their highest card.
    Flush = 5, //Hand contains 5 cards of the same suit. Tie hands are ranked using the rules for High Card.
    Full_House = 6, //Three cards of the same value and 2 cards forming a pair. Ranked by the value of the three cards.
    Four_of_a_Kind = 7, //Four cards with the same value. Ranked by the value of the four cards.
    Straight_Flush = 8 //Five cards of the same suit with consecutive values. Ranked by the highest card in the hand.
};

struct card
{
    int value;
    char suit;
};

//hands
vector<card> hand[2]; //black 0, white 1

//value and suit frequency
map<int, int> vfreq[2]; //black 0, white 1
map<char, int> sfreq[2]; //black 0, white 1

//ranks of a hand where _rank[0] is category number from rank enum
int hand_rank[2][6]; //black 0, white 1
void fill_rank(int e, int h)
{
    hand_rank[h][0] = e;
    int i = 1;
    for (map<int, int>::iterator it = --vfreq[h].end(); it != vfreq[h].begin(); it--)
      hand_rank[h][i++] = it->first;
}

//By Moussa
template<class T, class V>
typename map<T, V>::iterator find_key_with_value(V value, map<T, V> &m)
{
    for (typename map<T, V>::iterator it = m.begin(); it != m.end(); it++)
        if (it->second == value)
            return it;
    
    return m.end();
}

//correct
int Is_Straight_Flush(int i)
{
    if(Is_Straight(i) != -1 && Is_Flush(i) != -1)
        return 1;
    else
        return -1;
}

//correct
int Is_Four_of_a_Kind(int i)
{
    map<int, int>::iterator it = find_key_with_value(4, vfreq[i]);
    if (vfreq[i].size() == 2 && it != vfreq[i].end())
        return it->first;
    return -1;
}

//correct
int Is_Full_House(int i)
{
    map<int, int>::iterator it = find_key_with_value(3, vfreq[i]);
    if (vfreq[i].size() == 2 && it != vfreq[i].end())
        return it->first;
    return -1;
}

//correct
int Is_Flush(int i)
{
    map<char, int>::iterator it = find_key_with_value(5, sfreq[i]);
    if (sfreq[i].size() == 1 && it != sfreq[i].end())
        return it->first;
    return -1;
}

//correct
int Is_Straight(int i)
{
    return (vfreq[i].size() == 5 && vfreq[i].begin()->first + 4 == (--vfreq[i].end())->first)? (--vfreq[i].end())->first : -1;
    /*
    if (vfreq[i].size() != 5) return -1;
    map<int, int>::iterator it = vfreq[i].begin();
    int s = it->first;
    while(++it != vfreq[i].end())
      if(s + 1 != it->first)
        return -1;
      else
        s = it->first;
    return (--it)->first;
     */
}

//correct
int Is_Three_of_a_Kind(int i)
{
    map<int, int>::iterator it = find_key_with_value(3, vfreq[i]);
    if (vfreq[i].size() == 3 && it != vfreq[i].end())
        return it->first;
    return -1;
}

int Is_Two_Pairs(int i)
{
    int pairs = 0;
    if (vfreq[i].size() == 3)
        for(map<int, int>::iterator it = vfreq[i].begin(); it!= vfreq[i].end(); it++)
            if(it->second == 2)
                pairs++;
    
    if(pairs == 2)
        return 1;
    else
        return -1;
    /*
     map<int, int>::iterator it = find_key_with_value(1, vfreq[i]);
     if (vfreq[i].size() == 3 && it != vfreq[i].end())
        return 1;
     return -1;
     */
}

int Is_Pair(int i)
{
    map<int, int>::iterator it = find_key_with_value(2, vfreq[i]);
    if (vfreq[i].size() == 4 && it != vfreq[i].end())
        return it->first;
    return -1;
}

int Is_High_Card(int i)
{
    map<int, int>::iterator it = vfreq[i].end();
    --it;
    //hand_rank[i][0] = it->first;  hand_rank[i][1] = (--it)->first;
    return it->first;
}

void compute_freq(int h)
{
    for (int i = 0; i<5; i++)
    {
        //values frequencies
        if (vfreq[h].find(hand[h][i].value) == vfreq[h].end())
            vfreq[h][hand[h][i].value] = 1;
        else
            vfreq[h][hand[h][i].value]++;
        
        //suits frequencies
        if (sfreq[h].find(hand[h][i].suit) == sfreq[h].end())
            sfreq[h][hand[h][i].suit] = 1;
        else
            sfreq[h][hand[h][i].suit]++;
    }
    //inverse black so loop through the freq map
    //for (map<int, int>::iterator it = freq[0].begin(); it != freq[0].end(); it++) freq[2][it->second] = it->first;
    
    //debug
    //for (map<int, int>::iterator it = freq[2].begin(); it != freq[2].end(); it++) cout<<it->first<<"="<<it->second<<endl;
}

void rank_hand(int h)
{
    compute_freq(h);
    int consecutive_values;
    int same_suit;
    int same_value;
    
    if (Is_Straight_Flush(h) != -1)
        fill_rank(Straight_Flush, h);
    else if (Is_Four_of_a_Kind(h) != -1)
        fill_rank(Four_of_a_Kind, h);
    else if (Is_Full_House(h) != -1)
        fill_rank(Full_House, h);
    else if (Is_Flush(h) != -1)
        fill_rank(Flush, h);
    else if (Is_Straight(h) != -1)
        fill_rank(Straight, h);
    else if (Is_Three_of_a_Kind(h) != -1)
        fill_rank(Three_of_a_Kind, h);
    else if (Is_Two_Pairs(h) != -1)
        fill_rank(Two_Pairs, h);
    else if (Is_Pair(h) != -1)
        fill_rank(Pair, h);
    else
        fill_rank(High_Card, h);

    /*
    int i = Is_Full_House(h);
    int j =  Is_Flush(h);
    int k =  Is_High_Card(h);
    int l =  Is_Straight(h);
    int m =  Is_Two_Pairs(h);
    int n =  Is_Pair(h);
    int o =  Is_Straight_Flush(h);
    
    cout<<"h"<<h<<") fullhouse: " << i << " twopair: " << m << " pair: " << n << endl;
    
    switch (vfreq[0].size()) {
        case 1:
        {
            cout<< "This is impossible to have 5 cards of same value : " << vfreq[0].at(0) << endl;
            //sfreq[0].size() == 1
        }
        break;
        case 2:
            map<int, int>::iterator it = find_key_with_value(4, vfreq[0]); // find_if(v.begin(), v.end(), isValue(4));
            if (it != vfreq[0].end())
            {
                same_value = 4;
                hand_rank[0][0] = Four_of_a_Kind;
                hand_rank[0][1] = it->first;
            }
            else if (3-2)
            {
                same_value = 4;
                hand_rank[0][0] = Three_of_a_Kind;
            }
        break;
        case 3:
        break;
        case 4:
        break;
        case 5:
        break;
        default:
            break;
    }
     */
}

bool cmp(int p1, int p2)
{
    return p1 < p2;
}

int main()
{
    //data structure
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch2- Data Structures/2.8.2.input");
    mp['2'] = 2;  mp['3'] = 3; mp['4'] = 4; mp['5'] = 5; mp['6'] = 6; mp['7'] = 7;  mp['8'] = 8; mp['9'] = 9;
    mp['T'] = 10; mp['J'] = 11; mp['Q'] = 12; mp['K'] = 13; mp['A'] = 14;
    string s;

    //read input
    while (getline(cin, s) && (s != "\r") && (s != "\n") && (s != ""))
    {
        
        for (int i = 0; i<2; i++)
        {
            hand[i].clear(); //black 0, white 1
            vfreq[i].clear();
            sfreq[i].clear();
            //int hand_rank[2][6];
        }
        
        stringstream ss; ss<<s; //cout << s <<endl;
        char c;
        
        //init black hand
        for (int i = 0; i<5; i++)
        {
            card cd;
            ss>>c;
            cd.value = mp[c];
            ss>>cd.suit;
            hand[0].push_back(cd);
        }

        //init white hand
        for (int i = 0; i<5; i++)
        {
            card cd;
            ss>>c;
            cd.value = mp[c];
            ss>>cd.suit;
            hand[1].push_back(cd);
        }
        
        //rank a hand
        rank_hand(0);
        //rank a hand
        rank_hand(1);
        
        /* debug print
        for (int i = 0; i<5; i++)
            cout<<black_hand[i].value << black_hand[i].suit<< " ";
        cout <<endl;
        */
        
       //test who wins by comparing ranks
       int winner = -1; //-1 tie, 0 black, 1 white
       for (int i = 0; i<6; i++)
       {
           if (hand_rank[0][i] == hand_rank[1][i])
               continue;
           else if (hand_rank[0][i] > hand_rank[1][i])
           {winner = 0; break;}
           else if (hand_rank[0][i] < hand_rank[1][i])
           {winner = 1; break;}
       }
    
       /*print output*/
        switch (winner)
        {
            case -1:
                cout<<"Tie."<<endl;
                break;
            case 0:
                cout<<"Black wins."<<endl;
                break;
            case 1:
                cout<<"White wins."<<endl;
                break;
            default:
                break;
        }
   }

   return 0;
}