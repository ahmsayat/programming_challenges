//////////////////////////////////////////////////////
//
//  7.6.6 Smith Numbers
//  PC/UVa IDs: 110706/10042, Popularity: B, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 28-FEB-2015 09:00 PM
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <bitset>

using namespace std;

#define MAXN 10000000

bitset<MAXN> prim;

bool is_prim(int n)
{
    for (int i=2; i <= sqrt(n); i++)
        if (n % i == 0)
            return false;
    return true;
};

//generating primes
void sieve(long long upper_bound)
{
    prim.set(); //set all bits to 1
    prim[0] = prim[1] = 0;
    for(long long i = 2; i <= upper_bound; i++)
        if(prim[i])
            for(long long j = i * i; j <= upper_bound; j += i)
                prim[j] = 0;
}

vector<int> factors;
void prime_factorization(int x)
{
    factors.clear();

    int c = x; /* remaining product to factor */
    while ((c % 2) == 0)
    {
        //printf("%d\n", 2);
        factors.push_back(2);
        c = c / 2;
    }
    
    int i = 3;  /* counter */
    while (i <= (sqrt(c)+1))
    {
        if ((c % i) == 0)
        {
            //printf("%d\n",i);
            factors.push_back(i);
            c = c / i;
        }
        else
            i = i + 2;
    }
    
    if (c > 1)
    {
        //printf("%d\n",c);
        factors.push_back(c);
    }
    
    //cout << endl;
}

int sum_digits(int n)
{
    int sum = 0;
    while (n>0)
    {
        int last_digit = n%10;
        sum+=last_digit;
        n/=10;
    }
    return sum;
};

int sum_factors(int i)
{
    prime_factorization(i);
    int sum = 0;
    for (int i=0; i<factors.size(); i++)
        sum+=sum_digits(factors[i]);
    return sum;
};

void Next_Smith_Number(int n)
{
    for (int i = n+1; ; i++)
        if (sum_digits(i) == sum_factors(i))
        {
            cout << i << endl;
            break;
        }
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.6.input");
    
    sieve(MAXN);
    
    int n; int T; cin>>T;
    for (int i=1; i<=T && cin>>n; i++)
    {
        Next_Smith_Number(n);
    }
    
    return 0;
}
