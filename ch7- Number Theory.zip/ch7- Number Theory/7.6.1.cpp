//////////////////////////////////////////////////////
//
//  7.6.1 Light, More Light
//  PC/UVa IDs: 110701/10110, Popularity: A, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 13-FEB-2015 10:53 PM, Quseir
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.1.input");
    
    for (double n = 0; cin>>n && n!=0; )
        if (sqrt(n) - int(sqrt(n)) == 0) //this mean it is a perfect square so n will have odd number of factors
            cout << "yes" << endl;
        else
            cout << "no" << endl;

    return 0;
}
