//////////////////////////////////////////////////////
//
//  7.6.2 Carmichael Numbers
//  PC/UVa IDs: 110702/10006, Popularity: A, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 13-FEB-2015 11:37 PM, Quseir
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include<bitset>

using namespace std;

int n;
bitset<65100> prim;
bitset<65100> carmichael;

//bool is_carmichael[65100];

bool is_prim(int n)
{
    for (int i=2; i <= sqrt(n); i++)
        if (n % i == 0)
            return false;
    return true;
};

//generating primes
void sieve(long long upper_bound)
{
    prim.set(); //set all bits to 1
    prim[0] = prim[1] = 0;
    for(long long i = 2; i <= upper_bound + 1; i++)
        if(prim[i])
            for(long long j = i * i; j <= upper_bound + 1; j += i)
                prim[j] = 0;
}

// using Using modular multiplication rules:
// ie: 5^90 % 10
long long exponential_mod(long long base, int exp, int mod)
{
    long long result = 1;
    for ( ; exp > 0; exp >>= 1 /*divid exp by  2*/)
    {
        if(exp % 2 == 1)
            result = (result * base) % mod;
        
        base = (base * base) % mod;
    }
    
    return result;
}

//pass Fermat Test however it is not really a prime
bool is_Carmichael_Number(int n)
{
    if(prim[n])
        return false;
    else //composite number
     for(int i = 2; i < n; i++)
        if(exponential_mod(i, n, n) != i)
            return false;
    
    return true; //passed all Fermat tests
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.2.input");
    
    //generating primes up to 65100
    sieve(65100);
    
    carmichael.reset(); //reset all bits to 0
    for(int i = 2; i <= 65000; i++)
        if (is_Carmichael_Number(i) == true)
            carmichael.set(i); //1
        else
            carmichael.reset(i); //0
    
    /*for (int i=0; i<100; i++)
        if(prim[i])
            cout << i << endl;*/
    
    for (int n = 0; cin>>n && n!=0; )
        if (carmichael[n])
            cout << "The number " << n << " is a Carmichael number." << endl;
        else
            cout << n << " is normal." << endl;
    
    return 0;
}
