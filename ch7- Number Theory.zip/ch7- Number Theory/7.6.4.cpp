//////////////////////////////////////////////////////
//
//  7.6.4 Factovisors
//  PC/UVa IDs: 110704/10139, Popularity: A, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 20-FEB-2015 01:01 PM, Marriott QA
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <bitset>

using namespace std;


long factovisors (long n, long m)
{
    if (n == 0)
        return 1;
    else
        return (n % m * factovisors(n-1, m) % m) % m;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.4.input");
    long n,m;
    
     
    for (;cin>>n>>m;)
    {
        if (factovisors (n, m) == 0)
            cout << m << " divides " << n << "!" << endl;
        else
            cout << m << " does not divide " << n << "!" << endl;
    }
    
    return 0;
}
