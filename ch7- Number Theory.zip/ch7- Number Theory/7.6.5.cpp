//////////////////////////////////////////////////////
//
//  7.6.5 Summation of Four Primes
//  PC/UVa IDs: 110705/10168, Popularity: A, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 28-FEB-2015 04:00 PM
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <bitset>

using namespace std;

#define MAXN 10000000

bitset<MAXN> prim;

bool is_prim(int n)
{
    for (int i=2; i <= sqrt(n); i++)
        if (n % i == 0)
            return false;
    return true;
};

//generating primes
void sieve(long long upper_bound)
{
    prim.set(); //set all bits to 1
    prim[0] = prim[1] = 0;
    for(long long i = 2; i <= upper_bound; i++)
        if(prim[i])
            for(long long j = i * i; j <= upper_bound; j += i)
                prim[j] = 0;
}

void f (long n)
{
    string s = "";
    if (n<8)
    { cout << "Impossible." << endl; return; }
    else if (n%2 == 0)
    { s = "2 2"; n-=4; }
    else if (n%2 == 1)
    { s = "2 3"; n-=5; }
    
    for (int i=2; i<n; i++)
        if ( prim[i] && prim[n-i] )
        {
            cout << s << " " << i << " " << n-i << endl;
            return;
        }
    
    cout << "Impossible." << endl;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.5.input");
    sieve(MAXN);
    int n;
    
    for (;cin>>n;) f(n);
    
    return 0;
}
