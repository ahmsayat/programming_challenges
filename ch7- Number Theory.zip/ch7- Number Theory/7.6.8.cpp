//////////////////////////////////////////////////////
//
//  7.6.8 Repackaging
//  PC/UVa IDs: 110708/10089, Popularity: C, Success rate: low Level: 2
//  programming_challenges
//  Created by Moussa on 28-FEB-2015 11:59 AM
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

/***
First, convert each package p = (s1, s2, s3) to a vector (s2 - s1, s3 - s1). All the packages forms convex hull. If point (0, 0) is in this convex hull, then there will be a solution, otherwise not. I can not tell the proof of this now, if you have any ideas, please let me know.

In fact, point (0, 0) is not in this convex hull if and only if all the vectors fall into a sector whose angle is less than PI. This is obviously correct. So we can use this point to get our answer.
*/
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <bitset>

using namespace std;

struct POINT
{
    POINT (){};
    
    POINT(long long x, long long y, long long z) : x(x), y(y), z(z)
    {};
    
    POINT(long long x, long long y) : POINT(x, y, 0)
    {
        //POINT(x, y, 0); // Here will make a problem and will not initialize members correctly.
        /* Can constructor call another constructor in c++? NO. Not before C++11.
         The "so-called" second call would compile, but has a different meaning in C++: it would construct a new object, a temporary, which will then be instantly deleted at the end of the statement. So, no.
         
         A destructor, however, can be called without a problem.
         */
    };
    
    //Copy ctor
    POINT& operator=(POINT const& copy)
    {
        x = copy.x;
        y = copy.y;
        z = copy.z;
        
        return *this;
    };
    
    /*
    some_struct& operator=(some_struct const& copy)
    {
        some_base::operator=(copy);
        str1 = copy.str1;
        a    = copy.a;
        b    = copy.b;
        c    = copy.c;
        str2 = copy.str2;
        return *this;
    }
    
     */
    
    bool operator==(const POINT &right)
    {
        if(x == right.x && y == right.y && z == right.z)
            return true;
        else
            return false;
    };
    
    
    long long x, y, z;
};

vector<POINT> v;

//find m1 and m2 that satisfy the equation  n1 * m1 + n2 * m2 = n, and gives the minimum cost where cost = c1 * m1 + c2 * m2 .
void moussa_solution()
{
    for (int i=0; i<v.size(); i++) {
        cout << v[i].x << " " << v[i].y << " " << v[i].z << endl;
    }
};

typedef long long llint;
bool repackage(int npkgs)
{
    for (llint i = 0; i < npkgs; ++i) {
        v[i].x -= v[i].z;
        v[i].y -= v[i].z;
    }
    
    llint x1 = v[0].x, y1 = v[0].y, x2 = v[0].x, y2 = v[0].y;
    for (llint i = 1; i < npkgs; ++i) {
        llint x = v[i].x, y = v[i].y;
        llint a1 = y1 * x, b1 = x1 * y, a2 = y2 * x, b2 = x2 * y;
        if (a1 == b1)
            if (x1 * x + y1 * y <= 0) return true;
            else continue;
        if (a2 == b2)
            if (x2 * x + y2 * y <= 0) return true;
            else continue;
        if (a1 < b1) x1 = x, y1 = y;
        if (a2 > b2) x2 = x, y2 = y;
        if (x1 == x2 && y1 == y2) return true;
        if (y1 * x2 == y2 * x1)
            if (x1 * x2 + y1 * y2 <= 0) return true;
            else continue;
        if (y1 * x2 < y2 * x1) return true;  
    }  
    return false;  
}

bool linear_programming_simplex_method(int npkgs)
{
    //convert packages to 2D CONVEX HULL
    for (int i = 0; i < npkgs; ++i)
    {
        v[i].x -= v[i].z;
        v[i].y -= v[i].z;
    }

    //I first convert (s1,s2,s3) to (s1-s3,s2-s3), then I find the convex hull and determine whether (0,0) is within this convex hull
    POINT pa(v[0].x, v[0].y), pz(v[0].x, v[0].y);
    //cout << pa.x << " " << v[0].x << endl;
    for (int i = 1; i < npkgs; ++i)
    {
        POINT p(v[i].x, v[i].y) /*p = current point or package*/, t1(pa.y * p.x, pa.x * p.y), t2(pz.y * p.x, pz.x * p.y); //cross xs * ys
        
        if (t1.x == t1.y)
            if (pa.x * p.x + pa.y * p.y <= 0)
                return true;
            else
                continue;
        else if (t2.x == t2.y)
            if (pz.x * p.x + pz.y * p.y <= 0)
                return true;
            else
                continue;
        else
        {
            if (t1.x < t1.y)
                pa = p;
            
            if (t2.x > t2.y)
                pz = p;
            
            if (pa == pz)
                return true;
            else if (pa.y * pz.x == pz.y * pa.x)
                if (pa.x * pz.x + pa.y * pz.y <= 0)
                    return true;
                else
                    continue;
            else if (pa.y * pz.x < pz.y * pa.x)
                return true;
        }
    }
    return false;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.8.input");

    int n;
    while (cin>>n && n>0)
    {
        v.clear();
        for(int i=0; i<n; i++)
        {
            POINT p;
            cin >> p.x >> p.y >> p.z;
            v.push_back(p);
        }
        
        //if (repackage(n))
        if (linear_programming_simplex_method(n))
            cout << "Yes" << endl;
        else
            cout << "No" << endl;
        
        //moussa_solution();
    }
    return 0;
}

/*
 I solved this problem by reducing it to 2D convex hull and checking if one point (representing the package k,k,k) lies inside the convex hull.
 But with the other method: you could use simplex to check if there is a solution.
*/

/*convux hull checking algorithm
 
 Hi I'm trying to solve that problem but absolutely stuck. Here what I do:
 1. Convert package (s1,s2,s3) to 2D vector [s2-s1,s3-s1]
 2. Sort it by angle
 3. If angle of 2 neighbor vectors is exceed pi than there is no solution, otherwise it has solution
 
 By the way, try problem 802 (Lead or Gold) after this one, it's similar.

 et the 3 packages be (p11,p12,p13 ), (p21,p22,p23) and (p31,p32,p33), now we have to find X,Y,Z such that
 
 X*p11 + Y*p21 + Z*p31 = k
 X*p12 + Y*p22 + Z*p32 = k
 X*p13 + Y*p23 + Z*p33 = k
 and X+Y+Z>0 and k > 0
 P=
 {
 [ p11 p21 p31 ]
 [ p12 p22 p32 ]
 [ p13 p23 p33 ]
 }
 
 Q={ X,Y,Z}
 p*Q = k*I

 
 A linear combinations of vectors (s2[i] - s1[i], s3[i] - s1[i]) is zero if and only if the same linear combination of vectors (s1[i], s2[i], s3[i]) is a vector with three equal components, namely, all equal to this linear combination of s1[i]'s. It's just simple algebra and manipulations of sums. It doesn't deserve to be called a theorem, or even lemma

**/