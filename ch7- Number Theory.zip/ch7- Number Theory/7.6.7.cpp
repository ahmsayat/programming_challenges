//////////////////////////////////////////////////////
//
//  7.6.7 Marbles
//  PC/UVa IDs: 110707/10090, Popularity: B, Success rate: low Level: 1
//  programming_challenges
//  Created by Moussa on 28-FEB-2015 09:45 PM
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <bitset>

using namespace std;

int c1, c2, n1, n2;

//find m1 and m2 that satisfy the equation  n1 * m1 + n2 * m2 = n, and gives the minimum cost where cost = c1 * m1 + c2 * m2 .
void moussa_solution(int n)
{
    int maxn1 = n / n1;
    int min_cost = INT_MAX, min_m1, min_m2;
    for (int m1=1; m1<=maxn1; m1++)
    {
        int v1 = n1*m1;
        int v2 = (n - v1);
        int m2 = v2 / n2;
        
        if (m2 * n2 == v2) //valid and no fractions
        {
            int cost = c1 * m1 + c2 * m2;
            if (cost < min_cost) //store lowest cost
            {
                min_cost = cost;
                min_m1 = m1;
                min_m2 = m2;
            }
        }
    }
    
    if (min_cost == INT_MAX)
        cout << "failed" << endl;
    else
        cout << min_m1 << " " << min_m2 << endl;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.7.input");
    
    /*
    int i = 0;
    while (i<2000000000)
        i++;
    */
    
    for (int n; cin>>n && n>0; )
    {
        cin >> c1 >> n1 >> c2 >> n2;
        moussa_solution(n);
    }
    
    return 0;
}

/* Another solution using egcd:
 https://tutorial92.wordpress.com/2012/09/17/uva-10090-marbles-tutorial/
 uva 10090 – Marbles – tutorial

 We want to find m1 and m2 that satisfy the equation  n1 * m1 + n2 * m2 = n, and give us the minimum cost where cost = c1 * m1 + c2 * m2 .
 
 Using extended Euclid to find gcd(n1,n2) and get m1`,m2` where n1 * m1` + n2 * m2` = gcd(n1,n2)
 
 to get m1 and m2 multiply both sides by n/gcd m1`=m1`*n/gcd , m2`=m2`*n/gcd.
 
 Now m1 = m1 + n2 / g * t  , m2 = m2 –  n1 / g * t   any integer t satisfy the desired equation, but we want to minimize the cost  c = c1 * m1 + c2 * m2 = c1 * ( m1 + n2 / g * t )  +   c2 * ( m2 – n1 /g * t) = c1*m1 +c2*m2 + t * (c1* n2/g – c2 *n1/g).
 
 Since c1*m1 +c2*m2  is constant we want to minimize  t * (c1* n2/g – c2 *n1/g)
 
 How to get t ?
 
 As we mention above m1 = m1 + n2 / g * t  , m2 = m2 –  n1 / g * t , m1 && m2 >=0
 
 So m1 + n2 / g * t >=0 ,  n2 / g * t >= – m1 ,  t >= – m1 *g / n2
 
 Also m2 –  n1 / g * t>=0  ,  – n1 / g * t >= – m2 , t <= m2 * g / n1
 
 so ceil(-m1*g/n2) <= t <= floor(m2*g/n1),
 
 Now  just check the two boundaries, and choose the one that give you the cheaper cost.

 #include <iostream>
 #include <cstdio>
 #include <math.h>
 #include <algorithm>
 
 using namespace std;
 long x, y; // result
 long c1, n1, c2, n2, n; // input
 
 void ex_gcd(long a, long b, long &d, long &x, long &y) {
 if (b == 0) {
 x = 1, y = 0, d = a;
 return;
 }
 long x1, y1;
 ex_gcd(b, a % b, d, x1, y1);
 x = y1;
 y = x1 - (a / b) * y1;
 }
 
 bool check() {
 long gcd, m1, m2;
 ex_gcd(n1, n2, gcd, m1, m2);
 if (n % gcd != 0)
 return false;
 m1 *= n / gcd, m2 *= n / gcd;
 n2 /= gcd, n1 /= gcd;
 long c = ceil(-(double) m1 / n2), f = floor((double) m2 / n1);
 if (c > f)
 return false;
 long cost = c1 * n2 - c2 * n1;
 if (cost * c < cost * f)
 x = m1 + n2 * c, y = m2 - n1 * c;
 else
 x = m1 + n2 * f, y = m2 - n1 * f;
 return true;
 }
 
 int main() {
 while (scanf("%ld", &n) != EOF && n != 0) {
 scanf("%ld%ld%ld%ld", &c1, &n1, &c2, &n2);
 if (check())
 printf("%ld %ld\n", x, y);
 else
 printf("failed\n");
 }
 return 0;
 }
*/
