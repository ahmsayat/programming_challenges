//////////////////////////////////////////////////////
//
//  7.6.3 Euclid Problem
//  PC/UVa IDs: 110703/10104, Popularity: A, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 18-FEB-2015 06:05 PM, Sakr Koresh
//  Copyright (c) 2015 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>
#include <bitset>

using namespace std;

//greatest common divisor
long gcd (long a, long b)
{
    if (b > a)
        return gcd(b, a);
    else if(b == 0)
        return a;
    else return gcd(b, a%b);
};

long lcm (long a, long b)
{
    return (a*b) / gcd(a, b);
};

void Euclid(long &x, long &y, long d)
{
    x = 10;
    y = 200;
};

/* Pseudocode
function extended_gcd(a, b)
    s := 0;    old_s := 1
    t := 1;    old_t := 0
    r := b;    old_r := a
    while r ≠ 0
        quotient := old_r div r
        (old_r, r) := (r, old_r - quotient * r)
        (old_s, s) := (s, old_s - quotient * s)
        (old_t, t) := (t, old_t - quotient * t)
    output "Bézout coefficients:", (old_s, old_t)
    output "greatest common divisor:", old_r
    output "quotients by the gcd:", (t, s)
*/

pair<int,int> extended_gcd(int a, int b )
{
    /*
     a*x + b*y = gcd (a,b);
     return (x,y);
     */
    if(!b)
        return make_pair(1,0);
    else
    {
        //pair<int,int>qr ( a/b , a%b );
        pair<int,int>st = extended_gcd(b, a%b);
        return make_pair(st.second , st.first - (a/b * st.second));
    }
}

struct e
{
    int quotient , Remainder, s, t;
    e(int quotient , int Remainder, int s, int t) : quotient(quotient) , Remainder(Remainder), s(s), t(t) {};
};

vector<e> v;

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch7- Number Theory/7.6.3.input");
    long A, B, D, X, Y;
    
    //extended Euclidean algorithm will give the solution
    for (;cin>>A>>B;)
    {
        
        pair<int,int> ans = extended_gcd(A,B);
        printf("%d %d %d\n", ans.first, ans.second, (ans.first*A) + (ans.second*B) );
 
        
        if (B>A) {
            long temp = A;
            A = B;
            B = temp;
        }
        
        v.clear();
        v.push_back(e(0, A, 1, 0));
        v.push_back(e(0, B, 0, 1));
        
        int i= 1;
        for (int r = A % B;  r > 0; i++)
        {
            int q = v[i-1].Remainder / v[i].Remainder;
            r = v[i-1].Remainder % v[i].Remainder;
            int s = v[i-1].s -  q * v[i].s;
            int t = v[i-1].t -  q * v[i].t;
            v.push_back(e(q, r, s, t));
            
            //v.push_back(e(v[i-1].Remainder / v[i].Remainder, r=v[i-1].Remainder % v[i].Remainder, v[i-1].s -  v[i-1].Remainder / v[i].Remainder * v[i].s, v[i-1].t -  v[i-1].Remainder / v[i].Remainder * v[i].t));
        }
        
        //Euclid(X, Y, D = gcd(A, B)); //wow i can pass and assign the return value of a function as a parameter to another function
        cout << v[i-1].t << " " << v[i-1].s << " " << v[i-1].Remainder << endl;
    }
    
    return 0;
}

/*Notes:
1) Bézout's identity in math
2) extended Euclidean algorithm

 The following table shows how the extended Euclidean algorithm proceeds with input 240 and 46. The greatest common divisor is the last non zero entry, 2 in the column "remainder". The computation stops at row 6, because the remainder in it is 0. Bézout coefficients appear in the last two entries of the second-to-last row. In fact, it is easy to verify that -9 × 240 + 47 × 46 = 2. Finally the last two entries 23 and -120 of the last row are, up to the sign, the quotients of the input 46 and 240 by the greatest common divisor 2.
 index i	quotient qi-1	Remainder ri	si	ti
 0		240	1	0
 1		46	0	1
 2	240 ÷ 46 = 5	240 − 5 × 46 = 10	1 − 5 × 0 = 1	0 - 5 × 1 = -5
 3	46 ÷ 10 = 4	46 − 4 × 10 = 6	0 − 4 × 1 = -4	1 - 4 × -5 = 21
 4	10 ÷ 6 = 1	10 − 1 × 6 = 4	1 − 1 × -4 = 5	-5 - 1 × 21 = -26
 5	6 ÷ 4 = 1	6 − 1 × 4 = 2	-4 − 1 × 5 = -9	21 - 1 × -26 = 47
 6	4 ÷ 2 = 2	4 − 2 × 2 = 0	5 − 2 × -9 = 23	-26 - 2 × 47 = -120

 
 
*/