//////////////////////////////////////////////////////
//
//  4.6.4 Longest Nap
//  PC/UVa IDs: 110404/10191, Popularity: B, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 24-DEC-2014 2:37 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>

using namespace std;

vector<string> appointment;

struct TIME
{
    int hour;
    int min;
};

/*
struct APPT
{
    TIME start;
    TIME end;
};*/

class APPT
{
public:
    int s;
    int e;
};

int toInt(string s)
{
    int n;
    stringstream ss(s);
    ss>>n;
    return n;
}

TIME getStartTime(string s)
{
    TIME temp;
    string h = s.substr(0,2);
    string m = s.substr(3,2);
    
    //cout<<h<<" "<<m<<endl;
    
    temp.hour = toInt(h);
    temp.min = toInt(m);
    
    return temp;
}

TIME getEndTime(string s)
{
    TIME temp;
    string h = s.substr(6,2);
    string m = s.substr(9,2);
    
    //cout<<h<<" "<<m<<endl;
    
    temp.hour = toInt(h);
    temp.min = toInt(m);

    return temp;
}

int getStartTimeAsInt(string s)
{
    int temp;
    string h = s.substr(0,2);
    string m = s.substr(3,2);
    
    //cout<<h<<" "<<m<<endl;
    
    temp = toInt(h) * 100 + toInt(m); //float(toInt(m) / 60.0) * 100.0; //convert minutes fractions to 100 percentages
    
    return temp;
}

int getEndTimeAsInt(string s)
{
    int temp;
    string h = s.substr(6,2);
    string m = s.substr(9,2);
    
    //cout<<h<<" "<<m<<endl;
    
    temp = toInt(h) * 100 + toInt(m);//float(toInt(m) / 60.0) * 100.0; //convert minutes fractions to 100 percentages
    
    return temp;
}

void print(APPT myappt)
{
    //cout<< myappt.start.hour << myappt.start.min << " => " << myappt.end.hour <<  myappt.end.min << endl;
    cout<< myappt.s << " => " << myappt.e << endl;
}

void print(APPT *myappt[], int n)
{
    for (int i=1; i<=n; i++)
        cout<< myappt[i]->s << " => " << myappt[i]->e << endl;
}

bool cmp(APPT * a, APPT * b)
{
    if (a->s < b->s) //return true with < because we want ascending order so a < b
        return true;
    else
        return false;
};

float time_diff(int a, int b)
{
    float ha = a/100, hb = b/100, ma = a%100, mb = b%100;
    float hd = ha - hb, md = float(ma/60.0) - float(mb/60.0);
    return hd + md;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.4.input");
    
    //data structure
    int N; string s; int TestCase = 1;
    
    //read input
    while (cin>>N && getline(cin, s)) //get line to get the endline marks \r
    {
        
        appointment.clear();
        
        APPT *apps[N+1];
        
        //for (int i=1; i<=N; i++) myappt[i] = new APPT();
        APPT *myappt = new APPT();
        myappt->s = 1000;
        myappt->e = 1000;
        apps[0] = myappt;
        
        for (int i=1; i<=N; i++)
        {
            APPT *myappt = new APPT();
            
            getline(cin, s);
            appointment.push_back(s);
            //myappt[i]->start = getStartTime(s);
            //myappt[i]->end = getEndTime(s);
            int a = getStartTimeAsInt(s), b = getEndTimeAsInt(s);
            myappt->s = a;
            myappt->e = b;
            
            apps[i] = myappt;
        }
        
        sort(apps+1, apps+N+1, cmp);
        
        float naps[N+1];
        naps[0] = time_diff(apps[1]->s , 1000);
        for (int i=1; i<N; i++)
            naps[i] = time_diff(apps[i+1]->s , apps[i]->e);
        naps[N] = time_diff(1800  , apps[N]->e);
        
        //print(apps, N);
        
        //for (int i=0; i<=N; i++) cout<<naps[i]<<endl;
        
        float max = 0; int max_index = 0;
        for (int i=0; i<=N; i++)
            if(naps[i] > max)
            {
                max_index = i;
                max = naps[i];
            }
        
        //cout<<max<<endl;
        stringstream ss; ss<<apps[max_index];

        cout << "Day #" << TestCase++ << ": the longest nap starts at " << apps[max_index]->e/100 << ":" <<  /*fixed << */ setw(2) << float(apps[max_index]->e%100) << " and will last for ";
        
        ((int)max/1 > 0)? cout << (int)max/1 << " hours and ": cout<<"";
        
        cout<< (max-((int)max/1)) /* get decimal part */ * 60 /* convert percentage to minutes part of 1 hour */<< " minutes." << endl;
        
        //  hh : mm and will last for [H hours and] M minutes. where d stands for the number of the test case (starting from 1) and hh : mm is the time when the nap can start.
        
        //cout << N << endl;
        
        //int h,m,h2,m2; cin >> h >> m >> h2 >> m2; cout<< h << m << h2 << m2 << endl;
    }

    return 0;
}

/******/