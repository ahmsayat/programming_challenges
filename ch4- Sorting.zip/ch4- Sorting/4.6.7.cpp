//////////////////////////////////////////////////////
//
//  4.6.7 ShellSort
//  PC/UVa IDs: 110407/10152, Popularity: B, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 25-DEC-2014 1:47 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

vector<string> original;
map<string, int> wanted;

void print()
{

};

//it is very tricky as we compare  [days(b) * fine(a)] vs [days(a) * fine(b)]
bool mycmp(string a, string b)
{
    if (true)
        return true;
    else
        return false;
};

string find_with_key(int i)
{
    for (map<string, int>::iterator it = wanted.begin(); it != wanted.end(); it++)
        if(i == it->second)
            return it->first;
    return "NOT FOUND";
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.7.input");
    
    //data structure
    int TestCases; cin >> TestCases;
    
    while (TestCases--)
    {
        original.clear(); wanted.clear();
        
        //read input
        int N; cin >> N; string s; getline(cin, s); //cout<<s<<endl;
        for (int i=1; i<=N; i++) { getline(cin, s); original.push_back(s); }
        for (int i=1; i<=N; i++) { getline(cin, s); wanted[s] = i; }
        
        //for (int i=1; i<=N; i++) cout<<wanted[original[i-1]];
        
        //find what is out of the increasing order maximum number
        int max = -1;
        for (int i=1; i<N; i++)
            if(wanted[original[i]] < wanted[original[i-1]])
                if(wanted[original[i]] > max)
                    max = wanted[original[i]];
        
        //cout<<max<<endl;
        //print solution as simple as iterating while printing values from max to 1
        for (int i=max; i>=1; i--)
            cout<<find_with_key(i)<<endl;
        
        cout << endl;
        //cout<<endl<<wanted.size()<<endl;
    }
    
    return 0;
}
