//////////////////////////////////////////////////////
//
//  4.6.8 Football (aka Soccer)
//  PC/UVa IDs: 110408/10194, Popularity: B, Success rate: average Level: 1
//  programming_challenges
//  Created by Moussa on 25-DEC-2014 3:54 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

vector<string> original;

map<string, int> wanted;

struct result
{
    //ctor
    result(): a(0),b(0),c(0),d(0),e(0),f(0),g(0),h(0),i(0)
    {}
    
    //where a = team rank, b = total points earned, c = games played, d = wins, e = ties, f = losses, g = goal difference, h = goals scored, i is goals against.
    int a,b,c,d,e,f,g,h,i;
};

map<string, result> tournment;

vector<string> teams;

void print()
{
    for (map<string, result>::iterator it = tournment.begin(); it != tournment.end(); it++)
    {
        result r = it->second;
        cout<< r.a << ") " << it->first << " " << r.b << "p, " << r.c << "g (" << r.d << "-" << r.e << "-" << r.f << "), " << r.g << "gd (" << r.h << "-" << r.i << ")"<<endl;
    }
};

void print2()
{
    for (int i=0; i<teams.size(); i++)
    {
        result r = tournment[teams[i]];
        cout<< i+1 << ") " << teams[i] << " " << r.b << "p, " << r.c << "g (" << r.d << "-" << r.e << "-" << r.f << "), " << r.g << "gd (" << r.h << "-" << r.i << ")"<<endl;
    }
};

//it is very tricky as we compare  [days(b) * fine(a)] vs [days(a) * fine(b)]
bool mycmp(string a, string b)
{
    //where a = team rank, b = total points earned, c = games played, d = wins, e = ties, f = losses, g = goal difference, h = goals scored, i is goals against.
    /*
     Teams are ranked according to these rules (in this order): 
     1. Most points earned.
     2. Most wins.
     3. Most goal difference (i.e., goals scored – goals against) 
     4. Most goals scored.
     5. Fewest games played.
     6. Case-insensitive lexicographic order.
    */
    if (tournment[a].b >  tournment[b].b)
        return true;
    else if((tournment[a].b <  tournment[b].b))
        return false;
    else //equal points
    {
        if (tournment[a].d >  tournment[b].d)
            return true;
        else if((tournment[a].d <  tournment[b].d))
            return false;
        else //equal wins
        {
            if (tournment[a].g >  tournment[b].g)
                return true;
            else if((tournment[a].g <  tournment[b].g))
                return false;
            else //equal goals diffs
            {
                if (tournment[a].h >  tournment[b].h)
                    return true;
                else if((tournment[a].h <  tournment[b].h))
                    return false;
                else //equal goals
                {
                    if (tournment[a].c < tournment[b].c)
                        return true;
                    else if((tournment[a].c >  tournment[b].c))
                        return false;
                    else //equal games played
                    {
                        // Case-insensitive lexicographic order.
                        if(a < b)
                            return true;
                        else
                            return false;
                        //no two teams will have the same name so equal names is not an exist case
                    }
                }
            }
        }
    }
    
};

string find_with_key(int i)
{
    for (map<string, int>::iterator it = wanted.begin(); it != wanted.end(); it++)
        if(i == it->second)
            return it->first;
    return "NOT FOUND";
}

int toInt(string s)
{
    stringstream ss; ss<<s; int n; ss>>n;
    return n;
}

void update(string s)
{
    int index_hash1 = -1, index_hash2 = -1, index_at = -1;
    index_at = s.find('@');
    index_hash1 = s.substr(0, index_at+1).find('#');
    index_hash2 = index_at + s.substr(index_at).find('#');
    string team1 = s.substr(0, index_hash1);
    string team2 = s.substr(index_hash2+1, s.size() - index_hash2 - 2);
    int score1 = toInt(s.substr(index_hash1+1, index_at - index_hash1 - 1)), score2 = toInt(s.substr(index_at + 1, index_hash2 - index_at - 1));
    
    //cout<< team1 << " : " << score1 << " vs " <<  team2 << " : " << score2 << endl;
    //cout<< index_hash1 << " " << index_at << " " << index_hash2 << endl;
    if (team2 == "Team ")
        cout<< "wanring" << endl;
    
    //Team 1
    tournment[team1].a+=0;
    tournment[team1].b+= (score1 == score2)? 1 : (score1 < score2)? 0 : 3;
    tournment[team1].c+=1;
    tournment[team1].d+= (score1 > score2)? 1 : 0;
    tournment[team1].e+= (score1 == score2)? 1 : 0;
    tournment[team1].f+= (score1 < score2)? 1 : 0;
    tournment[team1].g+= score1-score2;
    tournment[team1].h+=score1;
    tournment[team1].i+=score2;
    
    
    //Team 2
    tournment[team2].a+=0;
    tournment[team2].b+= (score1 == score2)? 1 : (score2 < score1)? 0 : 3;
    tournment[team2].c+=1;
    tournment[team2].d+= (score2 > score1)? 1 : 0;
    tournment[team2].e+= (score1 == score2)? 1 : 0;
    tournment[team2].f+= (score2 < score1)? 1 : 0;
    tournment[team2].g+= score2-score1;
    tournment[team2].h+=score2;
    tournment[team2].i+=score1;
    
    //where a = team rank, b = total points earned, c = games played, d = wins, e = ties, f = losses, g = goal difference, h = goals scored, i is goals against.
    
    //cout<<s<<endl;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.8.input");
    
    //data structure
    int TestCases;
    string s; getline(cin, s); TestCases = toInt(s);
    
    while (TestCases--)
    {
        tournment.clear();
        teams.clear();
        
        //output tournment name
        getline(cin, s); cout<< s << endl;
        
        //read teams
        getline(cin, s); int T = toInt(s);
        while (T--) { getline(cin, s); s=s.substr(0, s.size()-1); teams.push_back(s); tournment[s] = result(); }
        
        //read tournments games
        getline(cin, s);  int G = toInt(s);
        while (G--) { getline(cin, s); update(s);}
        
        //print();
        
        sort(teams.begin(), teams.end(), mycmp);
        
        print2();
        
        cout << endl;
    }
    
    return 0;
}
