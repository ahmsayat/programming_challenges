//////////////////////////////////////////////////////
//
//  4.6.5 Shoemaker’s Problem
//  PC/UVa IDs: 110405/10026, Popularity: C, Success rate: average Level: 2
//  programming_challenges
//  Created by Moussa on 24-DEC-2014 7:44 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>

using namespace std;

vector<pair<pair<int, int>, int>> jobs;

void print()
{
    for (vector<pair<pair<int, int>, int>>::iterator it = jobs.begin(); it != jobs.end(); it++)
    {
        pair<int, int> job = it->first;
        cout<< it->second  << "# " << job.first << " " << job.second << endl;
    }
};

void print2()
{
    for (vector<pair<pair<int, int>, int>>::iterator it = jobs.begin(); it != jobs.end(); it++)
    {
        pair<int, int> job = it->first;
        cout<< it->second  << " ";
    }
    cout << endl;
};

//it is very tricky as we compare  [days(b) * fine(a)] vs [days(a) * fine(b)]
bool mycmp(pair<pair<int, int>, int> a, pair<pair<int, int>, int> b)
{
    if (b.first.first *  a.first.second > a.first.first * b.first.second) //return true with > because we want descending order regarding fine paid
        return true;
    else
        return false;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.5.input");
    
    //data structure
    int TestCase = 1; cin>>TestCase;
    
    
    while (TestCase--)
    {
        jobs.clear();
        int N; cin>>N;
        
        //read input
        for (int i=1; i<=N; i++)
        {
            int T, S;
            cin >> T >> S;
            pair<int,int> p (T,S);
            pair<pair<int, int>, int> pair_pair(p, i);
            jobs.push_back(pair_pair);
        }
        
        //sort
        sort(jobs.begin(), jobs.end(), mycmp); //sort [a,b) where a is vector begin and b is vector end because end iterator points to an element after vector actual last element.
        //print();
        print2();
    }
    
    return 0;
}
