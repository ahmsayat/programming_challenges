//////////////////////////////////////////////////////
//
//  4.6.2 Stacks of Flapjacks
//  PC/UVa IDs: 110402/120, Popularity: B, Success rate: high Level: 2
//  programming_challenges
//  Created by Moussa on 19-DEC-2014 12:15 AM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>

using namespace std;

#define pancakes 30 //[1-30]

int arr[pancakes];

int N;

void flip(int k)
{
    cout<<N - k + 1<< " ";
    reverse(arr, arr + k);
}

void mysort()
{
    for (int i=0; i<N; i++)
        for (int j=N-1; j>i+1; j--)
            if(arr[j] < arr[i])
            {
                //flip(j+1);
                cout<<N - j<< " ";
                reverse(arr, arr + j+1);
                mysort();
            }
}

//standard deviation from the mean problem
int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.2.input");
    
    //data structure
    string s; int t;
    
    //read input
    while ( getline(cin, s) && s != "\r" )
    {
        stringstream ss; ss << s; N = 0;
        while (ss>>t)
            arr[N++] = t;
        for (int i=0; i<N; i++) cout<<arr[i]<<" ";
        cout<< endl;
        mysort();
        cout << 0 << endl;
    }
   return 0;
}