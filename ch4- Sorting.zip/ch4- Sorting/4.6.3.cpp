//////////////////////////////////////////////////////
//
//  4.6.3 Bridge
//  PC/UVa IDs: 110403/10037, Popularity: B, Success rate: low Level: 3
//  programming_challenges
//  Created by Moussa on 19-DEC-2014 8:15 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>

using namespace std;

#define people 100 //[1-30]

int arr[people];

int N;

set<int> left_team, right_team;

stack<int> st;

queue<string> solution;

set<int>::iterator get_minimum()
{
    int min = INT_MAX;
    set<int>::iterator min_it;
    for(set<int>::iterator it=left_team.begin(); *it != 0 && it != left_team.end(); it++)
     if(*it < min)
      { min = *it; min_it = it; }
    return min_it;
}

//always return from right the flashlight with the fastest which has lowest cross time
int move_from_right()
{
    set<int>::iterator min_it = get_minimum();
    left_team.insert(*min_it);
    right_team.erase(*min_it);
    return arr[*min_it];
}

//select two with minimal savings
int move_from_left()
{
    //if (left_team.empty()) return 0;
    for (set<int>::iterator it1=left_team.begin(); *it1 != 0 && it1 != left_team.end(); )
    {
     for (set<int>::iterator it2=it1; *it2 != 0 && it2 != left_team.end(); it2++)
      if(*it1 != *it2)
        {
            cout<<*it1<< " " << *it2 <<endl;
            right_team.insert(*it1);
            right_team.insert(*it2);
            
            //set<int>::iterator temp2 = it2; left_team.erase(*temp2);
            //cout << max(*it1, *it2) << endl;
        }
        set<int>::iterator temp1 = it1++;
        left_team.erase(*temp1);
        //move_from_left();
    }
}

void move(bool from_left)
{
    if (from_left)
    {
        
    }
    else
    {
        
    }
}

//Simplest Solution I inspired from the explanation on https://codingstrife.wordpress.com/2013/07/23/solution-uva10037-pc110403-bridge/
int recus(int people_left)
{
    if (people_left <= 3) {
        switch (people_left) {
            case 1:
                cout<<arr[1]<<endl;
                return arr[1];
                break;
            case 2:
                cout << arr[1] << " " << arr[2] << endl;
                return arr[2];
                break;
            case 3: //a,b,c move a + b then return a then move a + c
                cout << arr[1] << " " << arr[3] << endl;
                cout << arr[1] << endl;
                cout << arr[1] << " " << arr[2] << endl;
                return arr[1] + arr[2] + arr[3];
                break;
            default:
                return 0;
                break;
        }
    }
    else
    {
        int score;
        int A = arr[1] /*fastest_a*/, B = arr[2] /*fastest_b*/;
        int Z = arr[people_left] /*slowest_z*/, Y = arr[people_left-1] /*slowest_y*/;
        
        /*
        //AZ => A => AY => A ->(1)
        //AB => A => YZ => B ->(2)
        //from (1) & (2) times are
        //Z + A + Y + A => Y + Z + 2A  => Y + 2A => Y+A
        //B + A + Z + B => A + 2B + Z  => A + 2B => 2B
        //Use strategy Y + A or 2B? 
        */
        if(A + Y < 2*B)
        {  //using A only
            cout << A << " " << Z << endl; //AZ
            cout << A << endl; //A
            cout << A << " " << Y <<endl; //AY
            cout << A << endl; //A
            score = Z + A + Y + A;
        }
        else
        {   //using A and B
            cout << A << " " << B << endl; //AB
            cout << A << endl; //A
            cout << Y << " " << Z <<endl; //YZ
            cout << B << endl; //B
            score = B + A + Z + B;
        }
        
        return score + recus(people_left-2);
    }
}

int cnt_recus(int people_left)
{
    if (people_left <= 3) {
        switch (people_left) {
            case 1:
                return arr[1];
                break;
            case 2:
                return arr[2];
                break;
            case 3:
                return arr[1] + arr[2] + arr[3];
                break;
            default:
                return 0;
                break;
        }
    }
    else
    {
        int score;
        int A = arr[1] /*fastest_a*/, B = arr[2] /*fastest_b*/;
        int Z = arr[people_left] /*slowest_z*/, Y = arr[people_left-1] /*slowest_y*/;

        if(A + Y < 2*B)
            score = Z + A + Y + A;
        else
            score = B + A + Z + B;
        
        return score + cnt_recus(people_left-2);
    }
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.3.input");
    
    //data structure
    int T; cin>>T;
    
    //read input
    while (T--)
    {
        cin>>N;
        for (int i=1; i<=N; i++) { cin >> arr[i]; left_team.insert(arr[i]); }
        //for(int i=1; i<=N; i++) cout << arr[i] << " "; cout<<endl;
        //move_from_left();
        sort(arr, arr + N);
        cout << cnt_recus(N) << endl;
        recus(N);
    }
    
    //for(int i=1; i<=N; i++) st.push(arr[i]);
    
    //left_team.insert(5);
    //left_team.insert(50);
    //left_team.insert(15);
    
    return 0;
}

/******
Moving 3 people from left to right side: (1 optimal strategy)
if people = a,b,c with a as fastest we have all these possibilities
(a,b)     b + a + c    b + b + c
(a,c)     c + a + b    c + c + c
(c,b)     c + b + b    c + c + c
then find which strategy is fastest, eliminate c from all
 (a,b)     b + a    b + b
 (a,c)     a + b    c + c
 (c,b)     b + b    c + c
 
we have a + b   vs  b + b   vs  c + c
or      a + b   vs   2b     vs   2c
if c>b then 2c > 2b then 2b is better than 2c
then comparing 2b with a+b by eleminating b from both sides
a+b or 2b
then clearly it is a < b
so, a + b + c is the optimal strategy by choosing (a,b) or (a,c) and returning back the light with a

***************************************************************
 //how to reduce the problem? by moving 2 people of 4 or 5 or more to the other side
 //AZ => A => AY => A ->(1)
 //AB => A => YZ => B ->(2)
 //YZ => Y => AY => A : slow since Y>A
from (1) & (2) times are 
 Z + A + Y + A => Y + Z + 2A
 B + A + Z + B => A + 2B + Z
 eliminate Z from both
 Y + 2A 
 A + 2B
 then remove A from both
 Y + A
 2B
*/