//////////////////////////////////////////////////////
//
//  4.6.1 Vito’s Family
//  PC/UVa IDs: 110401/10041, Popularity: A, Success rate: high Level: 1
//  programming_challenges
//  Created by Moussa on 18-DEC-2014 07:33 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>

using namespace std;

int compare_c(int * a, int * b)
{
    if (*a == *b)
        return 0;
    if (*a < *b)
        return -1;
    if (*a > *b)
        return 1;
}

//we are saying we wanted to sort descending because i>j
bool compare_cpp11(int a, int b)
{
    return a > b;
}

//standard deviation from the mean problem
int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.1.input");
    
    //data structure
    int T; cin>>T;
    
    //read input
    while (T--)
    {
        int r; cin>>r;
        int arr[r];
        for (int i = 0; i<r; i++)
            cin >> arr[i];

        /* How to use sort functions in C++ 11 */
        //sort(&arr[0], &arr[r]); //[First,Last)
        sort(arr, arr + r, compare_cpp11); //first last range pointers
        //sort(begin(arr), end(arr));
        
        //qsort((char *) arr, 10, sizeof(int));
        //qsort(arr, sizeof(arr), sizeof(arr), compare);
        
        int avg = 0;
        for (int i = 0; i<r; i++)
            avg+=arr[i];
        avg/=r;
        
        int deviation = 0;
        for (int i = 0; i<r; i++)
            deviation+=abs(arr[i]-avg);
        
        //print output
        cout<<deviation<<endl;
    }
    
   return 0;
}