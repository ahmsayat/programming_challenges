//////////////////////////////////////////////////////
//
//  4.6.6 CDVII
//  PC/UVa IDs: 110406/10138, Popularity: C, Success rate: low Level: 2
//  programming_challenges
//  Created by Moussa on 24-DEC-2014 8:34 PM
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include <stdlib.h>
#include <set>
#include <vector>
#include <deque>
#include <stack>
#include <queue>
#include <iomanip>
#include <map>

using namespace std;

float fare_structure[24]; //fare in dollars per KM

//single plate photo
struct Photo
{
    int month, day, hour, minute, location; string enter_or_exit;
};

//hash a license plate to all its photos
map<string, vector<Photo>> Plate;

void print()
{
    for (map<string, vector<Photo>>::iterator it = Plate.begin(); it != Plate.end(); it++)
    {
        float  bill = 0;
        cout<< it->first << " $";
        for (int i=0; i<it->second.size() - 1; i++) // size - 1 because we will consider i and i+1
            if ( (it->second[i].enter_or_exit == "enter") && (it->second[i+1].enter_or_exit == "exit") ) //captured one trip
            {
                float distance = abs(it->second[i].location - it->second[i+1].location);
                float rate = fare_structure[it->second[i].hour] / 100.0; //use the rate when the car entered the road using the hour of entrance.
                bill = bill + rate * distance + 1; //plus one dollar per trip
            }
        cout<< setprecision(2) << fixed << bill+2 << endl; //plus a two dollar account charge
    }
};

//it is very tricky as we compare  [days(b) * fine(a)] vs [days(a) * fine(b)]
bool mycmp(Photo a, Photo b)
{
    if (a.day * 24 * 60 + a.hour * 60 + a.minute < b.day * 24 * 60 + b.hour * 60 + b.minute)
        return true;
    else
        return false;
};

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/ch4- Sorting/4.6.6.input");
    
    //data structure
    int TestCases; cin >> TestCases;
    
    while (TestCases--)
    {
        //read fare structures for hours from 00:00-00:59, 01:00-01:59, 02:00-02:59, ... , 23:00-23:59
        for (int i=1; i<=24; i++) cin >> fare_structure[i-1];
        
        Plate.clear();
        
        string license;
        Photo photo;
        char c;
    
        //read input
        while (cin >> license >> photo.month >> c >> photo.day >> c >> photo.hour >> c >> photo.minute >> photo.enter_or_exit >> photo.location) Plate[license].push_back(photo);
        
        //sort photos chronologically
        for (map<string, vector<Photo>>::iterator it = Plate.begin(); it != Plate.end(); it++) sort(it->second.begin(), it->second.end(), mycmp); //sort [a,b)
        
        print();
    }
    
    return 0;
}
