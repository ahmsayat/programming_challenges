class Generic_Chess_ Skeleton
{
	char chess[8][8];
    
	int white_king_i, white_king_j, black_king_i, black_king_j;
    
	#define double_loop for (int i=0; i<8; i++) for (int j=0; j<8; j++)

	//soliders
	bool Pawn(bool whites)
	{
	    if(whites)
	    {
	        double_loop if (chess[i][j] == 'P')
	        {
	            if( (i-1 == black_king_i && j-1 == black_king_j) || (i-1 == black_king_i && j+1 == black_king_j) )
	               return true;
	        }
	    }
	    else
	    {
	        double_loop if (chess[i][j] == 'p')
	        {
	            if( (i+1 == white_king_i && j-1 == white_king_j) || (i+1 == white_king_i && j+1 == white_king_j) )
	                return true;
	        }
	    }
    
	    return false;
	};

	//move a step forward in any of the 8 directions
	//move
	bool hit(int xdirection, int ydirection, int i, int j, int iking, int jking)
	{
	    while(true)
	    {
	        if (i == iking && j == jking)
	            return true;
        
	        if (chess[i][j] == '.')
	        {
	            i+=xdirection;
	            j+=ydirection;
	        }
	        else
	            return false;
	    }
	};

	//+
	bool Rook(bool whites)
	{
	    if(whites)
	    {
	        double_loop if (chess[i][j] == 'R')
	        {
	            if(i ==  black_king_i) //horizontal
	             return (j<black_king_j)?
	                 hit(+1, 0, i+0, j+1, black_king_i, black_king_j)
	                  :
	                 hit(-1, 0, i+0, j-1, black_king_i, black_king_j);
    
	            if(j ==  black_king_j) //vertical
	             return (i<black_king_i)?
	                hit(0, +1, i+1, j+0, black_king_i, black_king_j)
	                 :
	                hit(0, -1, i-1, j+0, black_king_i, black_king_j);
	        }
	    }
	    else
	    {
	        double_loop if (chess[i][j] == 'r')
	        {
	            if(i ==  white_king_i)
	             return (j<white_king_j)?
	                hit(+1, 0, i+0, j+1, white_king_i, white_king_j)
	                 :
	                hit(-1, 0, i+0, j-1, white_king_i, white_king_j);
	            if(j ==  white_king_j)
	             return (i<white_king_i)?
	                hit(0, +1, i+1, j+0, white_king_i, white_king_j)
	                 :
	                hit(0, -1, i-1, j+0, white_king_i, white_king_j);
	        }
	    }
    
	    return false;
	};

	bool Bishop(bool whites)
	{
	    if(whites)
	    {
	        double_loop if (chess[i][j] == 'B')
	        {
            
	        }
	    }
	    else
	    {
	        double_loop if (chess[i][j] == 'b')
	        {
            
	        }
	    }
	};

	bool Queen(bool whites)
	{
	    if(whites)
	    {
	        double_loop if (chess[i][j] == 'Q')
	        {
            
	        }
	    }
	    else
	    {
	        double_loop if (chess[i][j] == 'q')
	        {
            
	        }
	    }
	};

	bool King(bool whites)
	{
	    if(whites)
	    {
	        double_loop if (chess[i][j] == 'K')
	        {
            
	        }
	    }
	    else
	    {
	        double_loop if (chess[i][j] == 'k')
	        {
            
	        }
	    }
	};

	bool Knight(bool whites)
	{
	    if(whites)
	    {
	        double_loop if (chess[i][j] == 'N')
	        {
            
	        }
	    }
	    else
	    {
	        double_loop if (chess[i][j] == 'n')
	        {
            
	        }
	    }
	};

	bool Check_Black_King()
	{
	    for (int i=0; i<8; i++)
	     for (int j=0; j<8; j++)
	      if(chess[i][j] == 'k')
	         {
	             black_king_i = i;
	             black_king_j = j;
	         }
    
	    if (Rook(true))
	        return true;
    
	    return false;
	};

	bool Check_White_King()
	{
	    for (int i=0; i<8; i++)
	        for (int j=0; j<8; j++)
	            if(chess[i][j] == 'K')
	            {
	                white_king_i = i;
	                white_king_j = j;
	            }
    
	    if (Rook(false))
	        return true;
    
	    return false;
	};
    
    void print()
    {
        for (int i=0; i<8; i++)
        {
            for (int j=0; j<8; j++)
                cout<<chess[i][j];
            cout<<endl;
        }
    };
    
    void read()
    {
        static ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.7.input");
        for (int i=0; i<8; i++)
            for (int j=0; j<8; j++)
            {
                cin>>chess[i][j];
                
                if(chess[i][j] == 'K')
                {
                    white = {i, j}; //initialize the struct as if we did location white(i,j);
                    white_king_i = i;
                    white_king_j = j;
                }
                
                if(chess[i][j] == 'k')
                {
                    black = {i, j}; //initialize the struct as if we did location black(i,j);
                    black_king_i = i;
                    black_king_j = j;
                }
            }
    };
    
    bool end()
    {
        for (int i=0; i<8; i++)
            for (int j=0; j<8; j++)
                if (chess[i][j] != '.')
                    return false;
        return true;
    };
    
    int main_solve()
    {
        int k=1;
        do
         {
         
         if(Check_White_King())
         cout<<"Game #" << k << ": white king is in check."<<endl;
         else if(Check_Black_King())
         cout<<"Game #" << k << ": black king is in check."<<endl;
         else
         cout<<"Game #" << k << ": no king is in check."<<endl;
         
         //print();
         //cout<<endl;
         k++;
         }while (!end()); 
        
        return 0;
    };
}