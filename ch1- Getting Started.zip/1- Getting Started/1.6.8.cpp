//////////////////////////////////////////////////////
//
//  1.6.8 Australian Voting
//
//  programming_challenges
//
//  Created by Moussa on 31-MAY-2014 12:55 AM
//
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>

using namespace std;

int vote[1000][20];

struct person
{
    string name;
    int freq;
    bool eliminated;
};

person candidate[20];

int voter(int n, int k)
{
    int win = k/2;
    
    //second rounds
    for(int L=1; L<=n; L++)
    {
    
   for (int i = 0; i<n; i++)
    if(candidate[i].freq > win && candidate[i].eliminated == false)
      return i;
        
    // find lowest candidates
    int min = 99999999;
    int lowest;
    for (int i = 0; i<n; i++)
     if(candidate[i].freq < min && candidate[i].eliminated == false)
     { min = candidate[i].freq; lowest = i;}
        
    //remove lowest
    candidate[lowest].eliminated = true;
    
    //distribute his votes
    for (int i = 0; i<k; i++)
     if(vote[i][0] == lowest)
         candidate[vote[i][1]].freq++;
    }
    
    return -1;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.8.input");
    int T; cin >> T;
    for (int t = 1; t<=T; t++) {
        int n; cin>>n;
       
        string s; getline(cin, s); //read the new line escaped 
        for (int i = 0; i<n; i++)
        {   
            getline(cin, s); //for (int i = 0; i<n; i++) cout<<names[i]<<endl;
            candidate[i].name = s;
            candidate[i].freq = 0;
            candidate[i].eliminated = false;
        }
        
        //read votes
        int k=0; 
        while (getline(cin, s) && (s != "\r") && (s != "\n") && (s != ""))
        {
            stringstream ss; ss<<s; //cout << s <<endl;
            for (int i = 0; i<n; i++)
            {
                int primary;
                ss>> primary; //cout<<primary<<endl;
                vote[k][i] = primary - 1;
                if(i==0)
                 candidate[primary-1].freq++;
            }
            k++;
        }
        
        int winner = voter(n, k);
        //print
        cout<<candidate[winner].name<<endl;
    }
    return 0;
}