class Japan{
//private: //default
    struct location
    {
        int x;
        int y;
    };

    //does a line connect directly both locations?
    bool line(location attacker, location king)
    {
        //determine which one is on the low location and the high location
        location low, high;
        if(attacker.x < king.x) {low.x = attacker.x; high.x = king.x;} else {low.x = king.x; high.x = attacker.x;}
        if(attacker.y < king.y) {low.y = attacker.y; high.y = king.y;} else {low.y = king.y; high.y = attacker.y;}
        
        //both are on the same vertical line
        if (attacker.x == king.x)
            for(int i = low.y + 1; i < high.y ; i++)
                if(chess[attacker.x][i] != '.')
                    return false;
        
        //both are on the same horizontal line
        if (attacker.y == king.y)
            for(int i = low.x + 1; i < high.x ; i++)
                if(chess[i][attacker.y] != '.')
                    return false;
        
        return true;
    };
    
    //does a diagonal connect directly both locations?
    bool diagonal(location attacker, location king)
    {
        //both attacker and king forms a square corners (diagonal)
        if (abs(attacker.x - king.x) == abs(attacker.y - king.y)) {
            
            //determine which one is on the low location and the high location
            location low, high;
            if(attacker.x < king.x) {low.x = attacker.x; high.x = king.x;} else {low.x = king.x; high.x = attacker.x;}
            if(attacker.y < king.y) {low.y = attacker.y; high.y = king.y;} else {low.y = king.y; high.y = attacker.y;}
            
            //determine which direction the j will step down-up or top-down
            int jdirection = ((king.x - attacker.x) * (king.y - attacker.y) > 0)? 1 : -1;
            int j = (jdirection == 1)? low.y + 1 : high.y - 1;
            for(int i = low.x + 1; i < high.x ; i++, j+=jdirection)
                if(chess[i][j] != '.')
                    return false;
        }
        else
            return false;
        
        return true;
    };

    //Japanese function
    int CheckTheCheck(location white, location black)
    {
        for (int x=0; x<8; x++)
            for (int y=0; y<8; y++)
                switch (chess[x][y])
            {
                case 'p':
                    if( white.y - y == 1 && abs(white.x - x) == 1) return 2;
                    break;
                case 'P':
                    if( black.y - y == -1 && abs(black.x - x) == 1) return 1;
                    break;
                case 'r':
                    if(line(white, location{x,y})) return 2;
                    break;
                case 'R':
                    if(line(black,location{x,y})) return 1;
                    break;
                case 'b':
                    if(diagonal(white,location{x,y})) return 2;
                    break;
                case 'B':
                    if(diagonal(black,location{x,y})) return 1;
                    break;
                case 'q':
                    if(diagonal(white,location{x,y})||line(white,location{x,y})) return 2;
                    break;
                case 'Q':
                    if(line(black,location{x,y})||diagonal(black,location{x,y})) return 1;
                    break;
                case 'n':
                    if(abs(white.x - x) == 2 && abs(white.y - y) == 1) return 2;
                    if(abs(white.x - x) == 1 && abs(white.y - y) == 2) return 2;
                    break;
                case 'N':
                    if(abs(black.x - x) == 2 && abs(black.y - y) == 1) return 1;
                    if(abs(black.x - x) == 1 && abs(black.y - y) == 2) return 1;
                    break;
                default:
                    break;
            }
        return 3;
    };
    
    //read input
    void read()
    {
        static std::ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.7.input");
        for (int i=0; i<8; i++)
         for (int j=0; j<8; j++)
            {
                cin>>chess[i][j];
                if(chess[i][j] == 'K')
                 white = {i, j}; //initialize the struct as if we did location white(i,j);

                if(chess[i][j] == 'k')
                 black = {i, j}; //initialize the struct as if we did location black(i,j);
            }
    };
    
    //check if end of dataset input
    bool end()
    {
        for (int i=0; i<8; i++)
            for (int j=0; j<8; j++)
                if (chess[i][j] != '.')
                    return false;
        return true;
    };
    
    //print chess board
    void print()
    {
        for (int i=0; i<8; i++)
        {
            for (int j=0; j<8; j++)
                std::cout<<chess[i][j];
            std::cout<<std::endl;
        }
    };
    
    //solve one chess puzzle in a japanese way
    void japanese(int k)
    {
        switch (CheckTheCheck(white, black))
        {
            case 1:
                printf("Game #%d: black king is in check.\n",k);
                break;
            case 2:
                printf("Game #%d: white king is in check.\n",k);
                break;
            case 3:
                printf("Game #%d: no king is in check.\n", k);
                break;
        }
    };
    
    //internal underlying data structure
    char chess[8][8];
    location white, black;
public:
    //ctor
    Japan(){};
    
    //dtor
    ~Japan(){};

    //solve all the chess puzzles in the data set
    void solve()
    {
        int k=1;
        do
        {
            read();
            japanese(k);
            print();
            k++;
        }while (!end());
    }
};
