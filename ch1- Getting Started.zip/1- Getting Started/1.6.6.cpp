//////////////////////////////////////////////////////
//
//  1.6.6 Interpreter
//
//  programming_challenges
//
//  Created by Moussa on 4/11/14.
//
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>

using namespace std;

string RAM[1000];
int Register[10];
int cnt;

int convertStringToNumber(string line)
{
    stringstream ss; ss<<line;
    int n; ss>>n;
    return n;
}

string convertNumberToString(int n)
{
    stringstream ss; ss<<n;
    string line; ss>>line;
    return line;
}
void process(int k)
{
    for (int j=0; j<k; j++)
    {
        string line = RAM[j];
        //process one instruction
        cnt++;
        switch (line[0] - 48) {
            case 1: //100 means halt
                return;
                break;
            case 2: //2dn means set register d to n (between 0 and 9)
                Register[line[1] - 48] = line[2] - 48;
                break;
            case 3: //3dn means add n to register d
                Register[line[1] - 48] += (line[2] - 48);
                Register[line[1] - 48] %= 1000;
                break;
            case 4: //4dn means multiply register d by n 
                Register[line[1] - 48] *= (line[2] - 48);
                Register[line[1] - 48] %= 1000;
                break;
            case 5: //5ds means set register d to the value of register s
                Register[line[1] - 48] = Register[line[2] - 48];
                break;
            case 6: //6ds means add the value of register s to register d]
                Register[line[1] - 48] += Register[line[2] - 48];
                Register[line[1] - 48] %= 1000;
                break;
            case 7: //7ds means multiply register d by the value of register s
                Register[line[1] - 48] *= Register[line[2] - 48];
                Register[line[1] - 48] %= 1000;
                break;
            case 8: //8da means set register d to the value in RAM whose address is in register a
                Register[line[1] - 48] = convertStringToNumber(RAM[line[2] - 48]);
                break;
            case 9: //9sa means set the value in RAM whose address is in register a to that of register s
                 RAM[line[2] - 48] = Register[line[1] - 48];
                break;
            case 0: //0ds means goto the location in register d unless register s contains 0
                if(Register[line[2] - 48] != 0)
                {
                    j = Register[line[1] - 48];
                    j--; //take care from the increament part in for loop....compiler first checks condition => execute all code => finally it increaments; so j got increamented by 1 after it got set.  
                }
                break;
            default:
                break;
        }
    }
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.6.input");
    string line;
    getline(cin, line);
    int t = convertStringToNumber(line);

    for (int i=0; i<t; i++)
    {
        //init registers
        for (int j=0; j<10; j++)
            Register[j]= 000;
        //init rams
        for (int j=0; j<1000; j++)
            RAM[j]= "   ";
        
        //read RAM Data
        int k=0;
        getline(cin, line);
        while (getline(cin, line))
        {
            RAM[k] = line;
            k++;
        }
        cnt = 0;
        process(k);
        cout<<cnt<<endl;
    }
    return 0;
}