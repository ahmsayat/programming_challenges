namespace MOUSSA {
    class CHESS
    {
        //internal underlying data structure
        char chess[8][8];
        
        struct location
        {
            int x;
            int y;
            location(){}
            location(int i, int j)
            {
                this->x = i;
                this->y = j;
            }
            location& set(int i, int j) { x = i; y = j; return *this;}
        };
        
        location white, black;
        
        //moussa's rights
        //if attacker moved in direction direction, will it hit king?
        bool hit(location attacker, location direction, location king)
        {
            while(true)
            {
                attacker.x+=direction.x; attacker.y+=direction.y;
                if (attacker.x == king.x && attacker.y == king.y) //attacker hit/checked king
                    return true;
                
                if (chess[attacker.x][attacker.y] != '.')
                    return false;
            }
        };
        
        //moussa way using hit and directions
        int CheckTheCheck(location white, location black)
        {
            location d;
            for (int x=0; x<8; x++)
                for (int y=0; y<8; y++)
                    switch (chess[x][y])
                {
                    case 'p':
                        if( white.y - y == 1 && abs(white.x - x) == 1) return 2;
                        break;
                    case 'P':
                        if( black.y - y == -1 && abs(black.x - x) == 1) return 1;
                        break;
                    case 'r':
                        d.x = (x == white.x)? 0 : (x<white.x)? 1 : -1;
                        d.y = (y == white.y)? 0 : (y<white.y)? 1 : -1;
                        if(hit(location{x,y}, d , white)) return 2;
                        break;
                    case 'R':
                        d.x = (x == black.x)? 0 : (x<black.x)? 1 : -1;
                        d.y = (y == black.y)? 0 : (y<black.y)? 1 : -1;
                        if(hit(location{x,y}, d, black)) return 1;
                        break;
                    case 'b':
                        d.x = (x == white.x)? 0 : (x<white.x)? 1 : -1;
                        d.y = (y == white.y)? 0 : (y<white.y)? 1 : -1;
                        if(hit(location{x,y}, d, white)) return 2;
                        break;
                    case 'B':
                        d.x = (x == black.x)? 0 : (x<black.x)? 1 : -1;
                        d.y = (y == black.y)? 0 : (y<black.y)? 1 : -1;
                        if(hit(location{x,y}, d, black)) return 1;
                        break;
                    case 'q':
                        d.x = (x == white.x)? 0 : (x<white.x)? 1 : -1;
                        d.y = (y == white.y)? 0 : (y<white.y)? 1 : -1;
                        if(hit(location{x,y}, d, white)||hit(location{x,y}, d, white)) return 2;
                        break;
                    case 'Q':
                        d.x = (x == black.x)? 0 : (x<black.x)? 1 : -1;
                        d.y = (y == black.y)? 0 : (y<black.y)? 1 : -1;
                        if(hit(location{x,y}, d, black)||hit(location{x,y}, d, black)) return 1;
                        break;
                    case 'n':
                        if(abs(white.x - x) == 2 && abs(white.y - y) == 1) return 2;
                        if(abs(white.x - x) == 1 && abs(white.y - y) == 2) return 2;
                        break;
                    case 'N':
                        if(abs(black.x - x) == 2 && abs(black.y - y) == 1) return 1;
                        if(abs(black.x - x) == 1 && abs(black.y - y) == 2) return 1;
                        break;
                    default:
                        break;
                }
            return 3;
        };
        
        //read input
        void read()
        {
            static std::ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.7.input");
            for (int i=0; i<8; i++)
             for (int j=0; j<8; j++)
                {
                    cin>>chess[i][j];
                    if(chess[i][j] == 'K')
                        white = {i, j}; //initialize the struct as if we did location white(i,j);
                    
                    if(chess[i][j] == 'k')
                        black = {i, j}; //initialize the struct as if we did location black(i,j);
                }
        };
        
        //check if end of dataset input
        bool end()
        {
            for (int i=0; i<8; i++)
                for (int j=0; j<8; j++)
                    if (chess[i][j] != '.')
                        return false;
            return true;
        };
        
        //print chess board
        void print()
        {
            for (int i=0; i<8; i++)
            {
                for (int j=0; j<8; j++)
                    std::cout<<chess[i][j];
                std::cout<<std::endl;
            }
        };
        
        //solve one chess puzzle in a moussa way
        void moussa(int k)
        {
            switch (CheckTheCheck(white, black))
            {
                case 1:
                    printf("Game #%d: black king is in check.\n",k);
                    break;
                case 2:
                    printf("Game #%d: white king is in check.\n",k);
                    break;
                case 3:
                    printf("Game #%d: no king is in check.\n", k);
                    break;
            }
        };
        
    public:
        //ctor
        CHESS(){};
        
        //dtor
        ~CHESS(){};
        
        //solve all the chess puzzles in the data set
        void solve()
        {
            int k=1;
            do
            {
                read();
                moussa(k);
                print();
                k++;
            }while (!end());
        };
    };
};