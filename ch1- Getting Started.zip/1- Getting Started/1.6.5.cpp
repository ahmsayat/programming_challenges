//////////////////////////////////////////////////////
//
//  1.6.5 Graphical Editor
//
//  programming_challenges
//
//  Created by Moussa on 1/11/14.
//
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>

using namespace std;

struct pixil
{
    pixil() {};
    pixil(int r, int g, int b): R(r), G(g), B(b) {};
    pixil(char color): Color(color){};
    int R, G, B;
    char Color;
};

pixil ** image;
int Width, Height;

//Create a new M × N image with all pixels initially colored white (O). //M=Width
void I(int M, int N)
{
    Width = M;
    Height = N;
    
    //alloc mem
    image = new pixil* [N];
    for (int i=0; i<N; i++) {
        image[i] = new pixil[M];
    }
    
   //init with white color
   for (int i=0; i<N; i++)
       for (int j=0; j<M; j++)
           image[i][j] = pixil('0');
}

//Clear the table by setting all pixels white (O). The size remains unchanged.
void C()
{
    for (int i=0; i<Height; i++)
        for (int j=0; j<Width; j++)
            image[i][j] = pixil('0');
}

//Colors the pixel (X, Y ) in color (C).
void L(int X, int Y, char C)
{
    image[Y-1][X-1] = pixil(C);
}

//Draw a vertical segment of color (C) in column X, between the rows Y 1 and Y 2 inclusive.
void V(int X, int Y1, int Y2, char C)
{
    for (int i=Y1; i<=Y2; i++)
        image[i-1][X-1] = pixil(C);
}

//Draw a horizontal segment of color (C) in the row Y , between the columns X1 and X2 inclusive.
void H(int X1, int X2, int Y, char C)
{
    for (int j=X1; j<=X2; j++)
        image[Y-1][j-1] = pixil(C);
}

//Draw a filled rectangle of color C, where (X1, Y1) is the upper-left and (X2, Y2) the lower right corner.
void K(int X1, int Y1, int X2, int Y2, char C)
{
    for (int i=Y1; i<Y2; i++)
        for (int j=X1; j<X2; j++)
            image[i-1][j-1] = pixil(C);
}

//??????
//Fill the region R with the color C, where R is defined as follows. Pixel (X, Y ) belongs to R. Any other pixel which is the same color as pixel (X, Y ) and shares a common side with any pixel in R also belongs to this region.
//recursive
void F(int X, int Y, char C, char old_color)
{
    image[Y][X].Color = C;
    
    //left
    if(image[Y][X-1].Color == old_color)
        F(X-1, Y, C, old_color);

    //right
    if(image[Y][X+1].Color == old_color)
        F(X+1, Y, C, old_color);

    //top
    if(image[Y+1][X].Color == old_color)
        F(X, Y+1, C, old_color);

    //bottom
    if(image[Y-1][X].Color == old_color)
        F(X, Y-1, C, old_color);

    //top left
    if(image[Y-1][X-1].Color == old_color)
        F(X-1, Y-1, C, old_color);
    
    //top right
    if(image[Y-1][X+1].Color == old_color)
        F(X+1, Y-1, C, old_color);

    //bottom left
    if(image[Y+1][X-1].Color == old_color)
        F(X-1, Y+1, C, old_color);

    //bottom right
    if(image[Y+1][X+1].Color == old_color)
        F(X+1, Y+1, C, old_color);
}

//Write the file name in MSDOS 8.3 format followed by the contents of the current image.
void S(string filename)
{
    cout<<filename<<endl;
    for (int i=0; i<Height; i++)
    {   for (int j=0; j<Width; j++)
            cout << image[i][j].Color;
        cout<< endl;
    }
}

//Terminate the session.
void X ()
{
}

//G 2 3 J
void donothing()
{
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.5.input");
    string line;
    
    
    
    //read input
    while (getline(cin, line) && line != "X")
    {
        stringstream ss;
        ss<<line;
        char command;
        ss >> command;
        
        switch (command) {
            case 'I':
                int M, N;
                ss>>M>>N;
                I(M,N);
                break;
            case 'C':
                C();
                break;
            case 'L':
                int X, Y;
                char C;
                ss>>X>>Y>>C;
                L(X,Y,C);
                break;
            case 'V':
            {
                int X, Y1, Y2;
                char C;
                ss>>X>>Y1>>Y2>>C;
                V(X,Y1,Y2,C);
            }
                break;
            case 'H':
            {
                int X1, X2, Y;
                char C;
                ss>>X1>>X2>>Y>>C;
                H(X1,X2,Y,C);
            }
                break;
            case 'K':
            {
                int X1, Y1, X2, Y2;
                char C;
                ss>> X1 >> Y1 >> X2 >> Y2 >> C;
                K(X1, Y1, X2, Y2, C);
            }
                break;
            case 'F':
            {
                int  X, Y;
                char C;
                ss>>X>>Y>>C;
                F(X,Y,C, image[X][Y].Color);
            }
                break;
            case 'S':
            {
                string filename;
                ss>>filename;
                S(filename);
            }
                break;
            case 'X':
                return 0;
                break;
            default:
                break;
        }
    }
    return 0;
}