//////////////////////////////////////////////////////
//
//  1.6.4 LCD Display
//
//  programming_challenges
//
//  Created by Moussa on 1/11/14.
//
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>

using namespace std;

/************************Hints**********************/
/*
 * LED representation for each number, according to
 * the following convention:
 *
 *  -0-
 * |   |
 * 2   1
 * |   |
 *  -3-
 * |   |
 * 5   4
 * |   |
 *  -6-
 *
*/

char lookupChar[10][7] = {
       /* 0   1   2   3   4   5   6 */
/* 0 */ {'-','|','|',' ','|','|','-'},
/* 1 */ {' ','|',' ',' ','|',' ',' '},
/* 2 */ {'-','|',' ','-',' ','|','-'},
/* 3 */ {'-','|',' ','-','|',' ','-'},
/* 4 */ {' ','|','|','-','|',' ',' '},
/* 5 */ {'-',' ','|','-','|',' ','-'},
/* 6 */ {'-',' ','|','-','|','|','-'},
/* 7 */ {'-','|',' ',' ','|',' ',' '},
/* 8 */ {'-','|','|','-','|','|','-'},
/* 9 */ {'-','|','|','-','|',' ','-'}
};

#define digits_loop for(int a=0; a<num.length(); a++)
#define size_loop for(int i=0; i<s; i++)
#define dig int digit = ;
int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.4.input");
    int s, n;
    
    //read input
    while (cin >> s >> n && s != 0 && n >= 0 && s >= 1 && s <= 10)
    {
        stringstream ss; ss<<n;
        string num; ss>>num;
        //process one entry
        
        //print 0 level lines
        digits_loop
        {
            cout << " ";
            size_loop
             cout << lookupChar[num[a] - 48][0];
            cout << " ";
        }
        cout<< endl;
        
        //print 1, 2 level lines
    for(int z=0; z<s; z++)
    {   digits_loop
        {
            cout <<lookupChar[num[a] - 48][2];
            size_loop
             cout <<" ";
            cout<<lookupChar[num[a] - 48][1];
            
        }
        cout<< endl;
    }
        
        //print 3 level lines
        digits_loop
        {
            cout << " ";
            size_loop
            cout << lookupChar[num[a] - 48][3];
            cout << " ";
        }
        cout<< endl;
        
        //print 3, 4 level lines
    for(int z=0; z<s; z++)
    {    digits_loop
        {
            cout <<lookupChar[num[a] - 48][5];
            size_loop
                cout <<" ";
            cout<<lookupChar[num[a] - 48][4];
        }
        cout<< endl;
    }

        //print 6 level lines
        digits_loop
        {
            cout << " ";
            size_loop
             cout << lookupChar[num[a] - 48][6];
            cout << " ";
        }
        cout<< endl;
        
        //prepare new line for next entry
        cout <<endl;
    }
    
    return 0;
}


/****My old approach that didn't work
//enum class
enum sign
{
    horizontal =  '-',
    vertical = '|'
};

//enum class
enum lcd
{
    horizontal1 = 1,
    horizontal2 = 2,
    horizontal3 = 4,
    vertical1 = 8,
    vertical2 = 16,
    vertical3 = 32,
    vertical4 = 64,
};

enum digit
{
    one = lcd::vertical2 | lcd::vertical4,
    two = lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical2 | lcd::vertical3,
    three = lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical2 | lcd::vertical4,
    four = lcd::horizontal2 | lcd::vertical1 | lcd::vertical2 | lcd::vertical4,
    five = lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical4,
    six = lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical3 | lcd::vertical4,
    seven =  lcd::horizontal1 | lcd::vertical2 | lcd::vertical4,
    eight = lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical2 | lcd::vertical3 | lcd::vertical4,
    nine = lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical2 | lcd::vertical4,
    zero = lcd::horizontal1 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical2 | lcd::vertical3 | lcd::vertical4
};

int mp[]{
    lcd::horizontal1 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical2 | lcd::vertical3 | lcd::vertical4,
    lcd::vertical2 | lcd::vertical4,
    lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical2 | lcd::vertical3,
    lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical2 | lcd::vertical4,
    lcd::horizontal2 | lcd::vertical1 | lcd::vertical2 | lcd::vertical4,
    lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical4,
    lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical3 | lcd::vertical4,
    lcd::horizontal1 | lcd::vertical2 | lcd::vertical4,
    lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical2 | lcd::vertical3 | lcd::vertical4,
    lcd::horizontal1 | lcd::horizontal2 | lcd::horizontal3 | lcd::vertical1 | lcd::vertical2 | lcd::vertical4
};

//x is the digit to be drawn now
void draw(int x, int s, char L[][], int start)
{
    if(x & 1 > 0)
        for(int i =1; i<=s; i++)
            L[0][1+start+s] = ‘-‘;
    if(x & 2 > 0)
        for(int i =1; i<=s; i++)
            L[s+1][1+start+s] = ‘-‘;
    if(x & 4 > 0)
        for(int i =1; i<=s; i++)
            L[2*s+2][1+start+s] = ‘-‘;
    if(x & 8 > 0)
        for(int i =1; i<=s; i++)
            L[1+ s][start] = ‘|‘;
    if(x & 16 > 0)
        for(int i =1; i<=s; i++)
            L[2 + s + i][start] = ‘|‘;
    if(x & 32 > 0)
        for(int i =1; i<=s; i++)
            L[1+ s][start + s] = ‘|‘;
    if(x & 64 > 0)
        for(int i =1; i<=s; i++)
            L[2 + s + i][start + s] = ‘|‘;
}

void _p(int n)
{
    while(n > 0)
        {
            cout<< (n & 1)? cout<<' ' : cout<<'1';
            n >>= 1;
        }
}

//recurse
void p(int n)
{
    if(n > 0)
    {
        cout<< (n & 1);
        n >>= 1;
        p(n);
    }
}

//map digit
void sw(int d)
{
    switch (d)
    {
        case 1:
            p(digit::one);
            break;
        case 2:
            p(digit::two);
            break;
        case 3:
            p(digit::three);
            break;
        case 4:
            p(digit::four);
            break;
        case 5:
            p(digit::five);
            break;
        case 6:
            p(digit::six);
            break;
        case 7:
            p(digit::seven);
            break;
        case 8:
            p(digit::eight);
            break;
        case 9:
            p(digit::nine);
            break;
        case 0:
            p(digit::zero);
            break;
        default:
            break;
    }
}

void _q(int n)
{
    while(n > 0)
    {
        n/=10;
        sw(n%10);
        cout<<":"<<n%10<<endl;
    }
}

//recurse A=Aa
void q(int n)
{
        if(n > 0)
        {
            q(n/10);
            sw(n%10); //switch right most digit
            cout<<":"<<n%10<<endl;
        }
}

bool is_on(int d, int bar)
{
    return (mp[d] & bar);
}

void t()
{
    
    for(int i=0; i<9; i++)
        if( is_on(i, lcd::vertical1) )
            cout << i << endl;
}

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.4.input");
    int s, n;

    //read input
    while (cin >> s >> n && s != 0 && n >= 0 && s >= 1 && s <= 10)
    {
        stringstream ss; ss <<n;
        string num; ss >> num;
        
        int c_size = (s + 2 + 1)*num.length() - 1;
        int r_size = 2*s+3;
        char res[r_size][c_size];
        
        for(int i=0; i<r_size; i++)
            for(int j=0; j<num.length(); j++)
            {
                int d = num[j];
            }
                
        cout <<  c_size << " " << r_size << endl;
        //q(n);
    }
    
    return 0;
}
end of my old approach ********/