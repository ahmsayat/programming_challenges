//////////////////////////////////////////////////////
//
//  1.6.7 Check the Check
//
//  programming_challenges
//
//  Created by Moussa on 4/11/14.
//
//  Finished by Moussa on 31-MAY-2014 12:25:55 AM
//
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
//////////////////////////////////////////////////////

#include<iostream>
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
#include "Japan.cpp"
#include "MOUSSA_CHESS.cpp"

using namespace std;

char chess[8][8];

struct location
{
    int x;
    int y;
};

location white, black;

//moussa
//if attacker moved in direction direction, will it hit king?
bool hit(location attacker, location direction, location king)
{
    while(true)
    {
        attacker.x+=direction.x; attacker.y+=direction.y;        
        if (attacker.x == king.x && attacker.y == king.y) //attacker hit/checked king
         return true;
        
        if (chess[attacker.x][attacker.y] != '.')
         return false;
    }
}

//moussa recursive way
//if attacker moved in direction direction, will it hit king?
bool hit_recurs(location attacker, location direction, location king)
{
    attacker.x+=direction.x; attacker.y+=direction.y; //move attacker a step toward direction
    if (attacker.x == king.x && attacker.y == king.y) return true; //attacker hit/checked king 
    else if (chess[attacker.x][attacker.y] != '.') return false; //attacker hit obstacle
    else return hit_recurs(attacker, direction, king);
}

//moussa 
int CheckTheCheck(location white, location black)
{
    location d;
    for (int x=0; x<8; x++)
     for (int y=0; y<8; y++)
      switch (chess[x][y])
        {
            case 'p':
                if( white.y - y == 1 && abs(white.x - x) == 1) return 2;
                break;
            case 'P':
                if( black.y - y == -1 && abs(black.x - x) == 1) return 1;
                break;
            case 'r':
                d.x = (x == white.x)? 0 : (x<white.x)? 1 : -1;
                d.y = (y == white.y)? 0 : (y<white.y)? 1 : -1;
                if(hit(location{x,y}, d , white)) return 2;
                break;
            case 'R':
                d.x = (x == black.x)? 0 : (x<black.x)? 1 : -1;
                d.y = (y == black.y)? 0 : (y<black.y)? 1 : -1;
                if(hit(location{x,y}, d, black)) return 1;
                break;
            case 'b':
                d.x = (x == white.x)? 0 : (x<white.x)? 1 : -1;
                d.y = (y == white.y)? 0 : (y<white.y)? 1 : -1;
                if(hit(location{x,y}, d, white)) return 2;
                break;
            case 'B': 
                d.x = (x == black.x)? 0 : (x<black.x)? 1 : -1;
                d.y = (y == black.y)? 0 : (y<black.y)? 1 : -1;
                if(hit(location{x,y}, d, black)) return 1;
                break;
            case 'q': 
                d.x = (x == white.x)? 0 : (x<white.x)? 1 : -1;
                d.y = (y == white.y)? 0 : (y<white.y)? 1 : -1;
                if(hit(location{x,y}, d, white)||hit(location{x,y}, d, white)) return 2;
                break;
            case 'Q': 
                d.x = (x == black.x)? 0 : (x<black.x)? 1 : -1;
                d.y = (y == black.y)? 0 : (y<black.y)? 1 : -1;
                if(hit(location{x,y}, d, black)||hit(location{x,y}, d, black)) return 1;
                break;
            case 'n':
                if(abs(white.x - x) == 2 && abs(white.y - y) == 1) return 2;
                if(abs(white.x - x) == 1 && abs(white.y - y) == 2) return 2;
                break;
            case 'N':
                if(abs(black.x - x) == 2 && abs(black.y - y) == 1) return 1;
                if(abs(black.x - x) == 1 && abs(black.y - y) == 2) return 1;
                break;
            default:
                break;
        }
    return 3;
}
 
void print()
{
    for (int i=0; i<8; i++)
    {
        for (int j=0; j<8; j++)
            cout<<chess[i][j];
        cout<<endl;
    }
}

bool end()
{
    for (int i=0; i<8; i++)
     for (int j=0; j<8; j++)
      if (chess[i][j] != '.')
          return false;
    return true;
}

int main()
{
    //Japan jp; jp.solve();
    //MOUSSA::CHESS m; m.solve();

    int k=1;
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.7.input");
    do
    {
        for (int i=0; i<8; i++)
            for (int j=0; j<8; j++)
            {
                cin>>chess[i][j];
                
                if(chess[i][j] == 'K')
                    white = {i, j}; //initialize the struct as if we did location white(i,j);
                
                if(chess[i][j] == 'k')
                    black = {i, j}; //initialize the struct as if we did location black(i,j);
            }
        
     if(!end())
        if(CheckTheCheck(white, black) == 2)
            cout<<"Game #" << k << ": white king is in check."<<endl;
        else if(CheckTheCheck(white, black) == 1)
            cout<<"Game #" << k << ": black king is in check."<<endl;
        else
            cout<<"Game #" << k << ": no king is in check."<<endl;
        
        //print(); cout<<endl;
        k++;
    } while (!end());

    return 0;
}