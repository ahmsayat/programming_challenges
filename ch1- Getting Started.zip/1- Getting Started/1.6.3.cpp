//  1.6.3 The Trip
//
//  programming_challenges
//
//  Created by Moussa on 1/11/14.
//
//  Copyright (c) 2014 Ahmsayat. All rights reserved.
//
///////////////////////////////////////////// ////////
#include<iostream> 
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
#include<iomanip>
using namespace std;

int main()
{
    ifstream cin("/Ahmsayat/1/1. ACM Coding/Chapters/1- Getting Started/1.6.3.input");
    int n; 
    while(cin>>n)
    if(n==0)
     break;
    else
    {
        double arr[n+1];    
        for(int i=1; i<=n; i++)
         cin>>arr[i];
        
        //summation
        double sum=0;
        for(int i=1; i<=n; i++)
         sum+=arr[i];
        
        //average
        double avg = int(sum/n);
        
        //cout << avg << endl;
        
        //algorithm for minimum amount
        double amount = 0.0;
        for(int i=1; i<=n; i++)
         if(arr[i] < avg)
          amount = amount + avg - arr[i];
       
        cout << "$" << fixed << setprecision(2) << amount << endl;
    }
    
    return 0;
}
