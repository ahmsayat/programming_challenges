//1.6.1 The 3n +1 Problem 
#include<iostream> 
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
using namespace std;

int main()
{
    //ifstream cin("sample.in");
    int i,j; 
    while(cin>>i>>j)
    {
        int max = 0; //max cycle length
        for(int a=i; a<=j; a++)
        {   
            int n=a, cnt=1;
            while(n != 1)
            { //even
              if(n%2 == 0)
                n = n/2;
              else 
                n = 3*n+1;
              cnt++;
            }
            
            if(cnt>max) max=cnt;
        }
        
        cout<<i<<" "<<j<<" "<<max<<endl;
    }
    //system("pause");
    return 0;
}
