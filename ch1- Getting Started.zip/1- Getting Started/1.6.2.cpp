//1.6.2 Minesweeper
#include<iostream> 
#include<string> 
#include<sstream> 
#include<fstream> 
#include<cmath>
using namespace std;

void print(char** arr, int n, int m)
{
      for(int i=1; i<=n; i++)
      {for(int j=1; j<=m; j++)
          cout<<arr[i][j];
       cout<<endl;
      }
}

void solve(char** arr, int n, int m)
{
      for(int i=1; i<=n; i++)
       for(int j=1; j<=m; j++)
        if(arr[i][j]=='.')
        {
               int cnt=0;
               
               //top
               if(i>=2)
                if(arr[i-1][j] == '*')
                 cnt++;
               
               //bottom
               if(i<=n-1)
                if(arr[i+1][j] == '*') 
                 cnt++;
               
               //left
               if(j>=2)
                if(arr[i][j-1] == '*')
                 cnt++;
               
               //right
               if(j<=m-1)
                if(arr[i][j+1] == '*') 
                 cnt++;
               
               //top-left
               if((i>=2) && (j>=2))
                if(arr[i-1][j-1] == '*')
                 cnt++; 
               
               //top-right
               if((i>=2) && (j<=m-1))
                if(arr[i-1][j+1] == '*')
                 cnt++; 
               
               //bottom-left
               if((i<=n-1) && (j>=2))
                if(arr[i+1][j-1] == '*')
                 cnt++; 
               
               //bottom-right
               if((i<=n-1) && (j<=m-1))
                if(arr[i+1][j+1] == '*')
                 cnt++; 
                 
               arr[i][j] = '0' + cnt;
        }
      print(arr,n,m);
}

int main()
{
    ifstream cin("sample.in");
    int n,m, T=1; 
    while(cin>>n>>m)
     if(n==0 || m==0)
      break;
     else
     {
        char** arr; //2D
        arr = new char*[n+1];
        for(int i=1; i<=n; i++)
        { arr[i] = new char[m+1];
         for(int j=1; j<=m; j++)
          cin>>arr[i][j];
        }
      
      cout<<"Field #"<<T++<<":"<<endl;
      solve(arr,n,m);
    }
    system("pause");
    return 0;
}
